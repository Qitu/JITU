//配置阿里云OSS
var client = new OSS.Wrapper({
region : 'oss-ap-southeast-3',
accessKeyId : 'LTAI4FtmFNQicykXA9ANZGir',
accessKeySecret : 'fJilcWY2ByTnBlXPog6uCbroCNzHXI',
bucket : 'jitugoods'
});

function upload_file(mid){
  if ((zxEditor.getBase64Images()).length==0) {
    api.execScript({name: 'Lobby',frameName: 'frame1',script: 'addMoment('+mid+',"'+$api.getStorage('CurrentContent')+'",0);'});
    return;
  }
  let cacheLine=[],imgArray = zxEditor.getBase64Images();
  for (let i = 0; i < imgArray.length; i++){ let cacheData = [(i+1), imgArray[i].base64];  cacheLine.push(cacheData);}
  $api.setStorage('cacheLine',cacheLine);
  continue_upload_file(mid);
}


function dataURItoBlob(dataURI) {
  var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]; // mime类型
  var byteString = atob(dataURI.split(',')[1]); //base64 解码
  var arrayBuffer = new ArrayBuffer(byteString.length); //创建缓冲数组
  var intArray = new Uint8Array(arrayBuffer); //创建视图
  for (var i = 0; i < byteString.length; i++) {
    intArray[i] = byteString.charCodeAt(i);
  }
  return new Blob([intArray], {type: mimeString});
}

let TryTime=0;//重新上传次数
function continue_upload_file(mid, ReModel=false){
  api.toast({ msg: 'Reuploading' });
  if (ReModel) TryTime++;
  if (TryTime>3) {
    $api.setStorage('cacheLine',[]);//清空队列
    api.execScript({name: 'Lobby',frameName: 'frame1',script: 'BackUpload();'});
    return;
  }
  let imgArray= $api.getStorage('cacheLine');
  if (imgArray!=null && imgArray.length>0) {
    const reader = new FileReader();
    reader.readAsArrayBuffer(dataURItoBlob(imgArray[0][1]));
    reader.onload = function (event) {
      const buffer = new OSS.Buffer(event.target.result);
      let storeAs = 'moments'+"/"+mid+'-'+imgArray[0][0]+'.jpg';
      client.put(storeAs, buffer).then(function(result){
            //alert(JSON.stringify(result));
            if (result.res.status=='200') {
              let current = $api.getStorage('cacheLine');
              for (let a = 0; a < current.length; a++){
                if (imgArray[0][0]==current[a][0]) { current.splice(a,1); $api.setStorage('cacheLine',current); }
              }
            }else {continue_upload_file(mid,true); return;}
            continue_upload_file(mid);
        }).catch(function(err){
            console.log(err);//错误
      });
   }
  }else if(imgArray.length==0){
    api.execScript({name: 'Lobby',frameName: 'frame1',script: 'addMoment('+mid+',"'+$api.getStorage('CurrentContent')+'",1);'});
    //api.execScript({name: 'Lobby',frameName: 'frame1',script: 'BackUpload();'});
    return;
  }else{api.execScript({name: 'Lobby',frameName: 'frame1',script: 'BackUpload();'});}

 }
