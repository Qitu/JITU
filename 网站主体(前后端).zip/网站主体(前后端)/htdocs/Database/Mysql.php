<?php

if(!defined('IN_SYS')) { 
       exit('禁止访问 / Prohibition of access');
	   return false;
   } 

/*

  后端数据库入口
  
*/
function connectSQL($ip='gdm340875110.my3w.com',$name='gdm340875110',$password='qitu..233',$dbname='gdm340875110_db')
{
   
   if($_SERVER['HTTP_HOST'] == "www.ramcraft.cn" || $_SERVER['HTTP_HOST'] == "jitu.fun"){
	$sql=mysqli_connect($ip,$name,$password,$dbname);
	$sql->query("set character set 'utf8';");
	$sql->query("set names 'utf8';");
  //date_default_timezone_set('Asia/Shanghai');
	return $sql;
   }else return false;
}


?>