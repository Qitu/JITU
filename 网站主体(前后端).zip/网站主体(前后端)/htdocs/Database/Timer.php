<?php

//代理IP直接退出
//empty($_SERVER['HTTP_VIA']) or exit('Access Denied');

 

 function canDo(){
 session_start(); 
 $seconds = "0.5";
 $refresh = "5";
 $cur_time = time();
 if(isset($_SESSION["last_time"])){

   $_SESSION["refresh_times"]++;

 }else{
   $_SESSION["refresh_times"]=1;
   $_SESSION["last_time"]=$cur_time-10;
 }

 if($cur_time -$_SESSION["last_time"]<$seconds){

   if($_SESSION["refresh_times"]>=$refresh){
//跳转至攻击者服务器地址
     header(sprintf('Location:%s','http://127.0.0.1'));
     exit('Access Denied');
   }

   return false;
 }else{
   $_SESSION["refresh_times"]=0;
   $_SESSION["last_time"]=$cur_time;
   return true;
 }
}
?>

