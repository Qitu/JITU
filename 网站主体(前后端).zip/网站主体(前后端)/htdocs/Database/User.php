<?php 


 require_once "Mysql.php";
 require_once "_Random.php";

 class User{

   static $db;//Database Box


 //User login
 static function _Login($phone){
     $myObj = array('status'=>"false",'token'=>"");
 
     $mysql = new Mysql;
     $rd=new _Random;

     if($mysql->connectSQL()){
       $token=$rd->randomkeys(30);
       if($mysql->_query("SELECT `phone` FROM `db_user` WHERE `phone`='$phone'")){

         $sqll="UPDATE `db_user` SET `token`='$token' WHERE `phone`='$phone'"; 
        if(mysql_query($sqll)){
             $myObj['status'] = 'true';
             $myObj['token'] = $token;            
          }else{            
             $myObj['status'] = '数据库更新失败';
          }

       }else{
         
         $sql="INSERT INTO db_user(`phone`,`token`,`accountType`,`level`) VALUES('$phone','".$token."','0','1')"; 
        if(mysql_query($sql)){
             $myObj['status'] = 'true';
             $myObj['token'] = $token;
          }else{
             $myObj['status'] = '数据创建时出错';
          }
       }
	   mysql_close();
      }
     return json_encode($myObj);
   }
   
   
   static function _Get_info($phone,$token){
      $myObj = array('status'=>"false",'xx'=>"");
     $mysql = new Mysql;
     $rd=new _Random;
     if($mysql->connectSQL()){
       if($data=$mysql->_query("SELECT `position`,`token`,`phone` FROM `db_user` WHERE `token`='$token'")){
           $myObj['status'] = 'true';
           $myObj['xx'] =  $data["position"];
       }
	   mysql_close();
     }
     return json_encode($myObj);
   }
   
   static function _Location($phone,$token,$position,$Location){
      $myObj = array('status'=>"false",'Location'=>"");
     $mysql = new Mysql;
     $rd=new _Random;
     if($mysql->connectSQL()){
     
         $sql="UPDATE `db_user` SET `position`='$position',`Location`='$Location' WHERE `token`='$token'"; 
        if(mysql_query($sql)){
             $myObj['status'] = 'true';
          }else{            
             $myObj['status'] = '信息更新失败';
          }
		  mysql_close();
     }
     return json_encode($myObj);
   }
   
   
 }
 ?>