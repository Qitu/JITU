<?php

 session_start(); 
header("Content-type: text/html; charset=utf-8");
require_once './safe.php';  
require_once 'Timer.php'; 
   if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	   if(canDo()){
	   if(isset($_SESSION['token'])){
	   if(isset($_POST["Door"])){
		   $postID = filter($_POST["Door"]);
		   switch($postID){
			   
			   //商品数据更新
			   case '1':
			       if(isset($_POST["ZH_Name"]) && isset($_POST["EN_Name"]) && isset($_POST["ZH_Size"]) && isset($_POST["EN_Size"]) && isset($_POST["ZH_Class"]) && isset($_POST["EN_Class"]) && isset($_POST["ZH_info"]) && isset($_POST["ZH_info"]) && isset($_POST["Action"])){
					   $ZH_Class = filter($_POST["ZH_Class"]);
					   $EN_Class = filter($_POST["EN_Class"]);
					   $ZH_Name = filter($_POST["ZH_Name"]);
					   $EN_Name = filter($_POST["EN_Name"]);
					   $ZH_Size = filter($_POST["ZH_Size"]);
					   $EN_Size = filter($_POST["EN_Size"]);
					   $ZH_info = filter($_POST["ZH_info"]);
					   $EN_info = filter($_POST["EN_info"]);
					   $GID = filter($_POST["GID"]);
					   $Action = filter($_POST["Action"]);
					   define('IN_SYS', TRUE);
					   require_once '../Database/Mysql.php';                       
                       
						   if($sql = connectSQL()){
                	        
							$z=$sql->query("SELECT 
					                    `ShopID`
									FROM 
									    Shopkeeper 
									WHERE
										Action='".$Action."' AND `KEY`='".$_SESSION['token']."'");	       
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
								$z="UPDATE 
							                      Goods
											SET
											      `ZH_Name`='".$ZH_Name."',`EN_Name`='".$EN_Name."',
												  `ZH_Class`='".$ZH_Class."',`EN_Class`='".$EN_Class."',
												  `ZH_Size`='".$ZH_Size."',`EN_Size`='".$EN_Size."',
												  `ZH_info`='".$ZH_info."',`EN_info`='".$EN_info."'
										    WHERE 
											      GID='".$GID."' AND ShopID='".$row[0]."'";                	            
								if ($sql->query($z)){
									Header("Location: http://jitu.fun/shopkeeper/?2");
									exit;
								}else include_once '500.html';
							}else exit('Action token error');
                		    //商品表获取
                		    
						   }else exit('Server busy');
					   		   
				   }else exit('hop');
			   break;
			   
			   case '2':
			       if(isset($_POST["DID"]) && isset($_POST["Action"])){
					   $GID = filter($_POST["DID"]);
					   $Action = filter($_POST["Action"]);
					   define('IN_SYS', TRUE);
					   require_once '../Database/Mysql.php';                       
                       
						   if($sql = connectSQL()){
                	        //验证用户权限
							$z=$sql->query("SELECT 
					                    `ShopID`
									FROM 
									    Shopkeeper 
									WHERE
										Action='".$Action."' AND `KEY`='".$_SESSION['token']."'");	       
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
								$z="DELETE  FROM
							                      Goods
										    WHERE 
											      GID='".$GID."' AND ShopID='".$row[0]."'";                	            
								if ($sql->query($z)){
									Header("Location: http://jitu.fun/shopkeeper/?2");
									exit;
								}else include_once '500.html';
							}else exit('Action token error');
                		    //商品表获取
                		    
						   }else exit('Server busy');
				   }else exit('Suprise xxxxx');
			   break;
			  
			   case '4':
			       if(isset($_POST["Action"]) && isset($_POST["status"]) && isset($_POST["phone"]) && isset($_POST["ZH_Name"]) && isset($_POST["ZH_info"]) && isset($_POST["EN_Name"]) && isset($_POST["EN_info"])){
					   $Action = filter($_POST["Action"]);
					   $status = filter($_POST["status"]);
					   $phone = filter($_POST["phone"]);
					   $ZH_Name = filter($_POST["ZH_Name"]);
					   $ZH_info = filter($_POST["ZH_info"]);
					   $EN_Name = filter($_POST["EN_Name"]);
					   $EN_info = filter($_POST["EN_info"]);
					   $ZH_info = str_replace("\s","_",$ZH_info);
					   $EN_info = str_replace("\s","_",$EN_info);
					   
					   if($status == '1' || $status == '0') echo 'Hi ~~~';
					   else $status = 0;
					   define('IN_SYS', TRUE);
					   require_once '../Database/Mysql.php';                       
                       
						   if($sql = connectSQL()){
                	        
							$z=$sql->query("SELECT
					                    `ShopID`
									FROM 
									    Shopkeeper 
									WHERE
										Action='".$Action."' AND `KEY`='".$_SESSION['token']."'");	       
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
								$z="UPDATE 
							                      stores
											SET
											      `ZH_Name`='".$ZH_Name."',`ZH_Detail`='".$ZH_info."',
												  `EN_Name`='".$EN_Name."',`EN_Detail`='".$EN_info."',
												  `Phone`='".$phone."',`Status`='".$status."'
										    WHERE 
											      SID='".$row[0]."'";                	            
								if ($sql->query($z)){
									Header("Location: http://jitu.fun/shopkeeper/?1");
									exit;
								}else include_once '500.html';
							}else exit('Action token error');
                		    //商品表获取
                		    
						   }else exit('Server busy');
					   		   
				   }else exit('die');
			   break;
			   

			   
			   case '':
			   break;
		   }
	   }else exit('exm ????');
	   }else{
		    session_destroy();
			$tip = '用户身份已更新，请重新登陆';
			include_once 'view/Login.php';
	   }
	   }else exit('Slowly please ??');
   }else exit('faild');

?>
 
