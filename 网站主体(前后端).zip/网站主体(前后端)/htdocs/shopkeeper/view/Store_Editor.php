﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek">
    <title>Information - Shopkeeper</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">    
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>

<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">Information</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#">Store</a></li>
          <li><a href="#" class="active">Information</a></li>
        </ol>
    </div>
</div>

<form action="updator.php" method="post">

  <div class="row">
   
    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3>店铺信息</h3>
                <p class="text-muted">当用户语言选择为 <code>中文版</code> 时，此店铺信息将会呈上</p>
            </div>
            <div class="panel-body m-t-0">

            <div class="form-group">
                <label for="name">店铺名称</label>
                <input type="text" class="form-control" name="ZH_Name" id="name" placeholder="店铺名称" value="<?php echo $row[0] ?>">
            </div> 

            <div class="form-group">
                <label>店铺通知</label>
                <textarea class="form-control" rows="6" name="ZH_info" placeholder="Your Text"><?php echo $row[1] ?></textarea>
            </div>

            </div>
        </div>
    </div>
	
	<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3>Information</h3>
                <p class="text-muted">When the user choose <code>English</code>，this information will be displayed</p>
            </div>		
            <div class="panel-body m-t-0">
			
            <div class="form-group">
                <label for="name">Sotre name</label>
                <input type="text" class="form-control" name="EN_Name" id="name" placeholder="Sotre name" value="<?php echo $row[2] ?>">
            </div>

            <div class="form-group">
                <label>Note</label>
                <textarea class="form-control" rows="6" name="EN_info" placeholder="Your Text"><?php echo $row[3] ?></textarea>
            </div>

            </div> 
        </div> 
    </div>
  </div>
	
  <div class="row">	
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3>Basic information</h3>
            </div>
            <div class="panel-body m-t-0">
            
            <div class="form-group">
                <label for="name">Contact</label>
                <input type="text" class="form-control" name="phone" id="name" placeholder="Your phone number" value="<?php echo $row[5] ?>">
            </div>
			
		<div id="status">
			<a v-show="status == 1" class="btn btn-md btn-rounded btn-outline bg-green active"  onclick="_ajax()"><span>Open</span></a>
			<a v-show="status == 0" class="btn btn-md btn-rounded btn-outline bg-red active" onclick="_ajax()"><span>Closed</span></a>
			<input type="hidden" id="zzzz" name="status" value="0">
			<input type="hidden" name="Door" value="4">
			
		</div>

			<br>
			<p class="text-muted">Express <code>RM <?php echo $row[6] ?></code></p>
			<br>

            <p class="text-muted">Place <code>Supported</code></p>
			<ul id="info">
				    <li v-for="(value, key, index) in info">
					    {{ key }}
					    <ul>
						    <li v-for="(value, key, index) in info[key]">{{ key }}, {{ value }}</li>
				        </ul>					
					</li>
			</ul>

            <br>
     
            <div class="checkbox checkbox-purple">   
                <input checked id="checkbox01" class="check" type="checkbox" />
                <label for="checkbox01"><span>I agree the </span></label> <a data-toggle="modal" data-target="#myModal" style="color: green">store clause</a>
            </div> 
			
			
			<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
				    <
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                            <h4 class="modal-title" id="myModalLabel">Store clause</h4>
                        </div> 
                        <div class="modal-body">
						    <p style="color: red"> 富强、民主、文明、和谐,、自由、平等、公正、法治、爱国、敬业、诚信、友善</p>
							<p style="color: red"> To be a good man / woman</p>
						</div> 
                        <div class="modal-footer">
                            <button type="button" class="btn btn-md bg-green" data-dismiss="modal"><span>Awesome ！</span></button>
                        </div>
                    </div>
                </div>
            </div>
			
			<div class="form-group">
                <label for="name">Operation code</label>
                <input type="text" class="form-control" name="Action" placeholder="Action token">
            </div>
			
            <button type="submit" value="Submit" class="btn btn-md bg-green"><span>Submit</span></button>
            </div>
        </div>
     </div>
	</div> 
</form>	
	
    

<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2018 Develop by qitu. All Rights Reserved.</p>
        </div> 
      </div>
    </footer>
</div>

</div>
</div>

<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/vue.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>

<script>
    var setting = <?php echo json_encode($_setting) ?>;
	var open = <?php echo $row[7]; ?>;
	
    var getFormatCode=function(strValue){
	    return strValue.replace(/\r\n/g, '<br/>').replace(/\n/g, '<br/>').replace(/\s/g, ' ');
	}
	
	
	if(open == 0){
		$('#zzzz').val(0);
	}else $('#zzzz').val(1);

	function _ajax(){
		if($('#zzzz').val() == 0){
		    $('#zzzz').val(1);
			mmp.status = 1;
		}else {
			$('#zzzz').val(0); 
		    mmp.status = 0;
		}
	}
	
	var info = new Vue({
		el: '#info',
        data: {
	            info: setting,
        }
    });
	
	var mmp = new Vue({
		el: '#status',
        data: {
	            status: open,
        }
    });
	

</script>
</body>

</html>