﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek">
    <title>进行中 - 店掌柜</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">       
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>

<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">In progress</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#">Orders</a></li>
          <li><a href="#" class="active">In progress</a></li>
        </ol>
    </div>
</div>

<div class="row">

   
        <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 sale-bar">
            <div class="panel" style="min-height: 280px">
            <div class="panel-heading">
                <h3>Goods list</h3>
                <p class="text-muted">Goods that you may prepare currently and give them to JITU's courier</p>
            </div>
            <div class="panel-body m-t-0">
            <div class="table-responsive">
            <table class="table table-striped"> 
            <thead> 
            <tr>  
                <th>Name</th> 
                <th>Quantity</th> 
                <th>Total</th> 
            </tr> 
            </thead> 
                <tbody id="all"> 
                <tr v-for="(value, key, index) in info"> 
                    <td>{{ value[1] }}</td> 
                    <td>{{ value[3] }}</td> 
                    <td>{{ value[4] }}</td> 
                </tr>          
                </tbody> 
            </table>
            </div>
            </div>
        </div>
        </div>

        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 stat-item">
        <div class="panel">     
            <div class="panel-body">
                <div class="col-xs-9 left-content no-padding pull-left">
                    <h2> Orders</h2>
                    <div class="statistics"><?php echo $num; ?></div>
                </div>
                <div class="col-xs-3 right-content no-padding pull-right">
                    <span><i class="fa fa-cart-plus" aria-hidden="true"></i></span>
                </div>
            </div>
            <div class="panel-footer">
                <div class="date"><h5><i class="fa fa-clock-o" aria-hidden="true"></i> Orders in this progress </h5></div>
            </div>
        </div>
        </div>
    
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 stat-item">
            <div class="panel">     
                <div class="panel-body">
                        <h2> Total</h2>
						<div class="col-xs-9 left-content no-padding pull-left">
                        <div class="statistics">RM <?php echo $total; ?></div>
                    </div>
                    <div class="col-xs-3 right-content no-padding pull-right">
                        <span><i class="fa fa-comment" aria-hidden="true"></i></span>
                    </div>
                </div>
                <div class="panel-footer">
                    <div class="date"><h5><i class="fa fa-clock-o" aria-hidden="true"></i> Orders in this progress </h5></div>
                </div>
            </div>
        </div>
</div>


<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2018 Develop by qitu. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
</div>

</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/vue.js"></script>
<script src="js/tools.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
<script>
    var data = <?php echo json_encode($view) ?>;
    var WORI = new Vue({
		el: '#info',
        data: {
	            info: data,
        },
		methods: {
		    look: function(id){
				//alert(id);
				var ar = (id).split('.'); //获取商品数据
	            var box = [];
	            	if(ar.length > 1){
	            		for (var y in ar){
	            			var arr = ar[y].split(',');
	            			if(arr.length > 1){
	            				var _id = arr[0];
	            				var _name = arr[1];
	            				var _count = arr[2];
								//box = [_id, _name, _count];
								box.push(new Array(_id, _name, _count));
	            			}
	            		}
	            	}
				mmp.info = box
				$("#modalaaa").click();
			}
		}
    });
	
	
	var mmp = new Vue({
		el: '#myModa2',
        data: {
	            info: [],
        }
    });
	
	
	
	var all = new Vue({
		el: '#all',
        data: {
	            info: [],
        }
    });
	
	
	var goods = <?php echo json_encode($goods) ?>;
	
	
	$(document).ready(function() {
		
		var box = [];
	    for (var x in data){ //遍历全部订单数据
		    for (var a in data[x]){ //遍历全部订单数据
		    var ar = (data[x][a][4]).split('.'); //获取商品数据
	        if(ar.length > 1){
	            for (var y in ar){
	            	var arr = ar[y].split(',');
	            	if(arr.length > 1){
	            		var _id = arr[0];
						if(arr.length == 3) var _count = parseInt(arr[2]);
						else if(arr.length == 2) var _count = parseInt(arr[1]);
						var has = false;
						var index = 0;
						var name = '';
						var price = 0;
						var total= 0;
						for (var z in box){ //寻找模式
						    if(box[z][0] == _id){
								has = true;
								index = z;
						        
								break;
							}
						}
						
						//探寻商品原始数据
						        for (var b in goods){
						        	if(goods[b][0] == _id){
						        		name = goods[b][1];
						        		price = goods[b][2];
										total = total + Mu(price,_count);
						        		break;
						        	}
						        }
						
						if(has) {
							box[index][3] = box[index][3] + _count;
							box[index][4] = box[index][4] + total;
						}else box.push(new Array(_id, name, price, _count, total));
						
						
	            	}
	            }
			}
	        }
		}
		all.info = box;
	});
</script>
</body>

</html>