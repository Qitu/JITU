﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek">
    <title>History - Shopkeeper</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">    
    <link rel="stylesheet" type="text/css" href="css/datatables/datatables.min.css">    
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">History</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#">Order</a></li>
          <li><a href="#" class="active">History</a></li>
        </ol>
    </div>
</div>

<div class="row">
    
    <div class=" col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3>Order list</h3>
            </div>
            <div class="panel-body m-t-0">
            <div class="table-responsive">
            <table id="multi-table" class=" table table-striped">
            <thead>
                <tr>
				    <th>#</th>
                    <th>Name</th>
                    <th>Phone</th>
					<th>Time</th>
                    <th>Deliver</th>                    
					<th>Price</th>
                </tr>
				
            </thead>
            <tbody id="info">
                <tr v-for="(value, key, index) in info">
				    <td>{{ value[0] }}</td>
					<td>{{ value[1] }}</td>
					<td>{{ value[2] }}</td>
					<td>{{ value[4] }}</td>
					<td>None</td>
					<td>{{ value[3] }}</td>
				</tr>
            </tbody>
            </table>
            </div>
            </div>
        </div>
    </div>
</div>


<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2016 Develop by qitu. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
</div>

</div>
</div>


<script src="js/jquery.min.js"></script>
<script src="js/vue.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script type="text/javascript" src="js/datatables/datatables.min.js"></script>
<script>
$(document).ready(function() {
"use strict";
    $('#basic-table').DataTable();
     $('#multi-table').DataTable( {
        columnDefs: [ {
            targets: [ 0 ],
            orderData: [ 0, 1 ]
        }, {
            targets: [ 1 ],
            orderData: [ 1, 0 ]
        }, {
            targets: [ 4 ],
            orderData: [ 4, 0 ]
        } ]
    } );
});
</script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
<script>
    var data = <?php echo json_encode($view) ?>;
    var mmp = new Vue({
		el: '#info',
        data: {
	            info: data,
        }
    });
</script>
</body>

</html>