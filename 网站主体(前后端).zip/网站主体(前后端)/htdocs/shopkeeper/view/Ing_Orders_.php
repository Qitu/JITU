﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>进行中 - 店掌柜</title>
    <!-- Custom Style-->
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <!-- Theme Color Style-->
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">       
    <!-- Nano Scroller Default Style-->
	<link rel="stylesheet" type="text/css" href="css/datatables/datatables.min.css"> 
    <link rel="stylesheet" href="css/nanoscroller.css">
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<?php include_once 'view/top.php' ?>

<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">进行中订单</h1>
        <!-- //////////////////////////////////////////////////// Breadcrumb -->
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#">订单管理</a></li>
          <li><a href="#" class="active">进行中订单</a></li>
        </ol> <!-- /breadcrumb -->
        
    </div> <!-- /dashboard -->
</div> <!-- /row -->


<div class="row">

   
        <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 sale-bar">
            <div class="panel" style="min-height: 280px">
            <div class="panel-heading">
                <h3>备货表单</h3>
                <p class="text-muted">作为商家，你需要提供的商品</p>
            </div> <!-- /panel-heading -->
            <div class="panel-body m-t-0">
            <div class="table-responsive">
            <table class="table table-striped"> 
            <thead> 
            <tr> 
                <th>#</th> 
                <th>商品名</th> 
                <th>单价</th> 
                <th>数量</th> 
                <th>总价</th> 
            </tr> 
            </thead> 
                <tbody id="all"> 
                <tr v-for="(value, key, index) in info"> 
                <th scope="row">{{ value[0] }}</th> 
                    <td>{{ value[1] }}</td> 
                    <td>{{ value[2] }}</td> 
                    <td>{{ value[3] }}</td> 
                    <td>{{ value[4] }}</td> 
                </tr>          
                </tbody> 
            </table>
            </div> <!-- /table-responsive -->
            </div> <!-- /panel-body -->
        </div> <!-- /panel-->
        </div> <!-- /col -->

        <!-- //////////////////////////////////////////////////// Statistics -->

        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 stat-item">
        <div class="panel">     
            <div class="panel-body">
                <div class="col-xs-9 left-content no-padding pull-left">
                    <h2> 订单总量</h2>
                    <div class="statistics"><?php echo $num; ?></div>
                </div>
                <div class="col-xs-3 right-content no-padding pull-right">
                    <span><i class="fa fa-cart-plus" aria-hidden="true"></i></span>
                </div>
            </div> <!-- /panel-body -->
            <div class="panel-footer">
                <div class="date"><h5><i class="fa fa-clock-o" aria-hidden="true"></i> 本次进行中订单 </h5></div>
            </div> <!-- /panel-footer -->
        </div> <!-- /panel -->
        </div> <!-- /col-lg-3 -->
    
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 stat-item">
            <div class="panel">     
                <div class="panel-body">
                    <div class="col-xs-9 left-content no-padding pull-left">
                        <h2> 金额总值</h2>
                        <div class="statistics"><?php echo $total; ?> RM</div>
                    </div>
                    <div class="col-xs-3 right-content no-padding pull-right">
                        <span><i class="fa fa-comment" aria-hidden="true"></i></span>
                    </div>
                </div> <!-- /panel-body -->
                <div class="panel-footer">
                    <div class="date"><h5><i class="fa fa-clock-o" aria-hidden="true"></i> 本次进行中订单 </h5></div>
                </div> <!-- /panel-footer -->
            </div> <!-- /panel -->
        </div> <!-- /col-lg-3 -->

</div> <!-- /row -->


<div class="row">	
	
	
	
	
	
	
	<div class="col-sm-12 col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3>订单列表</h3>
                <p class="text-muted">你将亲自运送 <code>下方全部订单</code></p>
            </div>
            <div class="panel-body m-t-0">
            <div class="table-responsive">
            <table id="multi-table" class="display table">
            <thead>
            <tr>
                <th>#</th>
                <th>用户</th>
				<th>联系</th>
				<th>运送</th>
                <th>金额</th>
				<th>商品</th>
            </tr> 
            </thead> 
                <tbody id="info">         
				<tr v-for="(value, key, index) in info"> 
                    <td>{{ value[0] }}</td> 
                    <td>{{ value[1] }}</td> 
				    <td>{{ value[2] }}</td>
                    <td>{{ value[3] }}</td> 
                    <td>{{ value[4] }}</td> 
				    <td><a @click="look(value[5])">查看</a></td> 
                </tr>
                </tbody> 
            </table>
            </div> <!-- /table-responsive -->
            </div> <!-- /panel-body -->
        </div> <!-- /panel-->
    </div> <!-- /col -->
 

</div> <!-- /row -->



<a id="modalaaa" style="display: none" data-toggle="modal" data-target="#myModa2">mmp</a>
	        <!-- 详情晔 -->
            <div class="modal fade" id="myModa2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                            <h4 class="modal-title" id="myModalLabel">商品详情</h4>
                        </div> 
                        <div class="modal-body">
						
						    
                                <div class="table-responsive">
                                <table class="table"> 
                                <thead> 
                                <tr> 
                                    <th>ID</th> 
                                    <th>名称</th>
			                    	<th>数量</th>
                                </tr> 
                                </thead> 
                                    <tbody> 				
                                        <tr v-for="value in info">  
                                            <th scope="row">{{ value[0] }}</th> 
                                            <td>{{ value[1] }}</td>   
                                            <td>{{ value[2] }}</td> 
                                        </tr>
                                    </tbody> 
                                </table>
                                </div> 
                             

						</div> 
                        <div class="modal-footer">
                            <button type="button" class="btn btn-md" data-dismiss="modal"><span>返回</span></button>
                        </div> 
                    </div> 
                </div> 
            </div> 


<!-- //////////////////////////////////////////////////// Footer -->
<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2018 Develop by qitu. All Rights Reserved.</p>
        </div> <!-- /col-sm-12 -->
      </div> <!-- /credits -->
    </footer> <!-- /footer-->
</div> <!-- /row -->

</div> <!-- /container-fluid -->
</div> <!-- /content-panel -->

<script src="js/jquery.min.js"></script>
<script src="js/vue.js"></script>
<script src="js/tools.js"></script>
<!-- Offline jQuery script -->  
<!-- <script  type="text/javascript" src="jquery.min"></script>  -->
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<!-- Menu Script -->
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<!-- Data Tables scripts -->
<script type="text/javascript" src="js/datatables/datatables.min.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
<script>
$(document).ready(function() {
"use strict";
    $('#basic-table').DataTable();
     $('#multi-table').DataTable( {
        columnDefs: [ {
            targets: [ 0 ],
            orderData: [ 0, 1 ]
        }, {
            targets: [ 1 ],
            orderData: [ 1, 0 ]
        }, {
            targets: [ 4 ],
            orderData: [ 4, 0 ]
        } ]
    } );
});
</script>

<script>
    var data = <?php echo json_encode($view) ?>;
    var o = new Vue({
		el: '#info',
        data: {
	            info: data,
        },
		methods: {
		    look: function(id){
				//alert(id);
				var ar = (id).split('.'); //获取商品数据
	            var box = [];
	            	if(ar.length > 1){
	            		for (var y in ar){
	            			var arr = ar[y].split(',');
	            			if(arr.length > 1){
	            				var _id = arr[0];
	            				var _name = arr[1];
	            				var _count = arr[2];
								box.push(new Array(_id, _name, _count));
	            			}
	            		}
	            	}
				mmp.info = box
				$("#modalaaa").click();
			}
		}
    });
	
	
	
	
	var mmp = new Vue({
		el: '#myModa2',
        data: {
	            info: [],
        }
    });
	
	
	
	
	var all = new Vue({
		el: '#all',
        data: {
	            info: [],
        }
    });
	
	
	var goods = <?php echo json_encode($goods) ?>;
	
	
	$(document).ready(function() {
		
		var box = [];
	    for (var x in data){ //遍历全部订单数据
		    var ar = (data[x][5]).split('.'); //获取商品数据
	        if(ar.length > 1){
	            for (var y in ar){
	            	var arr = ar[y].split(',');
	            	if(arr.length > 1){
	            		var _id = arr[0];
	            		var _count = parseInt(arr[2]);
						var has = false;
						var index = 0;
						var name = '';
						var price = 0;
						var total= 0;
						for (var z in box){ //寻找模式
						    if(box[z][0] == _id){
								has = true;
								index = z;
						        
								break;
							}
						}
						
						//探寻商品原始数据
						        for (var b in goods){
						        	if(goods[b][0] == _id){
						        		name = goods[b][1];
						        		price = goods[b][2];
										total = total + Mu(price,_count);
						        		break;
						        	}
						        }
						
						if(has) {
							box[index][3] = box[index][3] + _count;
							box[index][4] = box[index][4] + total;
						}else box.push(new Array(_id, name, price, _count, total));
						
						
	            	}
	            }
			}
		}
		all.info = box;
	});
	
</script>
</body>

</html>