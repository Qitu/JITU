﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek">
    <title>GOODS - Shopkeeper</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">     
    <link rel="stylesheet" type="text/css" href="css/summernote/summernote.css">
    <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.1/summernote.css" rel="stylesheet">
    <link rel="stylesheet" href="css/switchery/switchery.css">
    <link rel="stylesheet" href="css/touchspin/jquery.bootstrap-touchspin.css">
    <link rel="stylesheet" href="css/nanoscroller.css">

</head>

<body>
<?php include_once 'view/top.php' ?>

<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
    <h1 class="dash-title">Goods</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#">Stores</a></li>
          <li><a href="#" class="active">Goods</a></li>
        </ol>
    </div>
</div>


<div class="row">
<div class="col-xs-12">  
    <div class="panel">
        <div class="panel-heading"><h3>Goods</h3></div>
        <div class="panel-body">
        <div class="col-lg-2 col-md-2 col-sm-2 nav-ecommerce col-xs-12 no-padding">
          <ul class="nav nav-tabs nav-pills nav-stacked wells" role="tablist">
            <li role="presentation" class="active"><a href="#ing" aria-controls="ing" role="tab" data-toggle="tab">Goods on shelves</a></li>
            <li role="presentation"><a href="#add" aria-controls="add" role="tab" data-toggle="tab">Add new products</a></li>
          </ul> 
        </div>
          <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12 table-ecommerce e-commerce-form">
          <div class="tab-content">
			<div role="tabpanel" class="tab-pane active active" id="ing">
			    <div class="table-responsive">
            <table class="table table-striped"> 
            <thead> 
            <tr> 
                <th>Name</th>
				<th>Price</th>
				<th>Operation</th>
				<th>Class</th>
            </tr>
            </thead>
                <tbody>
				<?php echo $view; ?>
                </tbody>
            </table>
            </div>
			
			
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                            <h4 class="modal-title" id="myModalLabel">Edit goods</h4>
                        </div> 
                        <form action="updator.php" method="post" class="modal-body">
						    <input type="hidden" name="Door" value="1">
							<input style="display: none" type="text" name="GID" id="GID" value="0">
						    <div class="form-group">
                                <label for="des">名称</label>
                                <input type="text" class="form-control" id="ZH_Name" name="ZH_Name" placeholder="中文名">
                            </div>
						    <div class="form-group">
                                <label for="des">Name</label>
                                <input type="text" class="form-control" id="EN_Name" name="EN_Name" placeholder="name">
                            </div>
							
							<div class="form-group">
                                <label for="des">规格</label>
                                <input type="text" class="form-control" id="ZH_Size" name="ZH_Size" placeholder="规格，如： 一个">
                            </div>
						    <div class="form-group">
                                <label for="des">Size</label>
                                <input type="text" class="form-control" id="EN_Size" name="EN_Size" placeholder="Size：eg. One box">
                            </div>
							
							<div class="form-group">
                                <label for="des">类型</label>
                                <input type="text" class="form-control" id="ZH_Class" name="ZH_Class" placeholder="类型名">
                            </div>
						    <div class="form-group">
                                <label for="des">Class</label>
                                <input type="text" class="form-control" id="EN_Class" name="EN_Class" placeholder="Class name">
                            </div>
							
							<div class="form-group">             
                                <textarea class="form-control" rows="3" id="ZH_info" name="ZH_info" placeholder="介绍"></textarea>
                            </div>
							<div class="form-group">             
                                <textarea class="form-control" rows="3" id="EN_info" name="EN_info" placeholder="Introduction"></textarea>
                            </div>
							
							
                            <div class="form-group">
                                <label for="des">Operation code</label>
                                <input type="number" class="form-control" name="Action" placeholder="Code">
                            </div>
							<input style="display: none" id="s" type="submit" value="Submit" />
						</form> 
                        <div class="modal-footer">
						    
						    
                            <button type="button" class="btn btn-md bg-red" data-dismiss="modal"><span>Cancel</span></button>
                            <button class="btn btn-md bg-green" onclick="Do()"><span>Edit</span></button>
                        </div> 
                    </div> 
                </div> 
            </div> 
            
			
            <div class="modal fade" id="myModa2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <form action="updator.php" method="post" class="modal-dialog" role="document">
				    <input type="hidden" name="Door" value="2">
					<input style="display: none" type="text" name="DID" id="DDID" value="0">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                            <h4 class="modal-title" id="myModalLabel">Delete goods</h4>
                        </div> 
                        <div class="modal-body">
						    <p style="color: red">Are you sure to delete the goods ? ( ID：<b id="DID">0</b> )</p>
						    <div class="form-group">
                                <label for="des">Input your operation code</label>
                                <input type="text" class="form-control" name="Action" placeholder="Token">
                            </div>
						</div> 
                        <div class="modal-footer">
                            <button type="button" class="btn btn-md" data-dismiss="modal"><span>Cancel</span></button>
                            <button type="submit" value="Submit" class="btn btn-md bg-red"><span>Delete</span></button>
                        </div> 
                    </div> 
                </form> 
            </div> 
			
        </div> 

            <div role="tabpanel" class="tab-pane" id="add">
			    
				
                <h2>Contact the admin to add new products via the accounts below</h2>
				<hr class="m-b-0" >
				<br>
				<ul>

					    <li>Wechat： 13357220477</li>
						<li>WhatsApp： 0172917920</li>

				<br>
				<hr class="m-b-0" >
				<br>
		
					    <li>You shall provide your store infomation</li><br>
						<li>You shall provide a simple description of the new goods (name, class, size, price, ...)</li><br>
						<li>You shall provide a picture of the new goods ( Image ratio 1:1 )</li>

				</ul>
				<br>
				<br>
				
            </div>
          </div>
          </div>
        </div>
    </div>
</div>
</div>




<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2018 Develop by qitu. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
</div>

</div>
</div>

<script src="js/jquery.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/switchery/switchery.js"></script>
<script  type="text/javascript" src="js/touchspin/jquery.bootstrap-touchspin.js"></script>
<script  type="text/javascript" src="js/touchspin/data.js"></script>
<script type="text/javascript" src="js/summernote/summernote.js"></script>
<script>
    
    $('#description').summernote();
</script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
<script>
    function Edit(ZH_Name,EN_Name,ZH_Size,EN_Size,ZH_Class,EN_Class,ZH_info,EN_info,id){
		$('#ZH_Name').val(ZH_Name);
		$('#EN_Name').val(EN_Name);
		$('#ZH_Size').val(ZH_Size);
		$('#EN_Size').val(EN_Size);
		$('#ZH_Class').val(ZH_Class);
		$('#EN_Class').val(EN_Class);
		$('#ZH_info').val(ZH_info);
		$('#EN_info').val(EN_info);
		$('#GID').val(id);
	}
	
	function Del(id){
		$('#DID').text(id);
		$('#DDID').val(id);
	}
	
	function Do(){
		$('#s').click();
	}
	
	
    var getFormatCode=function(strValue){
	    return strValue.replace(/\r\n/g, '<br/>').replace(/\n/g, '<br/>').replace(/\s/g, ' ');
    }
</script>
</body>

</html>