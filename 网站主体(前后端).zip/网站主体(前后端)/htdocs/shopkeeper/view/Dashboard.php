﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek">
    <title>JITU - Shopkeeper</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css"> 
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">Home</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#" class="active">Dashboard</a></li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-md-4">      
        <div class="panel">
            <div class="panel-heading">
                <h3>Your store</h3>
                <p class="text-muted">This is the link of your store： <a href="http://jitu.fun/shops?<?php echo filter($mmp[0]); ?>">http://jitu.fun/shops?<?php echo filter($mmp[0]); ?></a></p>
            </div>
            <div class="panel-body m-t-10">
            <div class="list-group">
              <a href="#" class="list-group-item active">Store ID ： <b>#<?php echo filter($mmp[0]); ?></b></a>
              <a href="#" class="list-group-item"><?php echo $mmp[1] ?> / <?php echo filter($mmp[2]); ?></a>
              <a href="#" class="list-group-item">Express： RM <?php echo filter($mmp[3]); ?></a>
              <a href="#" class="list-group-item"><?php 
			                                        if($mmp[4] == 1) $out = '<span class="btn-xs bg-green">Open</span>';
													else if($mmp[4] == 0) $out = '<span class="btn-xs bg-red">Closed</span>';
													else $out = '<span class="btn-xs bg-red">Undefined</span>';
			                                        echo $out; ?>
													</a>
            </div>
            </div>
        </div>
    </div>
	
	
	
<div class="col-md-8">
    <div class="panel">
        <div class="panel-heading m-b-0">
            <h3>Announcements</h3>
            <p class="text-muted">Please keep an eye on the platform announcements below.</p>
        </div>
        <div class="panel-body">
            
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          
          <div class="panel panel-default bg-purple m-t-0">
          <div class=" panel-heading active" role="tab" id="headingOne">
            <h4 class="panel-title">
              <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> Fast & Light <span class="rectangle center-block"></span></a>
            </h4>
          </div>

          <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel">
            <div class="panel-body">
            <p>Suspendisse eu pharetra ex. In vitae blandit nisl. Sed quis neque varius, 
            malesuada mi consequat, tincidunt iaculis leo. In vitae augue eget velit viverra cursus. 
            Sed pellentesque semper lorem, sed imperdiet iaculis sollicitudin.  </p>
            </div>
          </div>
          </div>

          <div class="panel panel-default bg-purple">
          <div class="panel-heading" role="tab" id="headingTwo">
            <h4 class="panel-title">
              <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"> 管理员联系方式 <span class="rectangle center-block"></span></a>
            </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel">
              <div class="panel-body">
                <p>
				    <b>各位店家添加下面联系方式方便联系</b>
				        <br>联系电话： 60172917920		
						<br>WhatsApp： 969977237
						<br>QQ： 969977237
						<br>微信： qitu__
				</p>
              </div>
            </div>
          </div>


        </div>
        </div>
    </div>
</div>
</div>

<br><br>




        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12 ">
            <div class="panel m-t-0">
            <div class="panel-heading bg-purple font-white"><h3>Shopkeeper System</h3></div>
                <div class="panel-body panel-content">
                    <p>
					    <ul class="unordered"> 
                 <li>
				 店掌柜是积土一套完备的商家后台系统 。
				 商家获得权限后可在后台对自己店铺的 
                 商品进行实时修改数据、查看/编辑订单
                 信息、与用户进行交流。
				 </li>
				 <li> 
				 相比传统的 线下/伪线上 销售，我们更
				 加方便、快捷、思路清晰，商家拥有更多
				 的时间去思考、去创造 自己独特的销售
				 方式而不是纠结于用户来源等各种问题
				 </li>
				 <li> 
				 我们都正在不断成长 ... <br>来日方长，请多指教 ！
				 </li> 
             </ul> 
					</p>
			    </div>
            </div>
            </div>
        </div>

       

<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2018 Develop by Qitu. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
</div>

</div>
</div>


<script src="js/jquery.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
</body>

</html>