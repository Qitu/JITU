﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek. edited by qitu">
    <title>Pre orders - Shopkeeper</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-green.css">  >
    <link rel="stylesheet" type="text/css" href="css/datatables/datatables.min.css">    
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
    <h1 class="dash-title">Pre Orders</h1>   
        <ol class="breadcrumb">
          <li><a href="https://jitu.fun/Port/?0"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#">Orders</a></li>
          <li><a href="#" class="active">Pre</a></li>
        </ol>
    </div>
</div>
<?php if($view!=''){ ?>
<div style="margin-top: 45px; background: #FFF; border-radius: 8px">
            <div class="table-responsive">
            <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Contact</th>
					<th>Action</th>
					<th>Goods</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody id="info">
                <?php echo $view; ?>			
            </tbody>
                </table>
				<?php if($view=='') echo '<p style="text-align: center">No order now, try to get more!</p>'; ?>
                </div>
</div>
<?php }else{?>
<div style="text-align: center; ">
<img style="width: 240px; height: 240px; margin: 65px auto" src="nodata.png">
<br>
<a href="http://jitu.fun/Port/?2"><button class="btn btn-md bg-green m-r-10"><span>Ongoing 进行中订单</span></button></a>
</div>
<?php }?>

<div class="modal fade" id="action" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                            <h4 class="modal-title" id="myModalLabel">Goods detail</h4>
                        </div> 
                        <div class="modal-body">
								<div id="data">...</div>
								<br>
						</div> 
                        <div class="modal-footer">
							<button type="button" class="btn btn-md" data-dismiss="modal"><span>Back</span></button>
                        </div> 
                    </div> 
                </div> 
            </div> 




<div class="modal fade bs-modal-sm" id="operation" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-sm" role="document">
                    <div class="modal-content" id="ttip">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                                <h4 class="modal-title">Edit Orders</h4>
                        </div>
			
                        <form action="updator.php" method="post" class="modal-body">
				           
							<p style="color: #FFF; font-weight: 700" id="tt">Are you sure ？</p>
						    <br><br>
							
							<div class="form-group" id="pBox">
                                <label for="loc">Location</label>
                                <input id="loc" type="text" class="form-control" name="loc" placeholder="location info">
                            </div>
							
							
			                <div class="form-group">
                                <label for="des">Action code</label>
                                <input id="des" type="password" class="form-control" name="Action" placeholder="Code">
                            </div>
				
            				<input style="display: none" id="mdzz" type="submit" value="Submit" />
		            		<input type="hidden" id="Door" name="Door" value="1">
	            			<input type="hidden" id="OID" name="OID" value="0">
							<input type="hidden" id="ways" name="ways" value="App">
                        
			
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-md bg-purple"><span>Submit</span></button>
                        </div>
						</form>
                    </div>
                </div>
            </div>




</div>
</div>


<script src="js/jquery.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script type="text/javascript" src="js/datatables/datatables.min.js"></script>
<script>



function saw(data){
	$('#data').html(data);
}
	
	
	
function opt(kind,id,way,position){
	$('#loc').val(position);
	if(kind == 1){
		$('#ttip').css("background","#469f49");
		$('#tt').text('Process it');
		$('#Door').val('1');
		if(way != 'App' && way != "App") $('#pBox').show();
		else $('#pBox').hide();
	}else{
		$('#ttip').css("background","#FF9703");
		$('#tt').text('Cancel this order');
	    $('#Door').val('3');
		$('#pBox').hide();
	}
	$('#OID').val(id);
	$('#ways').val(way);
}


</script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>

</body>

</html>