﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek. edited by qitu">
    <title>JITU reward</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-green.css">  >
    <link rel="stylesheet" type="text/css" href="css/datatables/datatables.min.css">    
    <link rel="stylesheet" href="css/nanoscroller.css">
	
	<style>
	    .lct{
			display: -webkit-box;
			-webkit-box-orient: vertical;
			overflow: hidden;
			font-size: 12px;
		}
	</style>
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
    <h1 class="dash-title">Your reward</h1>   
        <ol class="breadcrumb">
          <li><a href="https://jitu.fun/Port/?0"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#">Reward</a></li>
        </ol>
    </div>
</div>

<div style="text-align: center; margin-top: 35px">
<input class="btn btn-md bg-purple m-r-10 col-xs-5" type="date" value="2019-01-01">
<input type="date" class="btn btn-md m-r-10 col-xs-5" value="">
</div>


            <div class="modal fade" id="action" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                            <h4 class="modal-title" id="myModalLabel">Goods detail</h4>
                        </div> 
                        <div class="modal-body">
						
						    
                                <p>UserName： <span id="name">...</span></p>
								<p>Contact： (<span id="contact">...</span>) <span id="phone">...</span></p>
								<p>Date： <span id="time">...</span></p>
								<p>Deliver： <span id="express">...</span></p>
								<br>
								<p style="font-weight: 700">Goods：</p>
								<div id="data">...</div>
								<br>
								<p>RM <b id="price">0.00</b></p>
						</div> 
                        <div class="modal-footer" style="text-align: left;">
                            <button class="btn btn-md bg-green m-r-10" data-toggle="modal"  data-target="#operation" onclick="opt(2)"><span>Complete</span></button>
							<button class="btn btn-md bg-purple m-r-10" data-toggle="modal"  data-target="#operation" onclick="opt(1)"><span>Roll back</span></button>
						    
							<button type="button" class="btn btn-md" data-dismiss="modal"><span>Back</span></button>
							
                        </div> 
                    </div> 
                </div> 
            </div> 




			<div class="modal fade" id="operation" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-sm" role="document">
                    <div class="modal-content" id="ttip">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                                <h4 class="modal-title" id="tt">Edit Orders</h4>
                        </div>
			
                        <form action="updator.php" method="post" class="modal-body">
				           
							<div class="form-group" id="psbox" style="display: none">
                                <label for="ps" style="color: #4EB152">Price / RM</label>
                                <input id="ps" type="number" class="form-control" name="ps" placeholder="The price of this order">
                            </div>
							<p style="color: #4EB152">The money you actually reviced from the customer 实际收款</p>
						    <br>
			                <div class="form-group">
                                <span class="input-group-addon bg-green" id="basic-addon3">Action</span>
                                <input id="des" type="password" class="form-control" name="Action" placeholder="Code">
                            </div>
				
            				<input style="display: none" id="mdzz" type="submit" value="Submit" />
		            		<input type="hidden" id="Door" name="Door" value="1">
	            			<input type="hidden" id="OID" name="OID" value="0">
							<input type="hidden" id="ways" name="ways" value="App">
                        
			
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-md bg-green"><span>Submit</span></button>
                        </div>
						</form>
                    </div>
                </div>
            </div>


</div>
</div>


<script src="js/jquery.min.js"></script>
<script src="js/vue.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script type="text/javascript" src="js/datatables/datatables.min.js"></script>
<script>


var ep="";
var position="";
var pss = 0;
function saw(name,phone,contact,price,shop,data,time,express,id,wz){
	$('#name').text(name);
	$('#contact').text(contact);
	$('#phone').text(phone);
	pss=price;
	$('#price').text(price);
	$('#data').html(data);
	$('#time').text(time);
	$('#express').text(express);
	$('#wz').text(wz);
	position = wz;
	ep=express;
	$('#OID').val(id);
	$('#ways').val(contact);
}




function opt(kind){
	if(kind == 1){
		$('#psbox').hide();
		$('#tt').text('Roll it back');
		$('#Door').val('0');
	}else{
		$('#ps').val(pss);
		$('#psbox').show();
		$('#tt').text('complete the order');
	    $('#Door').val('2');
	}
}

</script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>

</body>

</html>