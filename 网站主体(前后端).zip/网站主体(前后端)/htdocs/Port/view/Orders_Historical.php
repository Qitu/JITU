﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek. edited by qitu">
    <title>Historical Order</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-green.css">
    <link rel="stylesheet" type="text/css" href="css/datatables/datatables.min.css">    
    <link rel="stylesheet" href="css/nanoscroller.css">
	
	<style>
	    .contact{
			font-weight: 500; color: #4EB152
		}
	</style>
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
    <h1 class="dash-title">History</h1>   
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
          <li><a href="#">Order</a></li>
          <li><a href="#" class="active">History</a></li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3>Order list</h3>
            </div>
            <div class="panel-body m-t-0">
            <div class="table-responsive">
            <table id="order-table" class="table table-striped">
            <thead>
                <tr>
				    <th>ID</th>
				    <th>Date</th>
                    <th>INFO</th>
                    <th id="wwz">Location</th>
					<th>Status</th>
                </tr>
            </thead>
            <tbody id="info">
                <?php echo $view; ?>			
            </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>



            <div class="modal fade" id="action" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                            <h4 class="modal-title" id="myModalLabel">Goods detail</h4>
                        </div> 
                        <div class="modal-body">
						
						    
                                <p>UserName： <span id="name">...</span></p>
								<p>Contact： (<span id="contact">...</span>) <span id="phone">...</span></p>
								<p>Date： <span id="time">...</span></p>
								<p>Deliver： <span id="express">...</span></p>
								<br>
								<p style="font-weight: 700">Goods：</p>
								<div id="data">...</div>
								<br>
								<p>RM <b id="price">0.00</b></p>
						</div> 
                        <div class="modal-footer" style="text-align: left;">
							<button type="button" class="btn btn-md" data-dismiss="modal"><span>Close</span></button>
							
                        </div> 
                    </div> 
                </div> 
            </div> 


        



</div>
</div>


<script src="js/jquery.min.js"></script>
<script src="js/vue.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script type="text/javascript" src="js/datatables/datatables.min.js"></script>
<script>


var ep="";
var position="";
function saw(name,phone,contact,price,shop,data,time,express,wz){
	$('#name').text(name);
	$('#contact').text(contact);
	$('#phone').text(phone);
	$('#price').text(price);
	$('#data').html(data);
	$('#time').text(time);
	$('#express').text(express);
	$('#wz').text(wz);
	position = wz;
	ep=express;
}



$(document).ready(function() {
"use strict";
    $('#order-table').DataTable({
        "columnDefs": [{
        "targets": 4,
        "orderable": false
        }]
    });
	$("#wwz").click();
});
</script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>

</body>

</html>