﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Port - Lobby</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
	    <link rel="stylesheet" type="text/css" href="css/theme-green.css">
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
    <h1 class="dash-title">Lobby</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#" class="active">Lobby </a></li>
        </ol>
		
        <br>
		<div class="alert alert-warning" role="alert">To all the portmans, pls set alarm clock at 12am everyday to inform you to check the pending orders.
		<br><br>
		请设置一个每天上午12点的闹钟来提醒自己检测预备订单</div>
		
		<a href="http://jitu.fun/Port/payment.jpg" style="color: #1c87da; text-decoration: underline">Wechat/Alipay Recive money QR code - 网上收款码</a>
		<br>
		
		
		<div class="row">
		
		    <div class="col-md-4 col-sm-4 col-xs-6"  style="margin-top: 20px">
                <a href="http://jitu.fun/Port/?1" class="panel m-t-0">
                <div class="panel-heading bg-purple font-white"><h3>Panding</h3></div>
                    <div class="panel-body panel-content" style="background: #FFF">
                        <p>Order confirmation.</p>
                    </div>
                </a>
            </div>
			
			<div class="col-md-4 col-sm-4 col-xs-6"  style="margin-top: 20px">
                <a href="http://jitu.fun/Port/?2" class="panel m-t-0">
                <div class="panel-heading bg-orange  font-white"><h3>Ongoing</h3></div>
                    <div class="panel-body panel-content" style="background: #FFF">
                        <p>You are working on</p>
                    </div>
                </div>
           
			
			<div class="col-md-4 col-sm-4 col-xs-6" style="margin-top: 20px">
                <a href="http://jitu.fun/Port/?3" class="panel m-t-0">
                <div class="panel-heading bg-green font-white"><h3>Historical</h3></div>
                    <div class="panel-body panel-content" style="background: #FFF">
                        <p>Historical order...</p>
                    </div>
                </div>
        </div>
			
		</div>
    </div>
</div>

</div>


<script src="js/jquery.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
</body>

</html>