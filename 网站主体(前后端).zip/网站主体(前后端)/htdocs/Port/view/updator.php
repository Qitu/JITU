<?php

 session_start(); 
header("Content-type: text/html; charset=utf-8");
require_once './safe.php';  
require_once 'Timer.php'; 
   if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	   if(canDo()){
	   if(isset($_SESSION['Atoken'])){
	   if(isset($_POST["Door"])){
		   $postID = filter($_POST["Door"]);
		   switch($postID){
			   
			   //小手轻轻放回Pending
			   case '0':
			        if(isset($_POST["OID"]) && isset($_POST["Action"]) && isset($_POST["ways"])){
					   $OID = filter($_POST["OID"]);
					   $Action = filter($_POST["Action"]);
					   $token = filter($_SESSION['Atoken']);
					   define('IN_SYS', TRUE);
					   require_once '../Database/Mysql.php';
                       
						   if($sql = connectSQL()){
							$z=$sql->query("SELECT `KEY` FROM Port WHERE Action='".$Action."' AND `KEY`='".$token."'");
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
								
								$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
                                $password = ''; 
                                for ( $i = 0; $i < 32; $i++ ) { 
						            $password .= $chars[ mt_rand(0, strlen($chars) - 1) ]; 
						        }
								
								$v="UPDATE Port SET `KEY`='".$password."' WHERE `KEY`='".$token."'";
								if ($sql->query($v)){
									$_SESSION['Atoken'] = $password;
									if($_POST["ways"] == 'App') $z="UPDATE AppOrder SET `status`=0 WHERE ID='".$OID."'";
								    else $z="UPDATE WebOrder SET `Status`=0 WHERE OrderID='".$OID."'";
								    if ($sql->query($z)){
									    header("Location:https://jitu.fun/Port?2");
									    exit;
								    }else include_once '500.html';
								}else include_once '500.html';
								
							}else exit('Wrong action token');
						   }else exit('Server busy');
					}else exit('data lost, Your visits have been recorded');
			   break;
			   
			   
			   //一怒之下放入进行中
			   case '1':
			        if(isset($_POST["OID"]) && isset($_POST["Action"]) && isset($_POST["ways"]) && isset($_POST["loc"])){
					   $OID = filter($_POST["OID"]);
					   $loc = filter($_POST["loc"]);
					   $Action = filter($_POST["Action"]);
					   $token = filter($_SESSION['Atoken']);
					   define('IN_SYS', TRUE);
					   require_once '../Database/Mysql.php';                       
                       
						   if($sql = connectSQL()){
                	        
							$z=$sql->query("SELECT `PID` FROM Port WHERE Action='".$Action."' AND `KEY`='".$token."'");
                	          if($z->num_rows>0){
                			    $row = $z->fetch_row();
								
								$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
                                $password = ''; 
                                for ( $i = 0; $i < 32; $i++ ) { 
						            $password .= $chars[ mt_rand(0, strlen($chars) - 1) ]; 
						        }
								
								$total = 0;
								if($row[0]==0) $may = '';
								else $may =  ' AND Port='.$row[0];
								if($_POST["ways"] == 'App') $s="SELECT `goods`,`Express`,`Packing` FROM `AppOrder`,`stores` WHERE SID=AppOrder.store".$may." AND ID='".$OID."'";
								else $s="SELECT `Data`,`Express`,`Packing` FROM `WebOrder`,`stores` WHERE SID=ShopID".$may." AND OrderID='".$OID."'";
								
								$result=$sql->query($s);
                	            if($result->num_rows>0){
                			        $goods = $result->fetch_row();
								    $dt = '';
									$GDATA = array();
									$express = $goods[1] + $goods[2];
								    $ar = explode(".",$goods[0]);
								    for($i=0;$i<count($ar);$i++){
										$arr = explode(",",$ar[$i]);
										if(count($arr) == 2) {
										    if($dt=='') $dt = 'GID='.$arr[0];
											else $dt .= ' OR GID='.$arr[0];
											
											if(isset($GDATA[$arr[0]])) $GDATA[$arr[0]] = (int) $GDATA[$arr[0]] + (int) $arr[1];
											else $GDATA[$arr[0]]=(int) $arr[1];
										}else if(count($arr) == 3) {
											if($dt=='') $dt = 'GID='.$arr[0];
											else $dt .= ' OR GID='.$arr[0];
											
											if(isset($GDATA[$arr[0]])) $GDATA[$arr[0]] = (int) $GDATA[$arr[0]] + (int) $arr[2];
											else $GDATA[$arr[0]]=(int) $arr[2];
										}
									}
									
									$c=$sql->query("SELECT GID,Price FROM Goods WHERE ".$dt);
									if($c->num_rows>0){
										while($puy = $c->fetch_row()){
											if(isset($GDATA[$puy[0]])) $total = $total + ($GDATA[$puy[0]] * (float)$puy[1]);
										}
										$total = $total + $express;
										$v="UPDATE Port SET `KEY`='".$password."' WHERE `KEY`='".$token."'";
											if ($sql->query($v)){
												$_SESSION['Atoken'] = $password;
												
												
												if($_POST["ways"] == 'App') $z="UPDATE AppOrder SET `status`=1,`price`=".$total." WHERE ID='".$OID."'";
												else $z="UPDATE WebOrder SET `Status`=1,`Detail`='".$loc."',`Price`=".$total." WHERE OrderID='".$OID."'";
												
												if ($sql->query($z)){
													header("Location:https://jitu.fun/Port?1");
													exit;
												}else include_once '500.html';
											}else include_once '500.html';
									}else exit('Dirty data'.$dt);
									
							    }exit('Missing order');
								
								
							 }else exit('Wrong action token');
						   }else exit('Server busy');
					}else exit('data lost, Your visits have been recorded');
			   break;
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   case '2':
			       if(isset($_POST["OID"]) && isset($_POST["Action"]) && isset($_POST["ways"]) && isset($_POST["ps"])){
					   $OID = filter($_POST["OID"]);
					   $Action = filter($_POST["Action"]);
					   $ps = filter($_POST["ps"]);
					   $token = filter($_SESSION['Atoken']);
					   define('IN_SYS', TRUE);
					   require_once '../Database/Mysql.php';                       
                       
						   if($sql = connectSQL()){
							$z=$sql->query("SELECT `KEY` FROM Port WHERE Action='".$Action."' AND `KEY`='".$token."'");
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
								
								$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
                                $password = ''; 
                                for ( $i = 0; $i < 32; $i++ ) { 
						            $password .= $chars[ mt_rand(0, strlen($chars) - 1) ]; 
						        }
								
								$v="UPDATE Port SET `KEY`='".$password."' WHERE `KEY`='".$token."'";
								if ($sql->query($v)){
									$_SESSION['Atoken'] = $password;
									if($_POST["ways"] == 'App') $z="UPDATE AppOrder SET `status`=2,`price`='".$ps."' WHERE ID='".$OID."'";
								    else $z="UPDATE WebOrder SET `Status`=2,`Price`='".$ps."' WHERE OrderID='".$OID."'";
								    if ($sql->query($z)){
									    header("Location:https://jitu.fun/Port?2");
									    exit;
								    }else include_once '500.html';
								}else include_once '500.html';
								
							}else exit('Wrong action token');
						   }else exit('Server busy');
					}else exit('data lost, Your visits have been recorded');
			   break;
			   
			   //吓得取消了这个订单
			   case '3':
			       if(isset($_POST["OID"]) && isset($_POST["Action"]) && isset($_POST["ways"])){
					   $OID = filter($_POST["OID"]);
					   $Action = filter($_POST["Action"]);
					   $token = filter($_SESSION['Atoken']);
					   define('IN_SYS', TRUE);
					   require_once '../Database/Mysql.php';                       
                       
						   if($sql = connectSQL()){
							$z=$sql->query("SELECT `KEY` FROM Port WHERE Action='".$Action."' AND `KEY`='".$token."'");
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
								
								$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
                                $password = ''; 
                                for ( $i = 0; $i < 32; $i++ ) { 
						            $password .= $chars[ mt_rand(0, strlen($chars) - 1) ]; 
						        }
								
								$v="UPDATE Port SET `KEY`='".$password."' WHERE `KEY`='".$token."'";
								if ($sql->query($v)){
									$_SESSION['Atoken'] = $password;
									if($_POST["ways"] == 'App') $z="UPDATE AppOrder SET `status`=3 WHERE ID='".$OID."'";
								    else $z="UPDATE WebOrder SET `Status`=3 WHERE OrderID='".$OID."'";
								    if ($sql->query($z)){
									    header("Location:https://jitu.fun/Port?1");
									    exit;
								    }else include_once '500.html';
								}else include_once '500.html';
								
							}else exit('Wrong action token');
						   }else exit('Server busy');
					}else exit('data lost, Your visits have been recorded');
			   break;


			   
			   case '':
			   exit;
			   break;
		   }
	   }else exit('exm ????');
	   }else{
		    session_destroy();
			header("Location:https://jitu.fun/Port?0");
	   }
	   }else exit('Slowly please ??');
   }else exit('faild');

?>
 
