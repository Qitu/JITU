﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="HTML5 Template">
    <meta name="author" content="Andy">
    <title>Login - Port</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
	    <link rel="stylesheet" type="text/css" href="css/theme-green.css">
    <link rel="stylesheet" href="css/nanoscroller.css">
	
	<script type='text/javascript'>
        var code ;
        function createCode(){
             code = "";   
             var codeLength = 4;
             var checkCode = document.getElementById("code");   
             var random = new Array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R',  
             'S','T','U','V','W','X','Y','Z');
             for(var i = 0; i < codeLength; i++) {
                var index = Math.floor(Math.random()*36);
                code += random[index];
            }  
            checkCode.value = code;
        }
  
        function validate(){
				var u = document.getElementById("inputEmail").value;
				var p = document.getElementById("inputPassword").value;
				localStorage["username"]=u; 
				localStorage["psw"]=p; 
				document.getElementById("bb").click();
				return true;           
        }
        
        var username = localStorage.getItem("username");
			if (username != "" && username != null){
				document.getElementById("inputEmail").value = username ;
			}
			var psw = localStorage.getItem("psw");
			if (psw != "" && psw != null){
				document.getElementById("inputPassword").value = psw ;
			}
        </script>
        <style type='text/css'>
        #code{
            font-family:Arial,宋体;
            font-style:italic;
            color:white;
            border:0;
            padding:2px 3px;
            letter-spacing:3px;
            font-weight:bolder;
			background:rgba(0,0,0,0)
        }
        </style>
</head>

<body class="bg-green">

<div id="login" >
<div class="container">
<div class="row">
    <div class="col-xs-12 content">
    <div class="panel login-form">
        <div class="panel-heading">
        </div>
        <div class="panel-body m-t-0">

        <form data-toggle="validator" action="?0" method="post">
		        <h3 style="text-align: center; color: black; font-weight: 550; font-size: 25px; margin-bottom: 10px;">PORT</h3>
				<p style="text-align: center; color: black;  margin-bottom: 16px; color: red"><?php echo $tip ?></p>
                <div class="form-group">
                    <label for="inputEmail" class="control-label">Account</label>
                    <div class="input-group">
                        <span class="input-group-addon bg-green" id="basic-addon1"><i class="fa fa-user" aria-hidden="true"></i></span>
                        <input  type="text" class="form-control" name="account" id="inputEmail" placeholder="Account" data-error="Invalid value" required>
                    </div>
                    <div class="help-block with-errors"></div>
                </div>

                <div class="form-group">
                    <label for="inputPassword" class="control-label">Token</label>                    
                    <div class="input-group">
                        <span class="input-group-addon bg-green" id="basic-addon2"><i class="fa fa-key" aria-hidden="true"></i></span>
                        <input type="password" data-minlength="6" class="form-control" name="token" id="inputPassword" placeholder="Password" required>
                    </div>
                </div>
				
				<br>
				
				<!--<div class="form-group">
                <div class="input-group">   
                    <input type="text" data-minlength="4" class="form-control" id = "input" id="inputPassword" autocomplete="off" placeholder="Code 验证码" required>
					<span class="input-group-addon bg-p" id="basic-addon2"><input type="button" id="code" onclick="createCode()" style="width:60px" title='Change Code' /></span>
                </div>
                </div>-->
				
				<br>
                <div class="form-group">
				    <div onclick="validate()" class="btn btn-md bg-green"><span>Sign in</span></div>
                    <button id="bb" style="display: none" type="submit" class="btn btn-md bg-green"><span>Sign in</span></button>
                </div>
            </form>

        </div>
    </div>
    </div>
</div>
</div>
</div>


<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/validator.js"></script>
</body>
<script>
window.onload = function(){
    //createCode();
};
</script>
</html>