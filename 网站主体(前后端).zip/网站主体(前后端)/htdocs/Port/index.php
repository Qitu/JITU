<?php
   
   session_start(); //启用 session
   
   
   header("Content-type: text/html; charset=utf-8"); //启用中文支持
   
   require_once './safe.php'; //安全系统  
   require_once '../Database/Timer.php'; //延时系统
   
	if($_SERVER['HTTP_HOST'] == "jitu.fun"){ //简单安全判断
		if(canDo()){
			define('IN_SYS', TRUE); 
			require_once '../Database/Mysql.php'; //开启数据库模块
		    if(isset($_POST["account"]) && isset($_POST["token"])){ //尝试登入
			    $account = filter($_POST["account"]);
                $token = filter($_POST["token"]);
				if($sql = connectSQL()){
					$z=$sql->query("SELECT 
					                    `KEY`
									FROM 
									    Port 
									WHERE
										Account='".$account."' AND Token='".$token."'");	       
                	    if($z->num_rows>0){
                			$row = $z->fetch_row();
							$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
                            $password = ''; 
                            for ( $i = 0; $i < 32; $i++ ) { 
						        $password .= $chars[ mt_rand(0, strlen($chars) - 1) ]; 
						    }
							//echo $row[0];
							$z = "UPDATE `Port` SET `KEY`='".$password."' WHERE `KEY`='".$row[0]."'";
                            if ($sql->query($z)) {
								//店铺信息 + 获取数据
								$_SESSION['Atoken'] = $password;
								$_SESSION['Account'] = $account;
								echo "Please wait....";
								header("refresh:2;url=http://jitu.fun/Port?2");
								exit;
								
							}else echo 'Server busy...';							
						}else{
							//回登陆
							$tip = 'Login faild, your password or username is  incorrect.';
							include_once 'view/Login.php';
						}
				}else echo 'Network connected error';
		    }else if(isset($_SESSION['Atoken']) && isset($_SESSION['Account'])){
				$token = filter($_SESSION['Atoken']);
				$account = filter($_SESSION['Account']);
	            $now = filter($_SERVER["QUERY_STRING"]); //可编辑字符串安全化
		        switch($now){
					
			        case '0':
						include_once 'view/Home.php';
			        break;
					
					case '1':
					    if($sql = connectSQL()){ 
							$z=$sql->query("SELECT `PID` FROM Port WHERE `KEY`='".$token."' AND Account='".$account."'");
							if($z->num_rows>0){
								
								$port = $z->fetch_row();
								$GDATA = array(); $order = array();
								$QDT=''; $view = '';
								
								
								if($port[0] == 0) $qstt = "SELECT `ID`,`client_info`,`store`,`date`,`status`,`goods`,`webClient` FROM `AppOrder` WHERE status=0";
					            else $qstt = "SELECT `ID`,`client_info`,`store`,`date`,`status`,`goods`,`webClient` FROM `AppOrder` WHERE status=0 AND Port=".$port[0];
								$z=$sql->query($qstt);	       
                	            if($z->num_rows>0){
									while($row = $z->fetch_row()){
										$info = array('--', '--','--', 'App');
										$ar = explode(";",$row[1]);
									    if($row[6] != null){
											$loc = $row[6];
											$info = array($row[6], '', $loc,'Web');
										}else if(count($ar) == 2){
											$loc = $ar[0];
										    $arr = explode(",",$ar[1]);
										    if(count($arr) > 1) $info = array($arr[0], $arr[1], $loc,'App');
									    }
										$dt = '';
										$ar = explode(".",$row[5]);
									    for($i=0;$i<count($ar);$i++){
										    $arr = explode(",",$ar[$i]);
										    if(count($arr) == 2) {
												$dt .= $arr[0].",".$arr[1].".";
											    //添加需要查询的商品名
												$has = false;
												for($o=0;$o<count($GDATA);$o++){
													if($arr[0] == $GDATA[$o]) $has = true;
												}
												if(!$has) $GDATA[$arr[0]] = '--';
											}
									    }
										$order['0'.$row[0]] = array($info[0],$info[1],$info[3],$row[2],$dt,$row[3],$row[0],$row[4],$info[2]);
									}
								}
								$Gindex = 0;
								foreach ($GDATA as $key => $value) {
									if($Gindex == 0) $QDT .= 'GID='.$key.' ';
									else $QDT .= 'OR GID='.$key.' ';
									$Gindex++;
								}
								$c=$sql->query("SELECT EN_Name,ZH_Name,GID FROM Goods WHERE ".$QDT);
								if($c->num_rows>0){
									while($puy = $c->fetch_row()){
										$GDATA[$puy[2]] = str_replace('_', ' ', $puy[0].'('.$puy[1].')');
									}
								}
								foreach ($order as $value) {
									$Udt = '';
										$ar = explode(".",$value[4]);
									    for($i=0;$i<count($ar);$i++){
										    $arr = explode(",",$ar[$i]);
										    if(count($arr) == 2) {
											    $Udt .= '<p>'.$GDATA[$arr[0]].' x'.$arr[1].'</p>';
											}
									    }
										//联系人   手机号   方式   店铺   商品   时间     ID    状态    地点
								        $view .= '<tr>  
                                            <th scope="row">'.$value[6].'</th> 
											<td>'.$value[1].' '.$value[0].'</td>
											<td>
											<button type="button" class="btn btn-xs bg-green" data-toggle="modal" data-target="#operation" onclick="opt(1,\''.$value[6].'\',\''.$value[2].'\',\''.$value[8].'\')"><span>Process</span></button>
											<button type="button" class="btn btn-xs bg-orange" data-toggle="modal" data-target="#operation" onclick="opt(2,\''.$value[6].'\',\''.$value[2].'\',88)"><span>Cancel</span></button>
											</td>
											<td><a data-toggle="modal" data-target="#action" onclick="saw(\''.$Udt.'\')" style="font-weight: 700; color: #4EB152">Check</a></td>
											<td>'.$value[5].'</td> 
                                          </tr>';
								}
								
								include_once 'view/Orders_Pending.php';
				            }else{
								//$tip = $token;
							    session_destroy();
				                $tip = 'Security Token has been updated, please relogin.';
				                include_once 'view/Login.php';
						    }
						}else echo 'Network connected error';
					break;
					
					
					
					case '2':
					    if($sql = connectSQL()){
							$z=$sql->query("SELECT `PID` FROM Port WHERE `KEY`='".$token."' AND Account='".$account."'");
							if($z->num_rows>0){
								
								$port = $z->fetch_row();
								$GDATA = array(); $order = array();
								$QDT=''; $view = '';
								
								
								if($port[0] == 0) $qstt = "SELECT `ID`,`client_info`,`price`,`store`,`date`,`deliver`,`goods`,`webClient` FROM `AppOrder` WHERE status=1";
					            else $qstt = "SELECT `ID`,`client_info`,`price`,`store`,`date`,`deliver`,`goods`,`webClient` FROM `AppOrder` WHERE status=1 AND Port=".$port[0];
					            
								$z=$sql->query($qstt);	       
                	            if($z->num_rows>0){
									while($row = $z->fetch_row()){
										$info = array('--', '--','--', 'Web');
										$ar = explode(";",$row[1]);
										
										if($row[7] != null){
											$loc = $row[7];
											$info = array('WebClient', $row[7], $loc,'Web');
										}else if(count($ar) == 2){
											$loc = $ar[0];
										    $arr = explode(",",$ar[1]);
										    if(count($arr) > 1) $info = array($arr[0], $arr[1], $loc,'App');
									    }
										$dt = '';
										$ar = explode(".",$row[6]);
									    for($i=0;$i<count($ar);$i++){
										    $arr = explode(",",$ar[$i]);
										    if(count($arr) == 2) {
												$dt .= $arr[0].",".$arr[1].".";
											    //添加需要查询的商品名
												$has = false;
												for($o=0;$o<count($GDATA);$o++){
													if($arr[0] == $GDATA[$o]) $has = true;
												}
												if(!$has) $GDATA[$arr[0]] = '--';
											}
									    }
										$order['0'.$row[0]] = array($info[0],$info[1],$info[3],$row[2],$row[3],$dt,$row[4],$row[5],$row[0],$info[2]);
									}
								}
								$Gindex = 0;
								foreach ($GDATA as $key => $value) {
									if($Gindex == 0) $QDT .= 'GID='.$key.' ';
									else $QDT .= 'OR GID='.$key.' ';
									$Gindex++;
								}
								//var_dump($QDT);
									
								$c=$sql->query("SELECT EN_Name,ZH_Name,GID FROM Goods WHERE ".$QDT);
								if($c->num_rows>0){
									while($puy = $c->fetch_row()){
										$GDATA[$puy[2]] = str_replace('_', ' ', $puy[0].'('.$puy[1].')');
									}
								}
								foreach ($order as $value) {
									$Udt = '';
										$ar = explode(".",$value[5]);
									    for($i=0;$i<count($ar);$i++){
										    $arr = explode(",",$ar[$i]);
										    if(count($arr) == 2) {
											    $Udt .= '<p>'.$GDATA[$arr[0]].' x'.$arr[1].'</p>';
											}
									    }
										//联系人    电话    方式      价钱      店铺      商品      时间     送货员     ID      位置
								        $view .= '<tr>  
                                            <th>'.$value[8].'</th> 
                                            <td scope="row" class="lct">'.$value[9].'</td>
											<td>'.$value[3].'</td>
											<td><a data-toggle="modal" data-target="#action" onclick="saw(\''.$value[0].'\',\''.$value[1].'\',\''.$value[2].'\',\''.$value[3].'\',\''.$value[4].'\',\''.$Udt.'\',\''.$value[6].'\',\''.$value[7].'\',\''.$value[8].'\',\''.$value[9].'\')" style="font-weight: 500; color: #4EB152">'.$value[0].'</a></td> 
                                          </tr>';
								}			
								include_once 'view/Orders_Ongoing.php';
				            }else{
								//$tip = $token;
							    session_destroy();
				                $tip = 'Security Token has been updated, please relogin.';
				                include_once 'view/Login.php';
						    }
						}else echo 'Network connected error';
					break;
					
					
					
					case '3':
                	    if($sql = connectSQL()){
							$z=$sql->query("SELECT `PID` FROM Port WHERE `KEY`='".$token."' AND Account='".$account."'");
							if($z->num_rows>0){
								
								$port = $z->fetch_row();
								$GDATA = array(); $order = array();
								$QDT=''; $view = '';

								
								if($port[0] == 0) $qstt = "SELECT `ID`,`client_info`,`price`,`store`,`date`,`deliver`,`status`,`goods` FROM `AppOrder` WHERE status>1";
					            else $qstt = "SELECT `ID`,`client_info`,`price`,`store`,`date`,`deliver`,`status`,`goods` FROM `AppOrder` WHERE status>1 AND Port=".$port[0];
					            
								$z=$sql->query($qstt);	       
                	            if($z->num_rows>0){
									while($row = $z->fetch_row()){
										$info = array('undefine', 'undefine','undefine', 'Phone');
										$ar = explode(";",$row[1]);
									    if(count($ar) == 2){
											$loc = $ar[0];
										    $arr = explode(",",$ar[1]);
										    if(count($arr) > 1) $info = array($arr[0], $arr[1], $loc,'App');
									    }
										$dt = '';
										$ar = explode(".",$row[7]);
									    for($i=0;$i<count($ar);$i++){
										    $arr = explode(",",$ar[$i]);
										    if(count($arr) == 2) {
												$dt .= $arr[0].",".$arr[1].".";
											    //添加需要查询的商品名
												$has = false;
												for($o=0;$o<count($GDATA);$o++){
													if($arr[0] == $GDATA[$o]) $has = true;
												}
												if(!$has) $GDATA[$arr[0]] = '--';
											}
									    }
										$order['0'.$row[0]] = array($info[0],$info[1],$info[3],$row[2],$row[3],$dt,$row[4],$row[5],$row[0],$row[6],$info[2]);
									}
								}
								$Gindex = 0;
								foreach ($GDATA as $key => $value) {
									if($Gindex == 0) $QDT .= 'GID='.$key.' ';
									else $QDT .= 'OR GID='.$key.' ';
									$Gindex++;
								}
								//var_dump($QDT);
									
								$c=$sql->query("SELECT EN_Name,ZH_Name,GID FROM Goods WHERE ".$QDT);
								if($c->num_rows>0){
									while($puy = $c->fetch_row()){
										$GDATA[$puy[2]] = str_replace('_', ' ', $puy[0].'('.$puy[1].')');
									}
								}
								foreach ($order as $value) {
									$Udt = '';
									$st='<span class="label" style="line-height: 65px"> --- ';
									if($value[9] == "2") $st='<span class="label label-success" style="line-height: 65px">Finished';
									else if($value[9] == "3") $st='<span class="label label-warning" style="line-height: 65px">Canceled';
										$ar = explode(".",$value[5]);
									    for($i=0;$i<count($ar);$i++){
										    $arr = explode(",",$ar[$i]);
										    if(count($arr) == 2) {
											    $Udt .= '<p>'.$GDATA[$arr[0]].' x'.$arr[1].'</p>';
											}
									    }
								        $view .= '<tr>
										    <th scope="row">'.$value[8].'</th>
										    <td>'.$value[6].'</td>
											<td><a data-toggle="modal" data-target="#action" onclick="saw(\''.$value[0].'\',\''.$value[1].'\',\''.$value[2].'\',\''.$value[3].'\',\''.$value[4].'\',\''.$Udt.'\',\''.$value[6].'\',\''.$value[7].'\',\''.$value[8].'\')" class="contact">'.$value[0].', '.$value[1].'</a></td> 
                                            <td><p>'.$value[10].'</p></td>
											<td>'.$st.'</span></td>
										  </tr>';
								}			
								include_once 'view/Orders_Historical.php';
				            }else{
								//$tip = $token;
							    session_destroy();
				                $tip = 'Security Token has been updated, please relogin.';
				                include_once 'view/Login.php';
						    }
						}else echo 'Network connected error';
					break;
					
					
					case '4':
					    include_once 'view/No_Data.php';	
					break;
					
					case '5':
					    include_once 'view/Statistic.php';	
					break;
					
					
					
					case 'view/store_clause':
					    //PORT条款
						echo '...';
					break;
					
					
					
					case 'view/reward_clause':
					    //奖惩条款
						echo '...';
					break;
					
					
					
					case 'Logout':
					    session_destroy();
						//回登陆
				        $tip = '';
				        include_once 'view/Login.php';
					break;
					
					
					default:
				        include_once '404.html';
					break;
		        }
		
		    }else{
				//回登陆
				$tip = '';
				include_once 'view/Login.php';
		    }
		}else echo 'Slowly please';
		
	
    }else{
       echo '505';
    }

?>