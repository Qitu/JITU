<?php
   
   session_start(); //启用 session
   
   
   header("Content-type: text/html; charset=utf-8"); //启用中文支持
   
   require_once './safe.php'; //安全系统  
   require_once '../Database/Timer.php'; //延时系统
   
	if($_SERVER['HTTP_HOST'] == "jitu.fun"){ //简单安全判断
		if(canDo()){
			define('IN_SYS', TRUE); 
			require_once '../Database/Mysql.php'; //开启数据库模块
		    if(isset($_POST["account"]) && isset($_POST["token"])){ //尝试登入
			    $account = filter($_POST["account"]);
                $token = filter($_POST["token"]);
				if($sql = connectSQL()){
					$z=$sql->query("SELECT 
					                    `KEY`
									FROM 
									    Official
									WHERE
										Account='".$account."' AND Token='".$token."'");	       
                	    if($z->num_rows>0){
                			$row = $z->fetch_row();
							$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
                            $password = ''; 
                            for ( $i = 0; $i < 32; $i++ ) { 
						        $password .= $chars[mt_rand(0, strlen($chars) - 1)]; 
						    }
							//echo $row[0];
							$z = "UPDATE `Official` SET `KEY`='".$password."' WHERE `KEY`='".$row[0]."'";
                            if ($sql->query($z)) {
								$_SESSION['Otoken'] = $password;
							    //开大厅 + 获取数据
								echo 'Please wait...';	
							    header("refresh:2;url=http://jitu.fun/Official/?0");
								exit;
							}else echo 'Server busy...';							
						}else{
							//回登陆
							$tip = 'Login faild, can not find the account';
							include_once 'view/Login.php';
						}
				}else echo 'Network connected error';
		    }else if(isset($_SESSION['Otoken'])){
				$_SESSION['Otoken'] = filter($_SESSION['Otoken']);
	            $now = filter($_SERVER["QUERY_STRING"]); //可编辑字符串安全化
		        switch($now){
					
					
			        case '0':
						if($sql = connectSQL()){
					        $z=$sql->query("SELECT 
							                    Moment.MomentID,Moment.Content,Moment.Like,TopicEN
											FROM 
											    Moment,Official,Moment_Topic WHERE Official.KEY='".$_SESSION['Otoken']."' AND Official.Client=Moment.SenderID AND (TopicIDs = TopicID OR TopicIDs = 0) ORDER BY Moment.MDate desc");	       
                	        if($z->num_rows>0){
								$mb=''; $ct=0;
								while ($value = $z->fetch_row()) {
									$ct++;
									$mb .= '<div class="col-md-3 col-sm-4 col-xs-12 " style="margin-top: 40px">
									<div class="panel m-t-0" onclick="detail(\"'.$value[0] .'\")">
									<div><img src="https://jitugoods.oss-ap-southeast-3.aliyuncs.com/moments/'.$value[0] .'-1.jpg"></div>
									<p class="ctt">'.$value[1].'</p>
									<div style="margin: 18px 8px; text-align: center"><span class="lable">'.$value[3].'</span></div>
									<br>
									</div>
									</div>';
							    }
							    
								include_once 'view/Dashboard.php';
						    }else include_once 'view/No_Data.php';
				        }else echo 'Network connected error';
			        break;
					
					
					
					case '1':
						if($sql = connectSQL()){
							if(true){
								include_once 'view/Editor.php';
						    }else{
								session_destroy();
							    $tip = 'User Token expired, please relogin';
							    include_once 'view/Login.php';
						    }
				        }else echo 'Network connected error';
					break;
					
					
					
					case '2':
				        echo 'Network connected error';
					break;
					

					
					case 'Logout':
					    session_destroy();
						//回登陆
				        $tip = '';
				        include_once 'view/Login.php';
					break;
					
					
					
					default:
					    $tip = '';
				        include_once '404.html';
					break;
		        }
		
		    }else{
				//回登陆
				$tip = '';
				include_once 'view/Login.php';
		    }
		}else echo 'Slowly please';
		
	
    }else{
       echo '505';
    }

?>