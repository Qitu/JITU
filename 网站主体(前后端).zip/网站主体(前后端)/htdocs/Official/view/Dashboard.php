﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Andy">
    <title>JITU - Official</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-orange.css"> 
    <link rel="stylesheet" href="css/nanoscroller.css">
	<style>
	    .tt{text-align: center; margin-top: 15px}
		img{width: 100%}
		.ctt{margin: 8px 12px; color: rgba(0,0,0,0.6);overflow : hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;}
		.go{ background: #FF9703; color: white; border-radius: 6px; margin: 18px 16px 8px; padding: 6px 12px}
		.lable{color: white; background: #fdb216; border-radius: 5em; padding: 6px 14px;}
	</style>
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<h3 class="tt">Result: <?php echo $ct;?></h3>
<div><a class="go">+ New Post</a></div>
<?php echo $mb; ?>


</div>
</div>
<br><br>

<script src="js/jquery.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
</body>

</html>