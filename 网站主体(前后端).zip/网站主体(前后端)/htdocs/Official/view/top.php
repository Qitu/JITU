<?php
   
   if(isset($_SESSION['own'])) $own = '<li><a href="?3">PreOrder</a></li>';
   else $own = '';
    echo '<div id="header-panel">
<nav class="navbar navbar-fixed-top">
<div class="container-fluid">
    
    <div id="navbar-header">

      <a class="navbar-brand" href="?0">
          <span class="logo-img"><!-- logo img <img src="img" alt=""> -->JT</span>
          <span class="logo-text hidden-xs hidden-sm">JITU - Official</span>
      </a> 
	  
    <ul class="nav navbar-nav">


    <li class="btn-menu hidden-xs hidden-sm"> <a id="menu-toggle" href="#" class="toggle"></a> </li>
    <li class="btn-menu hidden-md hidden-lg"> <a id="mobile-menu-toggle" href="#" class="toggle"></a> </li>

      </ul>
        <ul class="nav navbar-nav navbar-right">    
        <li class="dropdown user-menu">       
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <img src="img/admin.jpg" alt="" class="profile-img img-circle img-resposnive pull-left" style="width: 40px; height: 40px"> 
        <span class="hidden-xs">My</span> <span class="caret"></span></a>

        <ul class="dropdown-menu pull-right">
            <li><a href="?Logout"><i class="fa fa-sign-out" aria-hidden="true"></i>Log out</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>

<div id="navigation-panel" class=""> 
    <nav class="sidebar nano">

    <div class="clearfix"></div>

    <div id="#sidebar-navbar" class="sidebar-nav nano-content navbar-collapse ">
    <ul class="nav" id="side-menu">
    
    <li class="nav-header">functions</li>

    <li><a href="?0"><i class="fa fa-home" aria-hidden="true"></i> <span class="link-hide"> Moments </span></a></li>   

    <li><a href="?1" ><i class="fa fa-magic" aria-hidden="true"></i> <span class="link-hide"> New Post </span></a></li>
    

    <li><a href="?2"><i class="fa fa-wpforms" aria-hidden="true"></i> <span class="link-hide"> My Analysis </span></a>
    </li>

    </ul> 
    </div>
	
    </nav>
</div>';
	
?>