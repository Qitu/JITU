﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek">
    <title>New Post - Official</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-orange.css">    
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>

<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">New Post</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#">Moment</a></li>
          <li><a href="#" class="active">New Post</a></li>
        </ol>
    </div>
</div>

<form action="updator.php" method="post">

  <div class="row">
   
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3>POST BOX</h3>
                <p class="text-muted">To create a new post as a <code>Ofiiicial</code> moment</p>
            </div>
            <div class="panel-body m-t-0">

            <div class="form-group">
                <label class="col-sm-2 control-label">Language section:</label>
                <div class="col-sm-10">
                <select class="form-control">
                  <option>English</option>
                  <option>Chinese</option>
                </select>
                </div>
            </div>
			
			<div class="form-group" style="margin-top: 20px">
                <label class="col-sm-2 control-label">Topic</label>
                <div class="col-sm-10">
                <select class="form-control">
                  <option>aaaa</option>
                  <option>bbbb</option>
                </select>
                </div>
            </div>
			


            <div class="form-group">
                <label>Content</label>
                <textarea class="form-control" rows="15" name="ZH_info" placeholder="Your Text"><?php echo $row[1] ?></textarea>
            </div>
			
			
			<button type="submit" value="Submit" class="btn btn-md bg-green"><span>Post it !</span></button>

            </div>
        </div>
    </div>
	
  </div>
	
  
</form>	


</div>
</div>

<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/vue.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>

<script>
    var setting = <?php echo json_encode($_setting) ?>;
	var open = <?php echo $row[7]; ?>;
	
    var getFormatCode=function(strValue){
	    return strValue.replace(/\r\n/g, '<br/>').replace(/\n/g, '<br/>').replace(/\s/g, ' ');
	}
	
	
	if(open == 0){
		$('#zzzz').val(0);
	}else $('#zzzz').val(1);

	function _ajax(){
		if($('#zzzz').val() == 0){
		    $('#zzzz').val(1);
			mmp.status = 1;
		}else {
			$('#zzzz').val(0); 
		    mmp.status = 0;
		}
	}
	
	var info = new Vue({
		el: '#info',
        data: {
	            info: setting,
        }
    });
	
	var mmp = new Vue({
		el: '#status',
        data: {
	            status: open,
        }
    });
	

</script>
</body>

</html>