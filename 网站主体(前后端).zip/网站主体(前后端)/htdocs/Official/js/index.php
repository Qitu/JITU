<?php
   
   session_start(); //启用 session
   
   
   header("Content-type: text/html; charset=utf-8"); //启用中文支持
   
   require_once './safe.php'; //安全系统  
   require_once '../Database/Timer.php'; //延时系统
   
	if($_SERVER['HTTP_HOST'] == "jitu.fun"){ //简单安全判断
		if(canDo()){
			define('IN_SYS', TRUE); 
			require_once '../Database/Mysql.php'; //开启数据库模块
		    if(isset($_POST["account"]) && isset($_POST["token"])){ //尝试登入
			    $account = filter($_POST["account"]);
                $token = filter($_POST["token"]);
				if($sql = connectSQL()){
					$z=$sql->query("SELECT 
					                    `KEY`
									FROM 
									    Official
									WHERE
										Account='".$account."' AND Token='".$token."'");	       
                	    if($z->num_rows>0){
                			$row = $z->fetch_row();
							$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
                            $password = ''; 
                            for ( $i = 0; $i < 32; $i++ ) { 
						        $password .= $chars[mt_rand(0, strlen($chars) - 1)]; 
						    }
							//echo $row[0];
							$z = "UPDATE `Official` SET `KEY`='".$password."' WHERE `KEY`='".$row[0]."'";
                            if ($sql->query($z)) {
								$_SESSION['Otoken'] = $password;
							    //开大厅 + 获取数据
								echo 'Please wait...';	
							    header("refresh:2;url=http://jitu.fun/Official/?0");
								exit;
							}else echo 'Server busy...';							
						}else{
							//回登陆
							$tip = 'Login faild, can not find the account';
							include_once 'view/Login.php';
						}
				}else echo 'Network connected error';
		    }else if(isset($_SESSION['Otoken'])){
				$_SESSION['Otoken'] = filter($_SESSION['Otoken']);
	            $now = filter($_SERVER["QUERY_STRING"]); //可编辑字符串安全化
		        switch($now){
					
					
			        case '0':
						if($sql = connectSQL()){
					        $z=$sql->query("SELECT 
							                    Moment.MomentID,Moment.Content,Moment.Like
											FROM 
											    Moment,Official WHERE Official.KEY='".$_SESSION['Otoken']."' AND Official.Client=Moment.SenderID");	       
                	        if($z->num_rows>0){
								$mb=''; $ct=0;
								while ($value = $z->fetch_row()) {
									$ct++;
									$mb .= '<div class="col-md-6 col-sm-6 col-xs-12 " style="margin-top: 40px">
									<div class="panel m-t-0" onclick="detail(\"'.$value[0] .'\")">
									<div><img src="https://jitugoods.oss-ap-southeast-3.aliyuncs.com/moments/'.$value[0] .'-1.jpg"></div>
									<p class="ctt">'.$value[1].'</p>
									<br>
									</div>
									</div>';
							    }
							    
								include_once 'view/Dashboard.php';
						    }else include_once 'view/No_Data.php';
				        }else echo 'Network connected error';
			        break;
					
					
					
					case '1':
						if($sql = connectSQL()){
					        $z=$sql->query("SELECT 
							                    ZH_Name,ZH_Detail,EN_Name,EN_Detail,Supports,Phone,Express,Status,Style
											FROM 
											    stores,Shopkeeper WHERE Shopkeeper.Key='".$_SESSION['token']."' AND stores.SID=Shopkeeper.ShopID");	       
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
                                $_setting = array();
							    $__date = filter($row[4]);
							    $ar = explode("!",$__date);
							    if($__date != null && count($ar) > 0){
							        for($i=0;$i<count($ar);$i++){
								        $first = $ar[$i];//一级初始化
									    $second = explode("@",$first);//二级化时间
									    if(count($second) > 0){
									        $place = $second[0];//获取地点
									        $_setting[$place] = array(); 
								            for($b=1;$b<count($second);$b++){
										        $third = explode("#",$second[$b]);//三级化时间
											    $day = $third[0];//获取星期
											    $_setting[$place][$day] = array();
											    for($c=1;$c<count($third);$c++){
												    if($third[$c] != "") $_setting[$place][$day] =  $third[$c]; //获取具体时间
								                }
											//var_dump($_setting);
								            }
							            }
								    }
							    }
								//$row[3] = str_replace("_"," ",$row[3]);
								include_once 'view/Store_Editor.php';
						    }else{
							    //回登陆
								session_destroy();
							    $tip = '用户身份已在另一台设备上更新，请重新登陆';
							    include_once 'view/Login.php';
						    }
				        }else echo 'Network connected error';
					break;
					
					
					
					case '2':
					    //编辑商品 + 获取数据
						if($sql = connectSQL()){
					        $z=$sql->query("SELECT 
							                    ZH_Name,ZH_Size,ZH_info,ZH_Class,EN_Name,EN_Size,EN_info,EN_Class,Price,GID
											FROM 
											    Goods,Shopkeeper WHERE Shopkeeper.KEY='".$_SESSION['token']."' AND Goods.ShopID=Shopkeeper.ShopID");
							$view = '';
                	        if($z->num_rows>0){
								
                			    while($row = $z->fetch_row()){
									$view .= '<tr> 
                                                      <td>'.$row[4].'</td> 
                                                      <td>'.$row[8].'</td>		
                                                      <td>
						                                  <a style="margin-right: 8px;" data-toggle="modal" data-target="#myModal" onclick="Edit(&apos; '.$row[0].'&apos; ,&apos; '.$row[4].'&apos; ,&apos; '.$row[1].'&apos; ,&apos; '.$row[5].'&apos; ,&apos; '.$row[3].'&apos; ,&apos; '.$row[7].'&apos; ,&apos; '.$row[2].'&apos; ,&apos; '.$row[6].'&apos;  ,&apos; '.$row[9].'&apos; )" ><i class="fa fa-pencil" aria-hidden="true"></i></a>
						                                  <a data-toggle="modal" data-target="#myModa2" onclick="Del('.$row[9].')"><i class="fa fa-times" aria-hidden="true"></i></a>
					                                  </td>													  
													  <td>'.$row[7].'</td>

                                             </tr> ';
								}								
						    }
							include_once 'view/Goods_Editor.php';
				        }else echo 'Network connected error';
					break;
					
					
					
					
					case '4':
					    if($sql = connectSQL()){
					        //进行中订单 + 获取数据
							$z=$sql->query("SELECT 
							                    `KEY`
											FROM 
											    Shopkeeper WHERE Shopkeeper.Key='".$_SESSION['token']."'");	       
                	        if($z->num_rows>0){
								$view = array();
								$mmp = $z->fetch_row();
								
								
								$total = 0;
								$goods = array();
									
								$x= $sql->query("SELECT 
							                    GID,EN_Name,ZH_Name,Price
											FROM Goods,Shopkeeper WHERE Shopkeeper.Key='".$_SESSION['token']."' AND Goods.ShopID=Shopkeeper.ShopID");
						            
				                    if($x->num_rows>0){
									    $goods = array();
		                                while($mm = $x->fetch_row()){
											$nn = array($mm[0],$mm[1].'('.$mm[2].')',$mm[3]);
										    array_push($goods,$nn);
										}
									}
									
								
								
								$z=$sql->query("SELECT 
							                    AppOrder.ID,client_info,price,goods
											FROM 
											    AppOrder,Shopkeeper WHERE Shopkeeper.Key='".$_SESSION['token']."' AND AppOrder.store=Shopkeeper.ShopID AND AppOrder.status=1");	       
                	        	if($z->num_rows>0){
									$num = $num + $z->num_rows;
									while($row = $z->fetch_row()){
										    
											$ar = explode(".",$goods);
										    $loc='--';
										    if(count($ar) > 2) {
												$arr = explode(",",$ar[1]);
												$Client = $arr[0];
												$phone = $arr[0];
											}
											
											$row[4] = "/";
											if(!isset($view[$row[4]])) $view[$row[4]] = array();
										    array_push($view[$row[4]],$now);
                                            $total = $total + $row[2];											
									    }
								}

									
								        
									    include_once 'view/Ing_Orders.php';
								
							}else{
							    //回登陆
								session_destroy();
							    $tip = '用户身份已更新，请重新登陆';
							    include_once 'view/Login.php';
						    }
							
							
							
							
							
						    
				        }else echo 'Network connected error';
						
					break;
					
					
					
					case '5':
					    //历史订单 + 获取数据
						//预订单 + 获取数据
						if($sql = connectSQL()){
					        $z=$sql->query("SELECT 
							                    OrderID,UserName,UserPhone,Price,Time
											FROM 
											    WebOrder,Shopkeeper WHERE Shopkeeper.Key='".$_SESSION['token']."' AND WebOrder.ShopID=Shopkeeper.ShopID AND WebOrder.Status=3");	       
                	        if($z->num_rows>0){
								$view = array();
                			    while($row = $z->fetch_row()){
									array_push($view,$row);
								}					
						    }
							include_once 'view/Old_Orders.php';
				        }else echo 'Network connected error';
						
					break;
					
					
					
					case '6':
					    //收入详情 + 获取数据
						//TODO
					break;
					
					
					
					case 'view/store_clause':
					    //店铺条款
					break;
					
					
					
					case 'view/reward_clause':
					    //奖惩条款
					break;
					
					
					
					case 'Logout':
					    session_destroy();
						//回登陆
				        $tip = '';
				        include_once 'view/Login.php';
					break;
					
					
					
					default:
					    $tip = '';
				        include_once '404.html';
					break;
		        }
		
		    }else{
				//回登陆
				$tip = '';
				include_once 'view/Login.php';
		    }
		}else echo 'Slowly please';
		
	
    }else{
       echo '505';
    }

?>