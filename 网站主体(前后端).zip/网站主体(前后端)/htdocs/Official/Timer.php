<?php

//代理IP直接退出
//empty($_SERVER['HTTP_VIA']) or exit('Access Denied');

 

 function canDo(){
 session_start(); 
 $seconds = "0.5";
 $refresh = "5";
 $cur_time = time();
 if(isset($_SESSION["lt"])){

   $_SESSION["rt"]++;

 }else{
   $_SESSION["rt"]=1;
   $_SESSION["lt"]=$cur_time-10;
 }

 if($cur_time -$_SESSION["lt"]<$seconds){

   if($_SESSION["rt"]>=$refresh){
//跳转至攻击者服务器地址
     header(sprintf('Location:%s','http://127.0.0.1'));
     exit('Access Denied');
   }

   return false;
 }else{
   $_SESSION["rt"]=0;
   $_SESSION["lt"]=$cur_time;
   return true;
 }
}
?>

