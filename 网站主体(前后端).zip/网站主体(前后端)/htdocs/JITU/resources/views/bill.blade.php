﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
	
    <meta name="description" content="JITU - user order">
	<meta name="theme-color" id="theme_color" content="#fdb216" />
	
    <meta name="author" content="Andy">
	<title>{{ $value->webClient }}{{ trans('bill.1') }}</title>
	<link rel="stylesheet" type="text/css" href="../../css/Bill.css">
	<link rel="icon" type="image/x-icon" href="../../JT.ico" />
	<link rel="shortcut icon" href="../../JT.ico" type="image/x-icon">
	<style>
	 .payBG{
	   position: fixed; top:0; left:0; width: 100%; height: 100%;
	   background: rgba(255,255,255,0.87); z-index: 999;
	 }
	 .payBotton{width: 260px; padding: 12px 0 14px; background: #EC7063; margin: 18px auto; text-align: center;
	 border-radius: 6px; color: #FFF; border: 1px solid #dbdbdb}
	 #qrcode{text-align:center; margin: 70px auto 0px; width: 240px; }
	</style>
</head>

<body>
@if (($value->status == '等待确认支付' || $value->status == 'Watting for confirm') && $value->payment == 'Alipay 支付宝')
  <div class="payBG"><div id="qrcode"></div><div id="olpay" class="payBotton">开始网上支付 / Online Pay</div></div>
@endif

    <header>
		<h2>{{ $value->status }}</h2>
		<p class="des">{{ trans('bill.2') }}</p>
		<p class="date">{{ $value->date }}</p>
	</header>

	<div class="content">
		<img style="width: 80px;" src="../{{ trans('bill.logo') }}">
		<ul>
		@foreach ($goods as $gd)
		    <li>
				<img src="{{ config('Qsetting.IMG_url') }}goods/{{ $gd->img }}.jpg">
				<div class="Ginfo">
				    <p>{{ $gd->name }}</p>
				    <p>x{{ $ct[$gd->GID] }}</p>
				    <p><span>RM</span> {{ $gd->Price }}</p>
			    </div>
			</li>
		@endforeach

		</ul>
		<br>
		<div class="line"><p class="title">{{ trans('bill.3') }}</p> <p class="rm"><span>RM</span> {{ ($value->Express) + ($value->Packing) }}</p></div>
		<div class="line"><p class="title">{{ trans('bill.4') }}</p> <p class="rm" style="font-weight: 700; color: #fdb216"><span>RM</span> {{ ($value->Express) + ($value->Packing) + ($value->price) }}</p></div>
		<div class="line"><p class="title">{{ trans('bill.5') }}</p> <p class="rm">{{ $value->payment }}</p></div>

	</div>

	<br>
	<h4 style="height: 50px; text-align: center; color: rgba(0,0,0,0.2)"><img style="height: 19px;vertical-align: top; opacity: 0.8" src="../{{ trans('bill.logo') }}"> {{ trans('bill.6') }}</h4>

</body>

<script type="text/javascript" src="../../js/vue.js"></script>
<script type="text/javascript" src="../../js/jquery.min.js"></script>
<script src="../../js/vue-lazyload.js"></script>
<script src="../../js/QR.js"></script>
<script>
   var st=0;  
   $("#olpay").click(function(){
   //alert(""+{{ $value->ID }});
   if(st==2) {
     location.reload();
     return;
   }else if(st==1) {
     return;
   }
   st=1;
   $("#olpay").text('Loading...');
    $.ajax({url: 'http://jitu.fun/Alipay/H5Payment2.php',
     type: 'GET',
     data: {
       oid: {{ $value->ID }}, price: {{ ($value->Express) + ($value->Packing) + ($value->price) }}
     },
     success: function(result){
      var out=JSON.parse(result);  
      if(out.status=="ok"){
        st=2;
         //window.location.href=out.info.qr;
        new QRCode(document.getElementById('qrcode'), out.info.qr);
        $("#olpay").text('已支付完成 / Check status');
      }else {
        $("#olpay").text('重新发起支付 / Retry Alipay'); st=0;
        alert(out.status);
      }
    },
    error: function(result){
      $("#olpay").text('重新发起支付 / Retry Alipay'); st=0;
      alert(result.status);
    }});
    
  });
</script>
</html>