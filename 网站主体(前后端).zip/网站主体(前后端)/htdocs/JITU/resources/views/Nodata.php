﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
	
    <meta name="description" content="404">
	
    <meta name="author" content="Andy">
	<title>404 :(</title>
	<link rel="icon" type="image/x-icon" href="../JT.ico" />
	<link rel="shortcut icon" href="../JT.ico" type="image/x-icon">
</head>

<body>
	<h3 style="margin: 70px; text-align: center; opacity: 0.6">There is no data ...</h3>
</body>

</html>