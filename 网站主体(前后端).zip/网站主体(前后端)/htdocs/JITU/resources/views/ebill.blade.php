<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
    <meta name="description" content="JITU Platform">
	<meta name="author" content="Andy">
	<meta name="theme-color" id="theme_color" content="#fdb216" />
	<title>JITU Reservation</title>
	<link rel="stylesheet" href="../../css/eBill.css">
	
    
	<link rel="icon" type="image/x-icon" href="../../JT.ico" />
	<link rel="shortcut icon" href="../../JT.ico" type="image/x-icon">

</head>

<body>
	<div class="card">
	    <img class="title" src="../../imgs/banner.jpg">
		<div class="if">
		    <p>{{ $value->ZH_Name }}</p>
		    <p>{{ $value->CreatedDate }}</p>
		    <p>{{ $value->EType }}</p>
		</div>
		<div style="text-align: center;">
		    <h4>{{ trans('ebill.1') }}： {{ $value->TID }}</h4>
			<img src="../../imgs/testQR.png">
		</div>
	</div>

	<h5 style="height: 50px; text-align: center; color: rgba(0,0,0,0.2)">{{ trans('ebill.2') }} <img style="height: 19px;vertical-align: top; opacity: 0.8" src="../{{ trans('bill.logo') }}"> {{ trans('ebill.3') }}</h5>

</body>
<script type="text/javascript" src="../../js/jquery.min.js"></script>
<script type="text/javascript" src="../../js/vue.js"></script>
<script type="text/javascript" src="../../js/vue-lazyload.js"></script>
<script>

</script>
</html>