<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
    <meta name="description" content="JITU Platform">
    <meta name="author" content="Andy">
	<title>JITU</title>
    <link rel="stylesheet" href="../css/swiper.min.css">
	<link rel="stylesheet" href="../css/Lobby.css">
    <script src="../js/iconfont.js"></script>
	<link rel="icon" type="image/x-icon" href="../JT.ico" />
	<link rel="shortcut icon" href="../JT.ico" type="image/x-icon">
    
	<style>
    a{text-decoration: none; color: rgba(1,1,1,1)}
	.icon {vertical-align: -0.15em; fill: currentColor; overflow: hidden; width: 20px; height: 20px;}
</style>
</head>

<body>

<div class="Goodsdetail" onclick="c1()">
    <div class="alert" onclick="c2()">
	    <h4 id="Gname"></h4>
		<img id="Gimg" src="../imgs/test.png">
		<p>RM <span id="Gprice"></span></p>
		<div id="GID" style="display: none">0</div>
		<div class="go" onclick="store()">{{ trans('home.9') }}</div>
		<div class="back" onclick="bk()">{{ trans('home.10') }}</div>
	</div>
</div>

<header>
    <div class="left"><img src="{{ trans('home.logo') }}.png"></div>
	<a href="app"><div class="right">{{ trans('home.1') }}</div></a>
	<ul class="PCcategory">
	    <li style="font-weight:700; color: #fdb216; border-bottom: 3px solid #fdb216;">{{ trans('home.2') }}</li>
	    <li><a href="food">{{ trans('home.3') }}</a></li>
	    <li><a href="events">{{ trans('home.4') }}</a></li>
	</ul>
</header>
<div class="loader">
    <div class="spinner">
       <div class="double-bounce1"></div>
       <div class="double-bounce2"></div>
    </div>
</div>



<div id="body">

<ul class="category">
<li class="active">{{ trans('home.2') }}</li>
<li><a href="food">{{ trans('home.3') }}</a></li>
<li><a href="events">{{ trans('home.4') }}</a></li>
</ul>

<div class="swiper-container">
    <div class="swiper-wrapper">
	    <a href="social/3"><div class="swiper-slide"><img src="../imgs/banner.jpg"></div></a>
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
 </div>


<div class="section" id="goods" v-show="items.length > 0">
    <p class="title" onclick="Tmore()">{{ trans('home.5') }}
	    <a>{{ trans('home.6') }} ></a>
	</p>
	<div class="content">
	    <a v-for="item in items" v-on:click="Goods(item.ID, item.img, item.name, item.Price)">
		    <img v-bind:src="item.img">
			<div class="ginfo">
			    <h4 v-text="item.name"></h4>
				<p>{{ trans('home.11') }} <span v-text="item.sold"></span></p>
			</div>
		</a>
	</div>
</div>

<div class="section pc" style="margin-top: 10px">
    <p class="title pchide">{{ trans('home.7') }}
	</p>

	<div id="root">
	
	<div class="item" v-for="item in items" v-on:click="Social(item.ID)">
        <img class="itemImg" v-lazy="item.img" alt=""/>
        <div class="userInfo">
            <div class="head" v-html="item.Content"></div>
			<div class="detail">
			    <div><img class="itemImg" v-lazy="item.userimg"> <span v-text="item.Sender"></span></div>
				<div class="like">{{ trans('home.12') }}  <em v-text="item.Like"></em> </div>
			</div>
        </div>
    </div>
</div>
	<div id="smart" style="text-align: center">
	    <a class="btn" href="app">{{ trans('home.8') }}</a>
	</div>
</div>

<div id="ml" style="text-align: center;">
	<a class="btn" href="app">{{ trans('home.8') }}</a>
</div>

</div>
<script type="text/javascript" src="../js/swiper.min.js"></script>
<script>
    var swiper = new Swiper('.swiper-container', {
      spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      }
    });
  </script>
</body>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/vue.js"></script>
<script type="text/javascript" src="../js/vue-lazyload.js"></script>
<script>

Vue.use(VueLazyload);

function Tmore(){
	window.location.href = "food";
}

function Gshow(){
	$("body").css("overflow","hidden");
	$('.Goodsdetail').fadeIn();
}

function Ghide(){
	$("body").css("overflow","auto");
	$('.Goodsdetail').fadeOut();
}

var c2c = false;
function c1(){
	if(c2c == false) {
		Ghide();
		}
	c2c = false;
}

function c2(){
	c2c = true;
}

function store(){
	var ID = $('#GID').text();
	window.location.href="goods/"+ID;
}

function bk(){
	Ghide();
	c2c = false;
}

var dt = {!!  json_encode($name) !!};

for (var i = 0; i < dt.length; i++) {
		dt[i].img = '{{ config('Qsetting.IMG_url') }}goods/'+dt[i].img+'.jpg';
}
	var Goods = new Vue({
		el: '#goods',
		data: {
			items: dt
		},
		methods: {
		    Goods: function(id,img,name,price){
				Gshow();
				$('#GID').text(id);
				$("#Gimg").attr("src",img);
				$('#Gname').text(name);
				$('#Gprice').text(price);
		    }
		}
});

var mt = {!!  json_encode($mmt) !!};
for (var i = 0; i < mt.length; i++) {
	mt[i].Content = reEdit(mt[i].Content);
	mt[i].img = '{{ config('Qsetting.IMG_url') }}moments/'+mt[i].ID+'-1.jpg';
	mt[i].userimg = '{{ config('Qsetting.IMG_url') }}users/'+mt[i].SenderID+'.jpg';
}

var Chat = new Vue({
  el: '#root',
  data: {
    items: mt
  },
  methods: {
		    Social: function(id){
				window.location.href="social/"+id;
		    }
	}
});

function reEdit(str){
	var clean = str.replace(/{a}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-a"></use></svg> ').
	replace(/{bizui}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-bizui"></use></svg> ').
	replace(/{baiyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-baiyan"></use></svg> ').
	replace(/{aixin}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-aixin"></use></svg> ').
	replace(/{dajing}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-dajing"></use></svg> ').
	replace(/{ziya}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-ziya"></use></svg> ').
	replace(/{daxiao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-daxiao"></use></svg> ').
	replace(/{esi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-esi"></use></svg> ').
	replace(/{fadai}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fadai"></use></svg> ').
	replace(/{fankun}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fankun"></use></svg> ').
	replace(/{ganga}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-ganga"></use></svg> ').
	replace(/{fennu}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fennu"></use></svg> ').
	replace(/{hanyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-hanyan"></use></svg> ').
	replace(/{jingkong}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-jingkong"></use></svg> ').
	replace(/{haochi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-haochi"></use></svg> ').
	replace(/{emo}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-emo"></use></svg> ').
	replace(/{jingsong}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-jingsong"></use></svg> ').
	replace(/{jingya}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-jingya"></use></svg> ').
	replace(/{kaixin}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-kaixin"></use></svg> ').
	replace(/{lengku}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-lengku"></use></svg> ').
	replace(/{danao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-danao"></use></svg> ').
	replace(/{liukoushui}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liukoushui"></use></svg> ').
	replace(/{liulei}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liulei"></use></svg> ').
	replace(/{mengbi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-mengbi"></use></svg> ').
	replace(/{mianwubiaoqing}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-mianwubiaoqing"></use></svg> ').
	replace(/{nanguo}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-nanguo"></use></svg> ').
	replace(/{shuizhuo}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shuizhuo"></use></svg> ').
	replace(/{taoyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-taoyan"></use></svg> ').
	replace(/{tanchi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tanchi"></use></svg> ').
	replace(/{siliao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-siliao"></use></svg> ').
	replace(/{tiaopi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tiaopi"></use></svg> ').
	replace(/{xiaochulei}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiaochulei"></use></svg> ').
	replace(/{wuliao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-wuliao"></use></svg> ').
	replace(/{xingxingyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xingxingyan"></use></svg> ').
	replace(/{xieyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xieyan"></use></svg> ').
	replace(/{xiasi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiasi"></use></svg> ').
	replace(/{xiaolian}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiaolian"></use></svg> ').
	replace(/{ku}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-ku"></use></svg> ').
	replace(/{shengqi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shengqi"></use></svg> ').
	replace(/{yousiliao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-yousiliao"></use></svg> ').
	replace(/{en}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-en"></use></svg> ').
	replace(/{bushufu}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-bushufu"></use></svg> ').
	replace(/{bianbian}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-bianbian"></use></svg> ').
	replace(/{fankun1}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fankun1"></use></svg> ').
	replace(/{feiwen}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-feiwen"></use></svg> ').
	replace(/{ganmao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-ganmao"></use></svg> ').
	replace(/{huaixiao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-huaixiao"></use></svg> ').
	replace(/{liuhan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liuhan"></use></svg> ').
	replace(/{outu}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-outu"></use></svg> ').
	replace(/{keshui}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-keshui"></use></svg> ').
	replace(/{renzhe}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-renzhe"></use></svg> ').
	replace(/{santiaoxian}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-santiaoxian"></use></svg> ').
	replace(/{guaiwu}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-guaiwu"></use></svg> ').
	replace(/{shoushang}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shoushang"></use></svg> ').
	replace(/{tianshi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tianshi"></use></svg> ').
	replace(/{shuai}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shuai"></use></svg> ').
	replace(/{xianwen}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xianwen"></use></svg> ').
	replace(/{xiaodiaodaya}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiaodiaodaya"></use></svg> ').
	replace(/{xiong}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiong"></use></svg> ').
	replace(/{yiwen}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-yiwen"></use></svg> ').
	replace(/{yun}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-yun"></use></svg> ').
	replace(/{liubixie}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liubixie"></use></svg> ').
	replace(/{shimo}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shimo"></use></svg> ').
	replace(/{dianzan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-dianzan"></use></svg> ').
	replace(/{biti}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-biti"></use></svg> ').
	replace(/{fendou}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fendou"></use></svg> ').
	replace(/{huqi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-huqi"></use></svg> ').
	replace(/{heng}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-heng"></use></svg> ').
	replace(/{kulou}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-kulou"></use></svg> ').
	replace(/{leng}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-leng"></use></svg> ').
	replace(/{taoyan1}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-taoyan1"></use></svg> ').
	replace(/{shuixing}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shuixing"></use></svg> ').
	replace(/{aini}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-aini"></use></svg> ').
	replace(/{aixin1}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-aixin1"></use></svg> ').
	replace(/{zhadan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-zhadan"></use></svg> ').
	replace(/{xinsui}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xinsui"></use></svg> ').
	replace(/{maren}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-maren"></use></svg> ').
	replace(/{zhutou}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-zhutou"></use></svg> ').
	replace(/{qie}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-qie"></use></svg> ').
	replace(/{youling}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-youling"></use></svg> ').
	replace(/&B/g,' ').
	replace(/&/g,' ');
	return clean;
}
 $(document).ready(function(){
	$('.loader').hide();
});

</script>
</html>