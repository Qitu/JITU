﻿<!DOCTYPE html>
<html lang="EN">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Social, UKM">
    <meta name="description" content="JITU Platform">
	<meta name="theme-color" id="theme_color" content="#fdb216" />
    <meta name="author" content="Andy">
	<title>{{ $m->Sender }}</title>
	<link rel="stylesheet" type="text/css" href="../../css/Lobby.css">
	<script src="../../js/iconfont.js"></script>
	<link rel="icon" type="image/x-icon" href="../../JT.ico" />
	<link rel="shortcut icon" href="../../JT.ico" type="image/x-icon">
	<style>
	    header{height: 50px; background: #fdb216; position: absolute}
		header .left{margin-top: 12px}
		header .right{margin-top: 12.5px; color: #FFF;}
		.btn{width: 200px; display: block; padding: 6px 7px; font-size: 13px; font-weight: 700}
		.info-container{margin: 58px 15px;} .info-container img{display: inline-block}
		.info-container .commad{display: inline-block; position: relative; left: 8px; top: -6.5px; line-height: 18px}
		.info-container .commad p{margin: 0; color: #999; font-size: 12px;} .info-container .commad h4{font-weight: 400; font-size: 13px; margin: 0}
		.info-container span{vertical-align: top; position: relative; left: 8px; top: 10.5px; font-weight: 700; font-size: 13px;}
		.info-container .right{float: right; color: #fdb216; border-radius: 6px; font-size: 13px; margin-top: 7px; padding: 3.5px 12px;} .info-container .right:active{background: #fdb216; color: #FFF}
		.info-container .detail{font-size: 14px; line-height: 25px; color: #373736; margin-top: 15px} .info-container .cm{margin-left: 50px}
		.info-container .reply{margin-top: 15px; margin-left: 50px; background: #f5f5f5; border-radius: 8px; padding: 12px 12px 36px; font-size: 13px; color: #aaa9aa} .info-container .reply p{font-weight: 400; line-height: 24px; margin: 0}
		.info-container .reply .rt{float: right; margin: 6px; color: #ff7f50; cursor: pointer}
		.user-img{width: 40px; height: 40px; border-radius: 50%;}
		.info-container ul{display: block; padding-left: 0; margin-top: 25px}
		.info-container ul li {display: inline-block; width: 32.33%; }
		.info-container ul li img{width: 100% }
		hr{ border: 0; height: 0; margin: auto; width: 90%; border-top: 1px solid rgba(0,0,0,0.1); border-bottom: 1px solid rgba(255,255,255,0.3);}
		.adv{display: none; line-height: 25px; position: fixed; bottom: 30px; background: #fdb216; box-shadow: 1px 1px 3px rgba(0,0,0,0.2); left: 50%; transform: translate3d(-50%, 0, 0); z-index: 20; font-size: 13px; padding: 10px 18px; color: #FFF; border-radius: 5em}
	    .adv img{background: #FFF; width: 30px; padding: 2px; border-radius: 5em; position: relative; top: 3.5px}		
		.icon {vertical-align: -0.15em; fill: currentColor; overflow: hidden; width: 20px; height: 20px;}
		.tags{border-radius: 5em; background: #fdb216; color: #FFF; padding: 5px 10px; margin: 8px 6px 8px 0; font-size: 12px;}
		.child-is-picture img{margin: 7px auto 9px; max-width: 100%}
		.child-is-picture{text-align: center;}
	</style>
</head>

<body>
<a href="../app/{{ $m->MomentID }}"><div class="adv"><img src="../../imgs/{{ trans('social.logo') }}.png"> {{ trans('social.5') }}</div></a>

<header>
    <div class="left"><a href="../home"><img src="../../imgs/Y{{ trans('social.logo') }}.png"></a></div>
	<a href="../app/{{ $m->MomentID }}"><div class="right">{{ trans('social.1') }}</div></a>
</header>
<div class="loader">
    <div class="spinner">
       <div class="double-bounce1"></div>
       <div class="double-bounce2"></div>
    </div>
</div>


<div id="body">

 <div class="section pc">
    
	<div class="info-container">
	    <a href="../official/{{ $m->SenderID }}"><img class="user-img" src="{{ config('Qsetting.IMG_url') }}users/{{ $m->SenderID }}.jpg" onerror="../../user.png" ></a> <span>{{ $m->Sender }}</span>
		<a href="../app/{{ $m->MomentID }}"><div class="right" style="border: 1px solid #fdb216; ">{{ trans('social.2') }}</div></a>

		<div class="detail nr"></div>
	</div>

	
	
	
	
	<p class="title"><b>{{ $m->ct }} </b>{{ trans('social.3') }}</p>
	<hr>


	@foreach ($c as $com)
	   <div id="yeah" class="info-container" style="margin-top: 20px">
	        <img class="user-img" src="{{ config('Qsetting.IMG_url') }}users/{{ $com->UserID }}.jpg" onerror="user.png"> <div class="commad"><h4>{{ $com->User }}</h4><p>{{ $com->PostDate }}</p></div>
		    <div class="right"><svg class="icon" style="width: 20px; height: 20px; " aria-hidden="true"><use xlink:href="#icon-aixin1"></use></svg></div>
			
			<div class="detail cm">
			    {{ $com->CommentContent }}
			</div>
			@if (count($r) > 0)
			<div class="reply">
			    @foreach ($r as $reply)
				    @if ($reply->CID == $com->CommentID)
			            <p>{{ $reply->FromName }} : {{ $reply->ContentR }}</p>
				    @endif	
				@endforeach
				<a class="rt" href="../app/{{ $m->MomentID }}">{{ trans('social.4') }} ></a>
			</div>
			@endif	
	    </div>
	@endforeach



	
	<div id="smart" style="text-align: center; margin-top: 40px; margin-bottom: 50px;">
	    <a style="color: #fdb216" href="../app/{{ $m->MomentID }}">{{ trans('social.4') }}</a>
	</div>
	
	
	<hr>
	
	

    <p class="title pchide">{{ trans('social.6') }}</p>
	
	<div id="root">
	
	<div class="item" v-for="item in items" v-on:click="Social(item.MomentID)">
        <img class="itemImg" v-show="item.Pictures>0" v-lazy="item.img" alt=""/>
        <div class="userInfo">
		    <div class="head" v-text="item.title"></div>
			<div class="detail">
			    <div><img class="itemImg" v-lazy="item.userimg" alt=""> <span v-text="item.user"></span></div>
				<div class="like"><svg class="icon" style="width: 20px; height: 20px; " aria-hidden="true"><use xlink:href="#icon-aixin1"></use></svg> <p v-text="item.Like" style="display: inline-block; margin: 0px"></p></div>
			</div>
        </div>
    </div>
	
</div>
</div>

</div>
<script src="../../js/zooming.js"></script>
<script>
      // Listen to images after DOM content is fully loaded
      document.addEventListener('DOMContentLoaded', function () {
        new Zooming({
          // options...
        }).listen('.img-zoomable')
      })
</script>
</body>
<script type="text/javascript" src="../../js/vue.js"></script>
<script type="text/javascript" src="../../js/jquery.min.js"></script>
<script src="../../js/vue-lazyload.js"></script>

<script>

Vue.use(VueLazyload);

function Gshow(){
	$("body").css("overflow","hidden");
	$('.Goodsdetail').fadeIn();
}

function Ghide(){
	$("body").css("overflow","auto");
	$('.Goodsdetail').fadeOut();
}

var c2c = false;
function c1(){
	if(c2c == false) {
		Ghide();
		}
	c2c = false;
}

function c2(){
	c2c = true;
}

function bk(){
	Ghide();
	c2c = false;
}


const matchList  = {
  'lt;': '<',
  'gt;': '>',
  '&amp;': '',
  '#34;': '"',
  'quot;': '"',
  '#39;': "'",
  '&B': " ",
  'amp;': '',
  'style': " style",
  'class': " class"
  //'&': " ",
}
const HtmlFilter = (text) => {
  let regStr = '(' + Object.keys(matchList).toString() + ')'
  // ↑ ------------【*提取匹配列表key值*】.【组数转字符串】
  regStr = regStr.replace(/,/g, ')|(')
  // ↑ 通过匹配将其更新为正则的字符串类型
  const regExp = new RegExp(regStr, 'g')
  // ↑ ------- 字符串 转 正则 方法
  return text.replace(regExp, match => matchList[match])
  // ↑ ------ 替换方法 (正则, 当前key => 返回当前被匹配的key值)
}

 $(document).ready(function(){
	$('.loader').hide();
	$(window).scroll(function(){
	    let scrollTop=$(this).scrollTop();
	    if(scrollTop >= 60 ) $('.adv').show();
		else $('.adv').hide();
	});
	//alert('{{ $m->Content }}');
	let str = HtmlFilter('{{ $m->Content }}'),ImgIndex=1;
	str= str.replace(/<img>/gi,function(match,capture){
      　let newStr='<img src="{{ config('Qsetting.IMG_url') }}moments/'+{{ $m->MomentID }}+'-'+ImgIndex+'.jpg">';
        ImgIndex++;
      　return newStr;
    });
	$('.nr').html(str);
});

let dtt = {!!  json_encode($recom) !!};

for (let i = 0; i < dtt.length; i++) {
		dtt[i].img = '{{ config('Qsetting.IMG_url') }}moments/'+dtt[i].MomentID+'-1.jpg';
		dtt[i].userimg = '{{ config('Qsetting.IMG_url') }}users/'+dtt[i].SenderID+'.jpg';
		dtt[i].title = HtmlFilter(dtt[i].title).replace(/<[^>]+>/g,"");
}

/*{ img: '../imgs/test.png', title: 'Java教学', user:'大湿兄', like: 638} */

let Chat = new Vue({
  el: '#root',
  data: {
    items: dtt
  },
  methods: {
		    Social: function(id){
				window.location.href="../social/"+id;
		    }
	}
});

</script>
</html>