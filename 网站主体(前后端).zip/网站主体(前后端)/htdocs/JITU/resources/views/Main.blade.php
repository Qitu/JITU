﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="JTalk, Online shopping, Events, Moments">
    <meta name="keywords" content="Online shopping, Events, JTalk, Moments">
    <meta name="author" content="JITU-Andy">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Title -->
    <title>JTalk</title>
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../JT.ico" />
    <link rel="shortcut icon" href="../JT.ico" type="image/x-icon">

    <!-- All CSS -->
    <link rel="stylesheet" href="../assets/css/plugins.css">
   	<link rel="stylesheet" href="../assets/css/themify-icons.css">
   	<link rel="stylesheet" href="../assets/css/main.css">
   	<link rel="stylesheet" href="../assets/css/responsive.css">
   	<script src="../js/iconfont.js"></script>
   	   
	<style>
	.icon {vertical-align: -0.15em; fill: currentColor; overflow: hidden; width: 20px; height: 20px;}
	.blog-title{overflow : hidden;text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;}
</style>
</head>
<body id="top">
	<div class="loader">
		<img src="../assets/img/loader.svg" alt="">
	</div>
	<!-- /loader -->

	<header>
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-2 col-md-6 col-8">
					<a href="02_index-2.html" class="logo">
						<!-- logo -->
						<img class="img-fluid" src="{{ trans('home.logo') }}.png" alt="JTalk">
					</a>
				</div>
				<div class="col-lg-10 col-md-6 col-4">
					<div class="navigation-show">
						<i class="ti-menu"></i>
					</div>
					<!-- /navigation-show -->
					<nav class="navigation">
						<div class="navigation-close">
							<i class="ti-close"></i>
						</div>
						
						<!-- navigation -->
						<ul>
						<!-- 
							<li class="dropToggle active">Home <i class="ti-angle-down"></i>
							
								<ul class="dropWrap">
									<li><a href="index.html">Home 01</a></li>
									<li class="active"><a href="02_index-2.html">Home 02</a></li>
								</ul>
								-->
							</li>
							<li><a href="">About Us</a></li>
		
						</ul>
					</nav>
					<!-- /navigation -->
				</div>
			</div>
		</div>
	</header>
	<!-- /header -->

	<!-- hero-wrapper start -->
	<div class="hero-wrapper hero-wrapper-2">
		<div class="hero-content">
			<div class="container h-100">
				<div class="row h-100 align-items-center">
					<div class="col-md-6">
						<div class="hero-info">
							<h2><span>{{ trans('Main.header1') }}</span>JTalk</h2>
							<p>{{ trans('Main.header2') }}</p>
							<a href="https://play.google.com/store/apps/details?id=com.z969977237.hvo" class="creatopo-btn">{{ trans('Main.header3') }} Android</a>
							<a href="http://jitu.fun/comming" class="creatopo-btn">{{ trans('Main.header3') }} IOS</a>
						</div>
						<!-- /hero-info -->
					</div>
					<div class="col-md-6">
						<div class="hero-img">
							<img class="img-fluid" src="../assets/img/hero-home/hero-members-img.png" alt="">
						</div>
						<!-- /hero-img -->
					</div>
				</div>
			</div>
		</div>
		<!-- /hero-content -->
	</div>
	<!-- hero-wrapper end -->
	
	
		<!-- testimonials-wrapper start -->
	<div class="wrapper testimonials-wrapper testimonials-wrapper-2">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-12">
                    <div class="wrapper-header text-center">
                        <p>{{ trans('Main.rec1') }}</p>
                        <h3>{{ trans('Main.rec2') }}<br><span>JTMall</span></h3>
                    </div>
                    <!-- /wrapper-header -->
				</div>
				<div class="col-lg-8">
					<div class="testimonials-carousel-2 owl-carousel" id="goods">
				
						<div v-for="item in items" v-on:click="Goods(item.ID)" class="client-item" style="text-align: center">
							<img class="client-img" v-bind:src="item.img" alt="" style="margin: auto">
							<div class="clients-bio">
								<h6 v-text="item.name"></h6>
								<p>{{ trans('home.11') }} <span v-text="item.sold"></span></p>
							</div>
							<p class="clients-text"></p>
							<div class="clients-star">
							  RM <span v-text="item.Price"></span>
							</div>
						</div>
						
						<!-- /client-item -->
					</div>
					<!-- /testimonials-carousel -->
				</div>
			</div>
		</div>
	</div>
	<!-- testimonials-wrapper end -->



	
		<!-- blogs-wrapper start -->
    <div class="wrapper blogs-wrapper">
        <div class="container">
            <div class="row align-items-end">
				<div class="col-lg-6 col-md-12">
					<div class="wrapper-header">
						<p>{{ trans('Main.mom1') }}</p>
						<h3>{{ trans('Main.mom2') }}<br><span>in JTalk</span></h3>
					</div>
					<!-- /wrapper-header -->
				</div>
				<div class="col-lg-6 col-md-12">
					<div class="blog-carousel-bullets">
						<div class="prev"><i class="ti-angle-left"></i></div>
						<div class="next"><i class="ti-angle-right"></i></div>
					</div>
					<!-- /service-carousel-bullets -->
				</div>
			</div>
            <div class="row">
                <div class="col-md-12">
                    <div id="root" class="blogs-carousel-2 owl-carousel">
                        <div v-for="item in items" v-on:click="Social(item.ID)" class="blog-item">
                            <a>
                                <img v-show="item.Pictures>0" class="img-fluid itemImg" v-lazy="item.img" alt="">
                                <div class="blog-info">
                                    <h5 class="blog-title" v-html="item.Content"></h5>
                                    <span class="blog-post-info" v-text="item.Sender"></span>
                                    <p class="blog-item-text">{{ trans('home.12') }}  <em v-text="item.Like"></em></p>
                                    <span class="more">{{ trans('Main.mom3') }}<i class="ti-angle-right"></i></span>
                                </div>
                            </a>
                        </div>
                        <!-- /blog-item -->
                        
                   <!--- <img class="itemImg" v-lazy="item.userimg"> -->
                   
                        <!-- /blog-item -->
                    </div>
                </div>
            </div>
        </div>
    </div>
	<!-- blogs-wrapper end -->
	

 <!-- case-study-wrapper start 
	<div class="wrapper case-study-wrapper case-study-wrapper-2">
		<div class="case-study-container">
			<div class="container">
				<div class="row zoom-gallery">
					<div class="col-md-12">
						<div class="wrapper-header text-center">
							<p>{{ trans('Main.act1') }}</p>
							<h3>{{ trans('Main.act2') }}<br><span>events</span></h3>
						</div>
						
						
					</div>
					<div class="col-lg-3 col-md-6 col-6 mb-35">
						<a class="zoom_image" href="../assets/img/portfolio/item0101.jpg">
							<div class="case-study-img">
								<img class="img-fluid" src="../assets/img/portfolio/item0101.jpg" alt="">
								<div class="case-study-item-pop">
									<h4>Black &amp; white pattern</h4>
								</div>
							</div>
							
							
							
						</a>
					</div>
					<div class="col-lg-3 col-md-6 col-6 mb-35">
						<a class="zoom_image" href="../assets/img/portfolio/item0102.jpg">
							<div class="case-study-img">
								<img class="img-fluid" src="../assets/img/portfolio/item0102.jpg" alt="">
								<div class="case-study-item-pop">
									<h4>Green container wall</h4>
								</div>
							</div>
							
							
						</a>
					</div>
					<div class="col-lg-3 col-md-6 col-6 mb-35">
						<a class="zoom_image" href="../assets/img/portfolio/item0103.jpg">
							<div class="case-study-img">
								<img class="img-fluid" src="../assets/img/portfolio/item0103.jpg" alt="">
								<div class="case-study-item-pop">
									<h4>Color of the year</h4>
								</div>
							</div>
							
							
						</a>
					</div>
					<div class="col-lg-3 col-md-6 col-6 mb-35">
						<a class="zoom_image" href="../assets/img/portfolio/item0104.jpg">
							<div class="case-study-img">
								<img class="img-fluid" src="../assets/img/portfolio/item0104.jpg" alt="">
								<div class="case-study-item-pop">
									<h4>Black pattern</h4>
								</div>
							</div>
						
						
						</a>
					</div>
					<div class="col-md-12 text-center mt-25">
						<a href="05_case-study.html" class="creatopo-btn">Explore More</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	 case-study-wrapper end -->






<!-- whycu-wrapper start -->
	<div class="wrapper whycu-wrapper whycu-wrapper-2">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-6 col-md-12">
					<div class="whycu-img">
						<img class="img-fluid" src="../assets/img/_home2/whycu-img2.png" alt="">
					</div>
					<!-- /whycu-img -->
				</div>
				<div class="col-lg-6 col-md-12">
					<div class="wrap-gap pl-70">
						<div class="wrapper-header">
							<p>{{ trans('Main.join1') }}</p>
							<h3>{{ trans('Main.join2') }} <span>{{ trans('Main.join3') }}</span></h3>
						</div>
						<!-- /wrapper-header -->
						<div class="whycu-item">
							<img src="../assets/img/whycu/text-item_01.png" alt="">
							<p>{{ trans('Main.join4') }}</p>
						</div>
						<!-- /whycu-item -->
						<div class="whycu-item">
							<img src="../assets/img/whycu/text-item_02.png" alt="">
							<p>{{ trans('Main.join5') }}</p>
						</div>
						<!-- /whycu-item -->
						<div class="whycu-item">
							<img src="../assets/img/whycu/text-item_03.png" alt="">
							<p>{{ trans('Main.join6') }}</p>
						</div>
						<!-- /whycu-item -->
						<div class="whycu-item mb-0">
							<img src="../assets/img/whycu/text-item_04.png" alt="">
							<p>{{ trans('Main.join7') }}</p>
						</div>
						<!-- /whycu-item -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- whycu-wrapper end -->
	
	




	<!-- award-wrapper start -->
	<div class="wrapper award-wrapper">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-3 col-md-6 col-6">
					<div class="award-item">
						<div class="award-img">
							<img src="../assets/img/award/process.png" alt="">
							<img src="../assets/img/award/process.hover.png" alt="">
						</div>
						<p class="count-text"><span class="counter">42382</span>+</p>
						<p class="award-title">{{ trans('Main.block1') }}</p>
					</div>
					<!-- /award-item -->
				</div>
				<div class="col-lg-3 col-md-6 col-6">
					<div class="award-item">
						<div class="award-img">
							<img src="../assets/img/award/complete.png" alt="">
							<img src="../assets/img/award/complete.hover.png" alt="">
						</div>
						<p class="count-text"><span class="counter">800</span>+</p>
						<p class="award-title">{{ trans('Main.block2') }}</p>
					</div>
					<!-- /award-item -->
				</div>
				<div class="col-lg-3 col-md-6 col-6">
					<div class="award-item">
						<div class="award-img">
							<img src="../assets/img/award/success.png" alt="">
							<img src="../assets/img/award/success.hover.png" alt="">
						</div>
						<p class="count-text"><span class="counter">120</span>+</p>
						<p class="award-title">{{ trans('Main.block3') }}</p>
					</div>
					<!-- /award-item -->
				</div>
				<div class="col-lg-3 col-md-6 col-6">
					<div class="award-item">
						<div class="award-img">
							<img src="../assets/img/award/happy.png" alt="">
							<img src="../assets/img/award/happy.hover.png" alt="">
						</div>
						<p class="count-text"><span class="counter">1246</span>+</p>
						<p class="award-title">{{ trans('Main.block4') }}</p>
					</div>
					<!-- /award-item -->
				</div>
			</div>
		</div>
	</div>
	<!-- award-wrapper end -->

	
	

	<!-- footer-wrapper start -->
    <footer class="footer-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-10">
                    <div class="footer-about">
                        <!-- logo -->
                        <img class="logo" src="{{ trans('home.logo') }}.png" alt="creatopo">
                    </div>
                </div>
                <div class="col-lg-2 col-md-3">
                    <h4 class="footer-header mt-0">{{ trans('Main.footer3') }}</h4>
                    <ul class="footer-links">
                        <li><a href="#">About Us</a></li>
                    </ul>
                    <!-- /.footer-links -->
                </div>
                <div class="col-lg-3 col-md-5">
                    <h4 class="footer-header">{{ trans('Main.footer4') }}</h4>
                    <ul class="footer-links">
                        <li>Saville Kajang, Kajang, Selangor, Kuala Lumpur, Malaysia</li>
                        <li>
                            <a href="mailto:andy@jitu.fun">andy@jitu.fun</a>
                        </li>
                    </ul>
                </div>
                
                <!---
                <div class="col-lg-3 col-md-4">
                    <h4 class="footer-header">Gallery</h4>
                    <div class="footer-img-group">
                        <div class="img-group-item">
                            <a href="#"><img src="../assets/img/footer/gallery/1.png" alt=""></a>
                        </div>
                        <div class="img-group-item">
                            <a href="#"><img src="../assets/img/footer/gallery/2.png" alt=""></a>
                        </div>
                        <div class="img-group-item">
                            <a href="#"><img src="../assets/img/footer/gallery/3.png" alt=""></a>
                        </div>
                        <div class="img-group-item mb-0">
                            <a href="#"><img src="../assets/img/footer/gallery/4.png" alt=""></a>
                        </div>
                        <div class="img-group-item mb-0">
                            <a href="#"><img src="../assets/img/footer/gallery/5.png" alt=""></a>
                        </div>
                        <div class="img-group-item mb-0">
                            <a href="#"><img src="../assets/img/footer/gallery/6.png" alt=""></a>
                        </div>
                       
                    </div>
                </div>
                -->
            </div>
        </div>
    </footer>
    <div class="footer-bottom text-center">
        <p class="copyright-text">
            &copy; 2019 All Right Reserved, <a href="http://jitu.fun/" target="_blank">JITU</a>
        </p>
        <!-- /copyright-text -->
    </div>
    <!-- ./footer-bottom -->
    <!-- footer-wrapper end -->

    <!-- scrollUp-wrapper start -->
    <a href="#top" class="scrollUp">
        <span class="ti-angle-up"></span>
        <span class="ti-angle-up"></span>
    </a>
    <!-- scrollUp-wrapper end -->

    <script src="../assets/js/plugins.js"></script>
    <script src="../assets/js/main.js"></script>
    
</body>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/vue.js"></script>
<script type="text/javascript" src="../js/vue-lazyload.js"></script>
<script>

Vue.use(VueLazyload);

var dt = {!!  json_encode($name) !!};
for(var i = 0; i < dt.length; i++) {
		dt[i].img = '{{ config('Qsetting.IMG_url') }}goods/'+dt[i].img+'.jpg';
}
	var Goods = new Vue({
		el: '#goods',
		data: {
			items: dt
		},
		methods: {
		    Goods: function(id){
		      window.open("goods/"+id);
		    }
		}
});


const matchList  = {
  'lt;': '<',
  'gt;': '>',
  '&amp;': '',
  '#34;': '"',
  'quot;': '"',
  '#39;': "'",
  '&B': " ",
  'amp;': '',
  'style': ' style'
  //'&': " ",
}
const HtmlFilter = (text) => {
  let regStr = '(' + Object.keys(matchList).toString() + ')'
  // ↑ ------------【*提取匹配列表key值*】.【组数转字符串】
  regStr = regStr.replace(/,/g, ')|(')
  // ↑ 通过匹配将其更新为正则的字符串类型
  const regExp = new RegExp(regStr, 'g')
  // ↑ ------- 字符串 转 正则 方法
  return text.replace(regExp, match => matchList[match]).replace(/<[^>]+>/g,"");
  // ↑ ------ 替换方法 (正则, 当前key => 返回当前被匹配的key值)
}


var mt = {!!  json_encode($mmt) !!};
for (var i = 0; i < mt.length; i++) {
	mt[i].Content = HtmlFilter(mt[i].Content);
	mt[i].img = '{{ config('Qsetting.IMG_url') }}moments/'+mt[i].ID+'-1.jpg';
	mt[i].userimg = '{{ config('Qsetting.IMG_url') }}users/'+mt[i].SenderID+'.jpg';
}
var Chat = new Vue({
    el: '#root',
    data: {
        items: mt
    },
    methods: {
		Social: function(id){
		    window.open("social/"+id);
		}
	}
});


</script>

</html>