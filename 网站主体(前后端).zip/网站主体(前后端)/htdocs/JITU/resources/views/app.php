<!doctype html>
<html lang="ZH">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>JTalk APP</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="../../JT.ico" />
        <link rel="shortcut icon" href="../../JT.ico" type="image/x-icon">

        <!-- Styles -->
        <style>
            html,body{background: #FFFDE2;}
            .logo{margin: 80px auto 12px; width: 140px; height: 140px; border-radius: 10px; box-shadow: 1px 5px 5px #dbdbdb}
            .title{
                border-bottom: 1px solid rgba(0,0,0,0.2); 
                color: rgba(0,0,0,0.6);
                padding-bottom: 6px;
                width: 180px;
                margin: auto auto 20px;
                font-size: 20px;
				text-shadow: 1px 5px 5px #dbdbdb
            }
            .btn{line-height: 28px; margin: auto; width: 180px; border-radius: 6px; padding: 8px 20px; color: #fdb216; background: #FFF}
            a{display: block;}
			a img{border-radius: 8px; width: 240px; margin: auto ;text-align: center; margin-top: 23px; box-shadow: 1px 5px 5px #dbdbdb}
		</style>
    </head>
    <body>
        <div style="text-align: center">
            <img class="logo" src="../../imgs/AppLogo.png">
            <p class="title">聊天交友 网上购物</p>
            <a href="https://play.google.com/store/apps/details?id=com.z969977237.hvo"><img src="../../download1.png"></a>
			<a href="http://jitu.fun/comming/"><img src="../../download2.png"></a>
			<a href="https://pan.baidu.com/s/1IDqZ7plyS6X7urYX81GYvg "><img src="../../download3.png"></a>
			<p>(提取码/DeCode：3u1e)</p>
        </div>
    </body>
	<script>
var browser = {
      versions: function () {
        var u = navigator.userAgent,
          app = navigator.appVersion;
        // alert(u);
        return {
          trident: u.indexOf('Trident') > -1,
          /*IE内核*/
          presto: u.indexOf('Presto') > -1,
          /*opera内核*/
          webKit: u.indexOf('AppleWebKit') > -1,
          /*苹果、谷歌内核*/
          gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,
          /*火狐内核*/
          mobile: !!u.match(/AppleWebKit.*Mobile.*/),
          /*是否为移动终端*/
          ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
          /*ios终端*/
          android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1,
          /*android终端或者uc浏览器*/
          iPhone: u.indexOf('iPhone') > -1,
          /*是否为iPhone或者QQHD浏览器*/
          iPad: u.indexOf('iPad') > -1,
          /*是否iPad*/
          webApp: u.indexOf('Safari') == -1,
          /*是否web应该程序，没有头部与底部*/
          souyue: u.indexOf('souyue') > -1,
          superapp: u.indexOf('superapp') > -1,
          /**微信浏览器 */
          weixin: u.toLowerCase().indexOf('micromessenger') > -1,
          Safari: u.indexOf('Safari') > -1,
          myqq: navigator.userAgent.indexOf('QQ') > -1,
          /**uc浏览器 */
          UCBrowser: navigator.userAgent.indexOf('UCBrowser') > -1
        };
      }()
// language: (navigator.browserLanguage || navigator.language).toLowerCase()
};
/**微信/qq */
if (browser.versions.weixin) {
if (browser.versions.ios) {
this.iosA = true;
this.andoridA = false;
}
else {
this.iosA = false;
this.andoridA = true;
}
/**显示提示 */
alert("请使用浏览器打开下载 / Please open by using the browser")
}
else if (browser.versions.ios) {
if (browser.versions.myqq) {
this.iosA = true;
this.andoridA = false;
/**显示提示 */
alert("请使用浏览器打开下载 / Please open by using the browser")
} else {
//window.open("jtalk://?MID=1");
window.location.href = "jtalk://?MID=1";
}
 
} else if (browser.versions.android) {
if(browser.versions.UCBrowser){
window.location.href = "jtalk://?MID=1";
}else{
window.location.href = "jtalk://?MID=1";
//window.open("jtalk://?MID=1");
}
 
}

	</script>
</html>
