﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
	
    <meta name="description" content="{{ $value->name }} | {{ trans('goods.1') }}">
	
    <meta name="author" content="Andy">
	<title>{{ $value->name }}</title>
	<link rel="stylesheet" type="text/css" href="../../css/Goods.css">
	<link rel="icon" type="image/x-icon" href="../../JT.ico" />
	<link rel="shortcut icon" href="../../JT.ico" type="image/x-icon">
</head>

<body style="max-width: 770px; margin: auto">
<header style="text-align: center">
		<img style="max-width: 500px; max-height: 500px" src="{{ config('Qsetting.IMG_url') }}goods/{{ $value->img }}.jpg">
	</header>

	<div class="content">
	    <h4>{{ $value->name }}</h4>
		<div class="share">{{ trans('goods.2') }}</div>
		<div class="des">{!! $value->info !!}</div>
	    <div class="money-box">
			<p>RM <b>{{ $value->Price }}</b></p>
		</div>
		<div class="detail-box">
			<div>{{ trans('goods.3') }} <span>FREE</span></div>
			<div style="text-align: right">{{ trans('goods.4') }} {{ $value->sold }}</div>
		</div>
		<div></div>
	</div>

	<!--  <div class="shareBtn">分享一下 ！</div>  -->

	<div class="btmBox">
		<div class="c1">{{ trans('goods.2') }}</div>
		<div class="c2" onclick="toStore({{ $value->SID }})">{{ trans('goods.5') }}</div>
	</div>

</body>

<script type="text/javascript" src="../../js/vue.js"></script>
<script type="text/javascript" src="../../js/jquery.min.js"></script>
<script type="text/javascript" src="../../js/fly.js"></script>
<script src="../../js/vue-lazyload.js"></script>
<script>
    function toStore(id){
		window.location.href = "../store/"+id;
	}
</script>

</html>