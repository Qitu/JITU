﻿<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Social, UKM">
    <meta name="description" content="JITU Platform">
	<meta name="theme-color" id="theme_color" content="#fdb216" />
    <meta name="author" content="Andy">
	<title>JITU</title>
	<link rel="stylesheet" type="text/css" href="../../css/Lobby.css">
	<script src="../../js/iconfont.js"></script>
	<link rel="icon" type="image/x-icon" href="../../JT.ico" />
	<link rel="shortcut icon" href="../../JT.ico" type="image/x-icon">
	<style>
	    header{height: 50px; background: #fdb216; position: absolute}
		header .left{margin-top: 12px}
		header .right{margin-top: 12.5px; color: #FFF;}
		.btn{width: 200px; display: block; padding: 6px 7px; font-size: 13px; font-weight: 700}
		.info-container{margin: 58px 15px;} .info-container img{display: inline-block}
		.info-container .commad{display: inline-block; position: relative; left: 8px; top: -6.5px; line-height: 18px}
		.info-container .commad p{margin: 0; color: #999; font-size: 12px;} .info-container .commad h4{font-weight: 400; font-size: 13px; margin: 0}
		.info-container span{vertical-align: top; position: relative; left: 8px; top: 10.5px; font-weight: 700; font-size: 13px;}
		.info-container .right{float: right; color: #fdb216; border-radius: 6px; font-size: 13px; margin-top: 7px; padding: 3.5px 12px;} .info-container .right:active{background: #fdb216; color: #FFF}
		.info-container .detail{font-size: 14px; line-height: 25px; color: #373736; margin-top: 15px} .info-container .cm{margin-left: 50px}
		.info-container .reply{margin-top: 15px; margin-left: 50px; background: #f5f5f5; border-radius: 8px; padding: 12px 12px 36px; font-size: 13px; color: #aaa9aa} .info-container .reply p{font-weight: 400; line-height: 24px; margin: 0}
		.info-container .reply .rt{float: right; margin: 6px; color: #ff7f50; cursor: pointer}
		.user-img{width: 40px; height: 40px; border-radius: 50%;}
		.info-container ul{display: block; padding-left: 0; margin-top: 25px}
		.info-container ul li {display: inline-block; width: 32.33%; }
		.info-container ul li img{width: 100% }
		hr{ border: 0; height: 0; margin: auto; width: 90%; border-top: 1px solid rgba(0,0,0,0.1); border-bottom: 1px solid rgba(255,255,255,0.3);}
		.adv{display: none; line-height: 25px; position: fixed; bottom: 30px; background: #fdb216; box-shadow: 1px 1px 3px rgba(0,0,0,0.2); left: 50%; transform: translate3d(-50%, 0, 0); z-index: 20; font-size: 13px; padding: 10px 18px; color: #FFF; border-radius: 5em}
	    .adv img{background: #FFF; width: 30px; padding: 2px; border-radius: 5em; position: relative; top: 3.5px}		
		.icon {vertical-align: -0.15em; fill: currentColor; overflow: hidden; width: 20px; height: 20px;}
		.tags{border-radius: 5em; background: #fdb216; color: #FFF; padding: 5px 10px; margin: 8px 6px 8px 0; font-size: 12px;}
	</style>
</head>

<body>
<div class="adv"><img src="../../imgs/{{ trans('social.logo') }}.png"> {{ trans('social.5') }}</div>

<header>
    <div class="left"><a href="../home"><img src="../../imgs/Y{{ trans('social.logo') }}.png"></a></div>
	<div class="right">{{ trans('social.1') }}</div>
</header>
<div class="loader">
    <div class="spinner">
       <div class="double-bounce1"></div>
       <div class="double-bounce2"></div>
    </div>
</div>


<div id="body">

 <div class="section pc">
    
	<div style="text-align: center; margin: 80px auto 40px">
	    <img style="box-shadow: 0px 1px 4px rgba(0,0,0,0.1); border-radius: 50%; width: 120px; height: 120px" src="{{ config('Qsetting.IMG_url') }}users/{{ $recom[0]->SenderID }}.jpg">
		<h3>{{ $recom[0]->user }}</h3>
	</div>

	
	
	
	
	<p class="title pchide"><b>动态 </b>{{ $ct }}</p>
	<hr><br>
	<div id="root">
	
	<div class="item" v-for="item in items" v-on:click="Social(item.MomentID)">
        <img class="itemImg" v-lazy="item.img" alt=""/>
        <div class="userInfo">
            <div class="head" v-text="item.title"></div>
			<div class="detail">
			    <div><img class="itemImg" v-lazy="item.userimg" alt=""> <span v-text="item.user"></span></div>
				<div class="like"><svg class="icon" style="width: 20px; height: 20px; " aria-hidden="true"><use xlink:href="#icon-aixin1"></use></svg> <p v-text="item.Like" style="display: inline-block; margin: 0px"></p></div>
			</div>
        </div>
    </div>
	
</div>
</div>

</div>
<script src="../../js/zooming.js"></script>
<script>
      // Listen to images after DOM content is fully loaded
      document.addEventListener('DOMContentLoaded', function () {
        new Zooming({
          // options...
        }).listen('.img-zoomable')
      })
</script>
</body>
<script type="text/javascript" src="../../js/vue.js"></script>
<script type="text/javascript" src="../../js/jquery.min.js"></script>
<script src="../../js/vue-lazyload.js"></script>

<script>

Vue.use(VueLazyload);

function Gshow(){
	$("body").css("overflow","hidden");
	$('.Goodsdetail').fadeIn();
}

function Ghide(){
	$("body").css("overflow","auto");
	$('.Goodsdetail').fadeOut();
}

var c2c = false;
function c1(){
	if(c2c == false) {
		Ghide();
		}
	c2c = false;
}

function c2(){
	c2c = true;
}

function bk(){
	Ghide();
	c2c = false;
}

 $(document).ready(function(){
	$('.loader').hide();
	$(window).scroll(function(){
	    var scrollTop=$(this).scrollTop();
	    if(scrollTop >= 60 ) $('.adv').show();
		else $('.adv').hide();
	});


});


function reEdit(str){
	var clean = str.replace(/{a}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-a"></use></svg> ').
	replace(/{bizui}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-bizui"></use></svg> ').
	replace(/{baiyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-baiyan"></use></svg> ').
	replace(/{aixin}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-aixin"></use></svg> ').
	replace(/{dajing}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-dajing"></use></svg> ').
	replace(/{ziya}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-ziya"></use></svg> ').
	replace(/{daxiao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-daxiao"></use></svg> ').
	replace(/{esi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-esi"></use></svg> ').
	replace(/{fadai}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fadai"></use></svg> ').
	replace(/{fankun}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fankun"></use></svg> ').
	replace(/{ganga}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-ganga"></use></svg> ').
	replace(/{fennu}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fennu"></use></svg> ').
	replace(/{hanyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-hanyan"></use></svg> ').
	replace(/{jingkong}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-jingkong"></use></svg> ').
	replace(/{haochi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-haochi"></use></svg> ').
	replace(/{emo}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-emo"></use></svg> ').
	replace(/{jingsong}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-jingsong"></use></svg> ').
	replace(/{jingya}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-jingya"></use></svg> ').
	replace(/{kaixin}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-kaixin"></use></svg> ').
	replace(/{lengku}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-lengku"></use></svg> ').
	replace(/{danao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-danao"></use></svg> ').
	replace(/{liukoushui}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liukoushui"></use></svg> ').
	replace(/{liulei}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liulei"></use></svg> ').
	replace(/{mengbi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-mengbi"></use></svg> ').
	replace(/{mianwubiaoqing}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-mianwubiaoqing"></use></svg> ').
	replace(/{nanguo}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-nanguo"></use></svg> ').
	replace(/{shuizhuo}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shuizhuo"></use></svg> ').
	replace(/{taoyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-taoyan"></use></svg> ').
	replace(/{tanchi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tanchi"></use></svg> ').
	replace(/{siliao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-siliao"></use></svg> ').
	replace(/{tiaopi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tiaopi"></use></svg> ').
	replace(/{xiaochulei}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiaochulei"></use></svg> ').
	replace(/{wuliao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-wuliao"></use></svg> ').
	replace(/{xingxingyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xingxingyan"></use></svg> ').
	replace(/{xieyan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xieyan"></use></svg> ').
	replace(/{xiasi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiasi"></use></svg> ').
	replace(/{xiaolian}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiaolian"></use></svg> ').
	replace(/{ku}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-ku"></use></svg> ').
	replace(/{shengqi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shengqi"></use></svg> ').
	replace(/{yousiliao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-yousiliao"></use></svg> ').
	replace(/{en}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-en"></use></svg> ').
	replace(/{bushufu}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-bushufu"></use></svg> ').
	replace(/{bianbian}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-bianbian"></use></svg> ').
	replace(/{fankun1}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fankun1"></use></svg> ').
	replace(/{feiwen}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-feiwen"></use></svg> ').
	replace(/{ganmao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-ganmao"></use></svg> ').
	replace(/{huaixiao}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-huaixiao"></use></svg> ').
	replace(/{liuhan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liuhan"></use></svg> ').
	replace(/{outu}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-outu"></use></svg> ').
	replace(/{keshui}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-keshui"></use></svg> ').
	replace(/{renzhe}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-renzhe"></use></svg> ').
	replace(/{santiaoxian}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-santiaoxian"></use></svg> ').
	replace(/{guaiwu}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-guaiwu"></use></svg> ').
	replace(/{shoushang}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shoushang"></use></svg> ').
	replace(/{tianshi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-tianshi"></use></svg> ').
	replace(/{shuai}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shuai"></use></svg> ').
	replace(/{xianwen}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xianwen"></use></svg> ').
	replace(/{xiaodiaodaya}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiaodiaodaya"></use></svg> ').
	replace(/{xiong}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xiong"></use></svg> ').
	replace(/{yiwen}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-yiwen"></use></svg> ').
	replace(/{yun}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-yun"></use></svg> ').
	replace(/{liubixie}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-liubixie"></use></svg> ').
	replace(/{shimo}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shimo"></use></svg> ').
	replace(/{dianzan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-dianzan"></use></svg> ').
	replace(/{biti}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-biti"></use></svg> ').
	replace(/{fendou}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-fendou"></use></svg> ').
	replace(/{huqi}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-huqi"></use></svg> ').
	replace(/{heng}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-heng"></use></svg> ').
	replace(/{kulou}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-kulou"></use></svg> ').
	replace(/{leng}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-leng"></use></svg> ').
	replace(/{taoyan1}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-taoyan1"></use></svg> ').
	replace(/{shuixing}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shuixing"></use></svg> ').
	replace(/{aini}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-aini"></use></svg> ').
	replace(/{aixin1}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-aixin1"></use></svg> ').
	replace(/{zhadan}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-zhadan"></use></svg> ').
	replace(/{xinsui}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-xinsui"></use></svg> ').
	replace(/{maren}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-maren"></use></svg> ').
	replace(/{zhutou}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-zhutou"></use></svg> ').
	replace(/{qie}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-qie"></use></svg> ').
	replace(/{youling}/g,' <svg class="icon" aria-hidden="true"><use xlink:href="#icon-youling"></use></svg> ').
	replace(/&B/g,' ').
	replace(/&/g,' ');
	return clean;
}


var dtt = {!!  json_encode($recom) !!};

for (var i = 0; i < dtt.length; i++) {
		dtt[i].img = '{{ config('Qsetting.IMG_url') }}moments/'+dtt[i].MomentID+'-1.jpg';
		dtt[i].userimg = '{{ config('Qsetting.IMG_url') }}users/'+dtt[i].SenderID+'.jpg';
		dtt[i].title = reEdit(dtt[i].title);
}

/*{ img: '../imgs/test.png', title: 'Java教学', user:'大湿兄', like: 638} */

var Chat = new Vue({
  el: '#root',
  data: {
    items: dtt
  },
  methods: {
		    Social: function(id){
				window.location.href="../social/"+id;
		    }
	}
});

</script>
</html>