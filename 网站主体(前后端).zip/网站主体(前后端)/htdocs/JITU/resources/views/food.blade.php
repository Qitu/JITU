﻿
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
    <meta name="description" content="JITU Platform">
    <meta name="author" content="Andy">
	<title>JITU</title>
	<link rel="stylesheet" type="text/css" href="../css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../css/Lobby.css">
	<link rel="icon" type="image/x-icon" href="../JT.ico" />
	<link rel="shortcut icon" href="../JT.ico" type="image/x-icon">
</head>
<style>
    a{text-decoration: none; color: rgba(1,1,1,1)}
</style>
<body>

<header>
    <div class="left"><img src="{{ trans('food.logo') }}.png"></div>
	<a href="app"><div class="right">{{ trans('food.1') }}</div></a>
	<ul class="PCcategory">
	    <li><a href="home">{{ trans('food.2') }}</a></li>
	    <li style="font-weight:700; color: #fdb216; border-bottom: 3px solid #fdb216;">{{ trans('home.3') }}</li>
	    <li><a href="events">{{ trans('food.4') }}</a></li>
	</ul>
</header>
<div class="loader">
    <div class="spinner">
       <div class="double-bounce1"></div>
       <div class="double-bounce2"></div>
    </div>
</div>


<div id="body">

<ul class="category">
<li><a href="home">{{ trans('food.2') }}</a></li>
<li class="active">{{ trans('food.3') }}</li>
<li><a href="events">{{ trans('food.4') }}</a></li>
</ul>

<div class="swiper-container">
    <div class="swiper-wrapper">
      <a href="store/1"><div class="swiper-slide"><img src="../imgs/banner2.jpg"></div></a>
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
 </div>



	
	<div id="root" style="margin: 50px auto 15px auto; max-width: 700px">
	
	<div class="item" v-for="item in items" v-on:click="Social(item.ID)">
        <img class="itemImg" v-lazy="item.img" alt=""/>
        <div class="userInfo">
            <div class="head" v-text="item.title"></div>
			<div class="detail">
			    <div><span style="font-weight: 700" v-text="item.size"></span></div>
				<div class="like" style="color: #fdb216">{{ trans('food.7') }} <nor v-text="item.price"></nor></div>
			</div>
        </div>
    </div>
</div>
	<div id="smart" style="text-align: center">
	    <a class="btn" href="app">{{ trans('food.8') }}</a>
	</div>

<div id="ml" style="text-align: center;">
	<a class="btn" href="app">{{ trans('food.8') }}</a>
</div>

</div>
<script  type="text/javascript" src="../js/swiper.min.js"></script>
<script>
    var swiper = new Swiper('.swiper-container', {
      spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      }
    });
  </script>
</body>
<script type="text/javascript" src="../js/vue.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script src="../js/vue-lazyload.js"></script>
<script>

Vue.use(VueLazyload);

function Gshow(){
	$("body").css("overflow","hidden");
	$('.Goodsdetail').fadeIn();
}

function Ghide(){
	$("body").css("overflow","auto");
	$('.Goodsdetail').fadeOut();
}

var c2c = false;
function c1(){
	if(c2c == false) {
		Ghide();
		}
	c2c = false;
}

function c2(){
	c2c = true;
}

function store(){
	var ID = $('#GID').text();
	window.location.href="store";
}

function bk(){
	Ghide();
	c2c = false;
}


 $(document).ready(function(){
	$('.loader').hide();
});

var dt = {!!  json_encode($value) !!};


for (var i = 0; i < dt.length; i++) {
		dt[i].img = '{{ config('Qsetting.IMG_url') }}goods/'+dt[i].img+'.jpg';
}
	
var Chat = new Vue({
  el: '#root',
  data: {
    items: dt
  },
  methods: {
		    Social: function(id){
				window.location.href="goods/"+id;
		    }
	}
});

</script>
</html>