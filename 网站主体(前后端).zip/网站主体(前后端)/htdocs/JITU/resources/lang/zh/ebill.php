<?php

return [
    'logo' => '../imgs/Logo2.png',
    '1' => '验证码',
    '2' => '使用',
    '3' =>'APP获得更多票据信息'
];
