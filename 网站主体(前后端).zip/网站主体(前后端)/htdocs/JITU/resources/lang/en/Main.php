<?php

return [
    'logo' => '../imgs/Logo2',
    'header1' => 'Discovery more fun in',
    'header2' =>'In UKM area, Enjoy the social chat in universities, feel the fire in JTalk clubs',
    'header3' =>'DOWNLOAD APP',
    'rec1' =>'Recommendation',
    'rec2' =>'Having wonderful shopping exp in',
    'mom1' =>'JTalking',
    'mom2' =>"See what's freash",
    'mom3' =>'Learn More',
    'act1' =>'Club activities',
    'act2' =>'The comming awesome',
    'footer1' =>'JTalk is a...',
    'footer2' =>'Follow Us',
    'footer3' =>'Relative Links',
    'footer4' =>'Contact',
    
    'block1' =>'Monthly Access',
    'block2' =>'Dealed Orders',
    'block3' =>'Social Moments',
    'block4' =>'Positive Feedback',
    
    'join1' =>'To be our familly',
    'join2' =>'We are providing the best',
    'join3' =>'creative services',
    'join4' =>'Enjoy the Chinese halal restrant and all the stores in JITU Mall',
    'join5' =>'JITU Official championship 《JITU Cup－Honor of King》 at May',
    'join6' =>'Keep doing a valuable thing with all the university students/Drs',
    'join7' =>'Be with your Dr in activity clubs',
];
