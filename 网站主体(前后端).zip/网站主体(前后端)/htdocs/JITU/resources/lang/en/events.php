<?php

return [
    'logo' => '../imgs/Logo',
    '1' => 'Open APP',
    '2' =>'Recommend',
    '3' =>'JTMall',
    '4' =>'Activities',
    '5' =>'Deadline：',
    '6' =>' days',
    '7' =>'Use JITU APP to get more fun ！',
];
