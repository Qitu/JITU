<?php

return [
    'logo' => '../imgs/Logo.png',
    '1' => '‘s order',
    '2' =>'Order created successfully',
    '3' =>'Delivery fee',
    '4' =>'Total',
    '5' =>'Payment',
    '6' =>'Supported'
];
