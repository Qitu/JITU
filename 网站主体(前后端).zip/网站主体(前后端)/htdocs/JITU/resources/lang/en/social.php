<?php

return [
    'logo' => 'Logo',
    '1' => 'Open APP',
    '2' => 'Subscribe',
    '3' => 'Comments',
    '4' => 'Open JITU to see more',
    '5' => 'Open by JITU APP',
    '6' => 'Recommended to you',
    '7' => 'Social chat',
    '8' => 'Open JITU APP to get more fun ！',
    '9' => 'Visit store',
    '10' => 'Back',
    '11' => 'Sold',
    '12' => 'Like'
];
