<?php

return [
    'logo' => '../imgs/Logo2.png',
    '1' => 'VerCode',
    '2' => 'Use',
    '3' =>'APP to get more ticket info.'
];
