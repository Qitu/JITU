<?php

return [
    'logo' => '../imgs/Logo',
    '1' => 'Open APP',
    '2' =>'Recommend',
    '3' =>'JTMall',
    '4' =>'Activities',
    '5' =>'Collections',
    '6' =>'see more',
    '7' =>'RM',
    '8' =>'Use JITU APP to get more fun ！',
];
