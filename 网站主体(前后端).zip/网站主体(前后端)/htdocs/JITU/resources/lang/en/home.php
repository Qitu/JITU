<?php

return [
    'logo' => '../imgs/Logo',
    '1' => 'Open APP',
    '2' =>'Recommend',
    '3' =>'JTMall',
    '4' =>'Activities',
    '5' =>'Collections',
    '6' =>'see more',
    '7' =>'Social chat',
    '8' =>'Use JITU APP to get more fun ！',
    '9' =>'Go ！',
    '10' =>'Back',
    '11' =>'Sold',
    '12' =>'Like'
];
