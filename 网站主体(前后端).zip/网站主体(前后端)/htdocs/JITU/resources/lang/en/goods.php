<?php

return [
    'logo' => '../imgs/Logo2.png',
    '1' => 'description',
    '2' => 'Share',
    '3' =>'Delivery fee',
    '4' =>'Sold',
    '5' =>'Visit Store'
];
