﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
	
    <meta name="description" content="<?php echo e($value->name); ?> | 简介">
	
    <meta name="author" content="Andy">
	<title><?php echo e($value->name); ?></title>
	<link rel="stylesheet" type="text/css" href="../css/Goods.css">
	<link rel="icon" type="image/x-icon" href="../JT.ico" />
	<link rel="shortcut icon" href="../JT.ico" type="image/x-icon">
</head>

<body>
    <header>
		<img src="https://jitugoods.oss-ap-southeast-3.aliyuncs.com/goods/<?php echo e($value->img); ?>.jpg">
	</header>

	<div class="content">
	    <h4><?php echo e($value->name); ?></h4>
		<div class="share">分享</div>
		<div class="des"><?php echo $value->info; ?></div>
	    <div class="money-box">
			<p>RM <b><?php echo e($value->Price); ?></b></p>
		</div>
		<div class="detail-box">
			<div>运费 <span>免运费</span></div>
			<div style="text-align: right">已售 <?php echo e($value->sold); ?></div>
		</div>
		<div></div>
	</div>

	<!--  <div class="shareBtn">分享一下 ！</div>  -->

	<div class="btmBox">
		<div class="c1">分享</div>
		<div class="c2" onclick="toStore(<?php echo e($value->SID); ?>)">进店购买</div>
	</div>

</body>

<script type="text/javascript" src="../js/vue.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/fly.js"></script>
<script src="../js/vue-lazyload.js"></script>
<script>
    function toStore(id){
		window.location.href = "../store/"+id;
	}
</script>

</html><?php /**PATH D:\LocalServer\XAMPP\htdocs\JITU\resources\views/goods.blade.php ENDPATH**/ ?>