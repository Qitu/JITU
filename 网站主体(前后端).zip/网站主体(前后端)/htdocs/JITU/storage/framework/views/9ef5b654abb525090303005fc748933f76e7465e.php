<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
    <meta name="description" content="JITU Platform">
	<meta name="author" content="Andy">
	<meta name="theme-color" id="theme_color" content="#fdb216" />
	<title>收据 - XXX</title>
	<link rel="stylesheet" href="../css/eBill.css">
	
    
	<link rel="icon" type="image/x-icon" href="../JT.ico" />
	<link rel="shortcut icon" href="../JT.ico" type="image/x-icon">

</head>

<body>
	<div class="card">
	    <img class="title" src="../imgs/banner.jpg">
		<div class="if">
		    <p><?php echo e($value->ZH_Name); ?></p>
		    <p><?php echo e($value->CreatedDate); ?></p>
		    <p><?php echo e($value->EType); ?></p>
		</div>
		<div style="text-align: center;">
		    <h4>验证码： <?php echo e($value->TID); ?></h4>
			<img src="../imgs/testQR.png">
		</div>
	</div>

	<h5 style="height: 50px; text-align: center; color: rgba(0,0,0,0.2)">使用 <img style="height: 19px;vertical-align: top; opacity: 0.8" src="../imgs/Logo2.png"> APP获取票据详情信息</h5>

</body>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/vue.js"></script>
<script type="text/javascript" src="../js/vue-lazyload.js"></script>
<script>

</script>
</html><?php /**PATH D:\LocalServer\XAMPP\htdocs\JITU\resources\views/ebill.blade.php ENDPATH**/ ?>