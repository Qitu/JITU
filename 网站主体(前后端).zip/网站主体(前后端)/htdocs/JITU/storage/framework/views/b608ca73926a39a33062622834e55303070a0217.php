﻿<?php
  $lang = 'ZH';
  if($lang == 'ZH' || $lang == 'EN'){
  $L = array(
        'ZH'=>array(
		    'Logo2','打开APP','关注','评论','打开积土APP，浏览全部回复','APP内打开','猜你喜欢','社区交流','使用积土APP, 查看更多精彩内容','进店瞧瞧','返回','已售','赞'
		),
		'EN'=>array(
		    'Logo','Open APP','Subscribe','comments','Use APP to see all the replies','Open APP','See more','Social chat','Use JITU APP to get more fun!','Enter this store','Back','Sold','Like'
		)
  );
  }else exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Social, UKM">
    <meta name="description" content="JITU Platform">
	<meta name="theme-color" id="theme_color" content="#fdb216" />
    <meta name="author" content="Andy">
	<title>JITU</title>
	<link rel="stylesheet" type="text/css" href="../css/Lobby.css">
	<script src="../js/iconfont.js"></script>
	<link rel="icon" type="image/x-icon" href="../JT.ico" />
	<link rel="shortcut icon" href="../JT.ico" type="image/x-icon">、
	<style>
	    header{height: 50px; background: #fdb216; position: absolute}
		header .left{margin-top: 12px}
		header .right{margin-top: 12.5px; color: #FFF;}
		.btn{width: 200px; display: block; padding: 6px 7px; font-size: 13px; font-weight: 700}
		.info-container{margin: 45px 15px;} .info-container img{display: inline-block}
		.info-container .commad{display: inline-block; position: relative; left: 8px; top: -6.5px; line-height: 18px}
		.info-container .commad p{margin: 0; color: #999; font-size: 12px;} .info-container .commad h4{font-weight: 400; font-size: 13px; margin: 0}
		.info-container span{vertical-align: top; position: relative; left: 8px; top: 10.5px; font-weight: 700; font-size: 13px;}
		.info-container .right{float: right; color: #fdb216; border-radius: 6px; font-size: 13px; margin-top: 7px; padding: 3.5px 12px;} .info-container .right:active{background: #fdb216; color: #FFF}
		.info-container .detail{font-size: 14px; line-height: 25px; color: #373736; margin-top: 15px} .info-container .cm{margin-left: 50px}
		.info-container .reply{margin-top: 15px; margin-left: 50px; background: #f5f5f5; border-radius: 8px; padding: 12px 12px 36px; font-size: 13px; color: #aaa9aa} .info-container .reply p{font-weight: 400; line-height: 24px; margin: 0}
		.info-container .reply .rt{float: right; margin: 6px; color: #ff7f50; cursor: pointer}
		.user-img{width: 40px; height: 40px; border-radius: 50%;}
		.info-container ul{display: block; padding-left: 0; margin-top: 25px}
		.info-container ul li {display: inline-block; width: 32.33%; }
		.info-container ul li img{width: 100% }
		hr{ border: 0; height: 0; margin: auto; width: 90%; border-top: 1px solid rgba(0,0,0,0.1); border-bottom: 1px solid rgba(255,255,255,0.3);}
		.adv{display: none; line-height: 25px; position: fixed; bottom: 30px; background: #fdb216; box-shadow: 1px 1px 3px rgba(0,0,0,0.2); left: 50%; transform: translate3d(-50%, 0, 0); z-index: 20; font-size: 13px; padding: 10px 18px; color: #FFF; border-radius: 5em}
	    .adv img{background: #FFF; width: 30px; padding: 2px; border-radius: 5em; position: relative; top: 3.5px}		
		.icon {vertical-align: -0.15em; fill: currentColor; overflow: hidden;}
	</style>
</head>

<body>
<div class="adv"><img src="../imgs/Logo2.png"> <?php echo $L[$lang][5]; ?></div>

<header>
    <div class="left"><img src="../imgs/YLogo2.png"></div>
	<div class="right"><?php echo $L[$lang][1]; ?></div>
</header>
<div class="loader">
    <div class="spinner">
       <div class="double-bounce1"></div>
       <div class="double-bounce2"></div>
    </div>
</div>


<div id="body">

 <div class="section pc">
    
	<div class="info-container">
	    <img class="user-img" src="../imgs/test.png"> <span><?php echo e($m->Sender); ?></span>
		<div class="right" style="border: 1px solid #fdb216; "><?php echo $L[$lang][2]; ?></div>
		
		<div class="detail">
		 <svg class="icon" style="width: 20px; height: 20px; " aria-hidden="true"><use xlink:href="#icon-huaixiao"></use></svg> 
		 <?php echo e($m->Content); ?>

		</div>
		<ul>
		<?php if(($m->Pictures) > 0): ?>
		    <?php for($i = 1; $i <= ($m->Pictures); $i++): ?>
			    <li style="width: <?php echo e($Pstyle); ?>"><img class='img-zoomable' src="https://jitugoods.oss-ap-southeast-3.aliyuncs.com/moments/<?php echo e($m->MomentID); ?>-<?php echo e($i); ?>.jpg" data-original="https://jitugoods.oss-ap-southeast-3.aliyuncs.com/moments/<?php echo e($m->MomentID); ?>-<?php echo e($i); ?>.jpg" /></li>
		        <!-- 待添加 水印系统 -->
			<?php endfor; ?>
		<?php endif; ?>	
		</ul>
	</div>
	
	
	
	
	<p class="title"><b>521 </b><?php echo $L[$lang][3]; ?></p>
	<hr>


	<?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	   <div class="info-container" style="margin-top: 20px">
	        <img class="user-img" src="../imgs/test.png"> <div class="commad"><h4><?php echo e($com->User); ?></h4><p><?php echo e($com->PostDate); ?></p></div>
		    <div class="right"><svg class="icon" style="width: 20px; height: 20px; " aria-hidden="true"><use xlink:href="#icon-aixin1"></use></svg></div>
			
			<div class="detail cm">
			    <?php echo e($com->CommentContent); ?>

			</div>
			<?php if(count($r) > 0): ?>
			<div class="reply">
			    <?php $__currentLoopData = $r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <?php if($reply->CID == $com->UserID): ?>
			            <p><?php echo e($reply->FromName); ?> : <?php echo e($reply->ContentR); ?></p>
				    <?php endif; ?>	
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<a class="rt"><?php echo $L[$lang][4]; ?> ></a>
			</div>
			<?php endif; ?>	
	    </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



	
	<div id="smart" style="text-align: center; margin-top: 40px; margin-bottom: 50px;">
	    <a class="btn"><?php echo $L[$lang][4]; ?></a>
	</div>
	
	
	<hr>
	
	

    <p class="title pchide"><?php echo $L[$lang][6]; ?></p>
	
	<div id="root">
	
	<div class="item" v-for="item in items">
        <img class="itemImg" v-lazy="item.img" alt=""/>
        <div class="userInfo">
            <div class="head" v-text="item.title"></div>
			<div class="detail">
			    <div><img src="../imgs/test.png"> <span v-text="item.user"></span></div>
				<div class="like"><svg class="icon" style="width: 20px; height: 20px; " aria-hidden="true"><use xlink:href="#icon-aixin1"></use></svg> <p v-text="item.Like"></p></div>
			</div>
        </div>
    </div>
	
</div>
</div>

</div>
<script src="../js/zooming.js"></script>
<script>
      // Listen to images after DOM content is fully loaded
      document.addEventListener('DOMContentLoaded', function () {
        new Zooming({
          // options...
        }).listen('.img-zoomable')
      })
</script>
</body>
<script type="text/javascript" src="../js/vue.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script src="../js/vue-lazyload.js"></script>

<script>

Vue.use(VueLazyload);

function Gshow(){
	$("body").css("overflow","hidden");
	$('.Goodsdetail').fadeIn();
}

function Ghide(){
	$("body").css("overflow","auto");
	$('.Goodsdetail').fadeOut();
}

var c2c = false;
function c1(){
	if(c2c == false) {
		Ghide();
		}
	c2c = false;
}

function c2(){
	c2c = true;
}

function bk(){
	Ghide();
	c2c = false;
}


 $(document).ready(function(){
	$('.loader').hide();
	$(window).scroll(function(){
	    var scrollTop=$(this).scrollTop();
	    if(scrollTop >= 60 ) $('.adv').show();
		else $('.adv').hide();
	});
	
});

var dtt = <?php echo json_encode($recom); ?>;

for (var i = 0; i < dtt.length; i++) {
		dtt[i].img = 'https://jitugoods.oss-ap-southeast-3.aliyuncs.com/moments/'+dtt[i].MomentID+'-1.jpg';
}

/*{ img: '../imgs/test.png', title: 'Java教学', user:'大湿兄', like: 638} */

var Chat = new Vue({
  el: '#root',
  data: {
    items: dtt
  }
});

</script>
</html><?php /**PATH D:\LocalServer\XAMPP\htdocs\JITU\resources\views/social.blade.php ENDPATH**/ ?>