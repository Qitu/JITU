<?php
  $lang = 'ZH';
  if($lang == 'ZH' || $lang == 'EN'){
  $L = array(
        'ZH'=>array(
		    'imgs/Logo2','打开APP','推荐','美食','活动','吃货大厅','查看更多','社区交流','使用积土APP, 查看更多精彩内容','了解一下','返回','已售','赞'
		),
		'EN'=>array(
		    'imgs/Logo','Open APP','Recommend','Food','Activities','Food hall','See more','Social chat','Use JITU APP to get more fun!','Enter this store','Back','Sold','Like'
		)
  );
  }else exit;
?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
    <meta name="description" content="JITU Platform">
    <meta name="author" content="Andy">
	<title>JITU</title>
    <link rel="stylesheet" href="css/swiper.min.css">
	<link rel="stylesheet" href="css/Lobby.css">
    
	<link rel="icon" type="image/x-icon" href="JT.ico" />
	<link rel="shortcut icon" href="JT.ico" type="image/x-icon">
    
	<style>
    a{text-decoration: none; color: rgba(1,1,1,1)}
</style>
</head>

<body>

<div class="Goodsdetail" onclick="c1()">
    <div class="alert" onclick="c2()">
	    <h4 id="Gname"></h4>
		<img id="Gimg" src="imgs/test.png">
		<p>RM <span id="Gprice"></span></p>
		<div id="GID" style="display: none">0</div>
		<div class="go" onclick="store()"><?php echo $L[$lang][9]; ?></div>
		<div class="back" onclick="bk()"><?php echo $L[$lang][10]; ?></div>
	</div>
</div>

<header>
    <div class="left"><img src="<?php echo $L[$lang][0]; ?>.png"></div>
	<div class="right"><?php echo $L[$lang][1]; ?></div>
	<ul class="PCcategory">
	    <li style="font-weight:700; color: #fdb216; border-bottom: 3px solid #fdb216;"><?php echo $L[$lang][2]; ?></li>
	    <li><a href="food"><?php echo $L[$lang][3]; ?></a></li>
	    <li><a href="events"><?php echo $L[$lang][4]; ?></a></li>
	</ul>
</header>
<div class="loader">
    <div class="spinner">
       <div class="double-bounce1"></div>
       <div class="double-bounce2"></div>
    </div>
</div>



<div id="body">

<ul class="category">
<li class="active"><?php echo $L[$lang][2]; ?></li>
<li><a href="food"><?php echo $L[$lang][3]; ?></a></li>
<li><a href="events"><?php echo $L[$lang][4]; ?></a></li>
</ul>

<div class="swiper-container">
    <div class="swiper-wrapper">
      <div class="swiper-slide"><img src="imgs/banner.jpg"></div>
      <div class="swiper-slide"><img src="imgs/banner.jpg"></div>
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
 </div>


<div class="section" id="goods" v-show="items.length > 0">
    <p class="title" onclick="Tmore()"><?php echo $L[$lang][5]; ?>
	    <a><?php echo $L[$lang][6]; ?>></a>
	</p>
	<div class="content">
	    <a v-for="item in items" v-on:click="Goods(item.ID, item.img, item.name, item.Price)">
		    <img v-bind:src="item.img">
			<div class="ginfo">
			    <h4 v-text="item.name"></h4>
				<p><?php echo $L[$lang][11]; ?> <span v-text="item.sold"></span></p>
			</div>
		</a>
	</div>
</div>

<div class="section pc" style="margin-top: 10px">
    <p class="title pchide"><?php echo $L[$lang][7]; ?>
	</p>

	<div id="root">
	
	<div class="item" v-for="item in items" v-on:click="Social(item.ID)">
        <img class="itemImg" v-lazy="item.img" alt=""/>
        <div class="userInfo">
            <div class="head" v-text="item.Content"></div>
			<div class="detail">
			    <div><img class="itemImg" v-lazy="item.userimg"> <span v-text="item.Sender"></span></div>
				<div class="like"><?php echo $L[$lang][12]; ?>  <em v-text="item.Like"></em> </div>
			</div>
        </div>
    </div>
</div>
	<div id="smart" style="text-align: center">
	    <a class="btn"><?php echo $L[$lang][8]; ?></a>
	</div>
</div>

<div id="ml" style="text-align: center;">
	<a class="btn"><?php echo $L[$lang][8]; ?></a>
</div>

</div>
<script type="text/javascript" src="js/swiper.min.js"></script>
<script>
    var swiper = new Swiper('.swiper-container', {
      spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      }
    });
  </script>
</body>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/vue.js"></script>
<script type="text/javascript" src="js/vue-lazyload.js"></script>
<script>

Vue.use(VueLazyload);

function Tmore(){
	window.location.href = "food";
}

function Gshow(){
	$("body").css("overflow","hidden");
	$('.Goodsdetail').fadeIn();
}

function Ghide(){
	$("body").css("overflow","auto");
	$('.Goodsdetail').fadeOut();
}

var c2c = false;
function c1(){
	if(c2c == false) {
		Ghide();
		}
	c2c = false;
}

function c2(){
	c2c = true;
}

function store(){
	var ID = $('#GID').text();
	window.location.href="goods/"+ID;
}

function bk(){
	Ghide();
	c2c = false;
}

var dt = <?php echo json_encode($name); ?>;

for (var i = 0; i < dt.length; i++) {
		dt[i].img = '<?php echo e(config('Qsetting.IMG_url')); ?>goods/'+dt[i].img+'.jpg';
}
	var Goods = new Vue({
		el: '#goods',
		data: {
			items: dt
		},
		methods: {
		    Goods: function(id,img,name,price){
				Gshow();
				$('#GID').text(id);
				$("#Gimg").attr("src",img);
				$('#Gname').text(name);
				$('#Gprice').text(price);
		    }
		}
});

 $(document).ready(function(){
	$('.loader').hide();
});


var mt = <?php echo json_encode($mmt); ?>;
for (var i = 0; i < mt.length; i++) {
	mt[i].img = '<?php echo e(config('Qsetting.IMG_url')); ?>moments/'+mt[i].ID+'-1.jpg';
	mt[i].userimg = '<?php echo e(config('Qsetting.IMG_url')); ?>users/'+mt[i].SenderID+'.jpg';
}

var Chat = new Vue({
  el: '#root',
  data: {
    items: mt
  },
  methods: {
		    Social: function(id){
				window.location.href="social/"+id;
		    }
	}
});

</script>
</html><?php /**PATH D:\LocalServer\XAMPP\htdocs\JITU\resources\views/home.blade.php ENDPATH**/ ?>