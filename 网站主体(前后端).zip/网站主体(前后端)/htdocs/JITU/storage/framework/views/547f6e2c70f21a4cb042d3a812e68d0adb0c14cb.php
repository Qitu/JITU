﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
	
    <meta name="description" content="<?php echo e($value->name); ?> | <?php echo e(trans('goods.1')); ?>">
	
    <meta name="author" content="Andy">
	<title><?php echo e($value->name); ?></title>
	<link rel="stylesheet" type="text/css" href="../../css/Goods.css">
	<link rel="icon" type="image/x-icon" href="../../JT.ico" />
	<link rel="shortcut icon" href="../../JT.ico" type="image/x-icon">
</head>

<body style="max-width: 770px; margin: auto">
<header style="text-align: center">
		<img style="max-width: 500px; max-height: 500px" src="<?php echo e(config('Qsetting.IMG_url')); ?>goods/<?php echo e($value->img); ?>.jpg">
	</header>

	<div class="content">
	    <h4><?php echo e($value->name); ?></h4>
		<div class="share"><?php echo e(trans('goods.2')); ?></div>
		<div class="des"><?php echo $value->info; ?></div>
	    <div class="money-box">
			<p>RM <b><?php echo e($value->Price); ?></b></p>
		</div>
		<div class="detail-box">
			<div><?php echo e(trans('goods.3')); ?> <span>FREE</span></div>
			<div style="text-align: right"><?php echo e(trans('goods.4')); ?> <?php echo e($value->sold); ?></div>
		</div>
		<div></div>
	</div>

	<!--  <div class="shareBtn">分享一下 ！</div>  -->

	<div class="btmBox">
		<div class="c1"><?php echo e(trans('goods.2')); ?></div>
		<div class="c2" onclick="toStore(<?php echo e($value->SID); ?>)"><?php echo e(trans('goods.5')); ?></div>
	</div>

</body>

<script type="text/javascript" src="../../js/vue.js"></script>
<script type="text/javascript" src="../../js/jquery.min.js"></script>
<script type="text/javascript" src="../../js/fly.js"></script>
<script src="../../js/vue-lazyload.js"></script>
<script>
    function toStore(id){
		window.location.href = "../store/"+id;
	}
</script>

</html><?php /**PATH /data/home/gyu3458260001/htdocs/JITU/resources/views/goods.blade.php ENDPATH**/ ?>