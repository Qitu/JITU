﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
	
    <meta name="description" content="活动名">
	
    <meta name="author" content="Andy">
	<title><?php echo e($event->ZH_Name); ?></title>
	
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/iconfont.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/iconfont2.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/eticket.css')); ?>">
	<link rel="icon" type="image/x-icon" href="<?php echo e(URL::asset('./JT.ico')); ?>" />
	<link rel="shortcut icon" href="<?php echo e(URL::asset('./JT.ico')); ?>" type="image/x-icon">
</head>

<body>
    <header>
		<div class="bg-glass"></div>
		<img src="../imgs/test.png">
		<div class="box">
		<div class="title"><?php echo e($event->ZH_Name); ?></div>
		<div class="price"><span>RM</span> <?php echo e($event->Price); ?></div>
		</div>
	</header>

	<div class="content">
		<div class="content-top">
			<p><span class="iconfont icon-check-circle"></span> 官方认证</p> 
			<p><span class="iconfont icon-check-circle"></span> 提供纸质票</p>
		</div>

		<ul>
		    <li>
				<p class="t1"><?php echo e($event->StartDate); ?> ~ <?php echo e($event->EndDate); ?></p>
				<p class="t2">活动时长以现场为准</p>
			</li>
			<li>
				<p class="t1"><?php echo e($t[0]); ?></p>
				<p class="t2"><?php echo e($t[1]); ?></p>
				<span class="iconfont icon-location right"></span>
			</li>
		</ul>

	</div>

	<div class="Einfo">
	    <h4>活动相册</h4>
		<div class="Eimgs">
	        <a>
		        <img src="../imgs/test.png">
			</a>
			<a>
		        <img src="../imgs/test.png">
			</a>
			<a>
		        <img src="../imgs/test.png">
			</a>
			<a>
		        <img src="../imgs/test.png">
			</a>
			<a>
		        <img src="../imgs/test.png">
			</a>
			<a>
		        <img src="../imgs/test.png">
		    </a>
		</div>
		
		<div class="Edetail">
		<?php echo e($event->ZH_Detail); ?>

		</div>
	</div>

	<h4 style="height: 80px; text-align: center; color: rgba(0,0,0,0.2);">
	    <img style="height: 19px;vertical-align: top; opacity: 0.8" src="../imgs/Logo2.png"> 
		提供技术支持
	</h4>


	<div class="bottom">
	     <a href="tel://<?php echo e($event->Contact); ?>"><div class="btn1"><span class="iconfont icon-customerservice"></span><br>联系客服</div></a>
		<div class="btn2" onclick="test()">在线购票</div>
	</div>

	<div class="sec" onclick="c1()">
		<div class="panel" onclick="c2()">
		    <p>选择种类：</p>
		    <ul>
			<?php for($i=0;$i<$kc;$i++): ?>
			    <?php if($i == 0): ?>
				    <li class="Eactive"><?php echo e($k[$i]); ?></li>
				<?php else: ?>
				    <li><?php echo e($k[$i]); ?></li>
			    <?php endif; ?>
			<?php endfor; ?>

			</ul>
	        <div class="btn" onclick="test2()">确认购票</div>
	    </div>
	</div>

	<div class="next"></div>

	<div class="inputBox">
            <div class="back" onclick="back()"><span class="iconfont icon-Stone-arrow-back"></span></div>

		<div>
			<label>用户名</label>
			<input placeholder="如： Sam" />
		</div>

		<div style="margin-top: 30px">
			<label>手机号</label>
			<input placeholder="如： 01234567890" />
		</div>

		<div class="Edone2" onclick="test3()">选择支付方式</div>

	</div>
		

	<div class="payment" id="pay">
            <div class="back" onclick="back2()"><span class="iconfont icon-Stone-arrow-back"></span></div>
	    <div class="Price">
	        <div class="deadline">支付剩余时间 23:59:46</div>
		    <div class="Money">RM<span>152.60</span></div>
		    <div class="detail">花天竺·臻牛2份</div>
	    </div>
	
	    <ul>
	        <li data-name="1" v-on:click="Selc($event)"><img src="../imgs/payments/wechat.png"></li>
		    <li data-name="2" v-on:click="Selc($event)"><img src="../imgs/payments/alipay.png"></li>
		    <li data-name="3" v-on:click="Selc($event)"><img src="../imgs/payments/unionpay.png"></li>
		    <li data-name="4" v-on:click="Selc($event)"><img src="../imgs/payments/mastercard.png"></li>
	    </ul>
	    <div id="pmt"><div class="done" :style="{ background: pay?'#fdb216':'rgba(0,0,0,0.2)' }">开始支付</div>
	    </div>

</div>
	
</body>

<script type="text/javascript" src="<?php echo e(URL::asset('js/vue.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/vue-lazyload.js')); ?>"></script>

<script>
	function test(){
		$('.sec').show();
		$('.panel').addClass("secShow");
		$('html').attr("style","overflow: hidden; height: 100%");
		$('body').attr("style","overflow: hidden; height: 100%");
	}

	function test2(){
		$(".next").addClass('OrderShow2');
		setTimeout(function(){$('.inputBox').fadeIn();},400);
		//setTimeout(function(){$('.payment').fadeIn();},400);
	}

	function test3(){
		$(".next").addClass('OrderShow2');
		$('.payment').fadeIn();
	}

	function back(){
		$(".next").removeClass('OrderShow2');
		$('.inputBox').fadeOut(600);
	}

	function back2(){
		$(".next").removeClass('OrderShow2');
		$('.payment').fadeOut(600);
	}

	var c2c = false;
function c1(){
	if(c2c == false) {
		$('.sec').hide();
		$('.panel').removeClass("secShow");
		$('html').attr("style","overflow: auto");
		$('body').attr("style","overflow: auto");
	}
	c2c = false;
}

function c2(){
	c2c = true;
}

$(".panel ul li").click(function(){
	$(".panel ul li").each(function(){
		$(this).removeClass("Eactive");
		$(this).addClass("Enone");
    });
	$(this).removeClass("Enone");
	$(this).addClass("Eactive");
});
var payBox = new Vue({
  el: '#pay',
  data: {
    payment: 0,
	pay: false
  },
  methods: {
			Selc: function(event){
				$(".payment ul li").each(function(){
					if($(this).hasClass("clicked")) $(this).removeClass('clicked');
				});
				$(event.currentTarget).addClass('clicked');
				payBox.payment = $(event.currentTarget).data("name");
				payBox.pay = true;
			}
	}
});

$(".done").click(function(){
	if(payBox.pay) window.location.href='../ebill';
});

</script>

</html><?php /**PATH /data/home/gyu3458260001/htdocs/JITU/resources/views/eticket.blade.php ENDPATH**/ ?>