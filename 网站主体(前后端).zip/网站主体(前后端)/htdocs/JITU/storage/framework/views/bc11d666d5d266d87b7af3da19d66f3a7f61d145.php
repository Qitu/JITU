﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
	
    <meta name="description" content="XXX的订单">
	<meta name="theme-color" id="theme_color" content="#fdb216" />
	
    <meta name="author" content="Andy">
	<title><?php echo e($value->webClient); ?>的订单</title>
	<link rel="stylesheet" type="text/css" href="../css/Bill.css">
	<link rel="icon" type="image/x-icon" href="../JT.ico" />
	<link rel="shortcut icon" href="../JT.ico" type="image/x-icon">
</head>

<body>
    <header>
		<h2><?php echo e($value->status); ?></h2>
		<p class="des">该订单已确认</p>
		<p class="date"><?php echo e($value->date); ?></p>
	</header>

	<div class="content">
		<img style="width: 80px;" src="../imgs/Logo.png">
		<ul>
		<?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <li>
				<img src="http://jitu.fun/shops/image/<?php echo e($gd->img); ?>.jpg">
				<div class="Ginfo">
				    <p><?php echo e($gd->name); ?></p>
				    <p>x<?php echo e($ct[$gd->GID]); ?></p>
				    <p><span>RM</span> <?php echo e($gd->Price); ?></p>
			    </div>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</ul>
		<br>
		<div class="line"><p class="title">运费</p> <p class="rm"><span>RM</span> <?php echo e(($value->Express) + ($value->Packing)); ?></p></div>
		<div class="line"><p class="title">总价格</p> <p class="rm" style="font-weight: 700; color: #fdb216"><span>RM</span> <?php echo e(($value->Express) + ($value->Packing) + ($value->price)); ?></p></div>
		<div class="line"><p class="title">支付方式</p> <p class="rm"><?php echo e($value->payment); ?></p></div>

	</div>

	<br>
	<h4 style="height: 50px; text-align: center; color: rgba(0,0,0,0.2)"><img style="height: 19px;vertical-align: top; opacity: 0.8" src="../imgs/Logo2.png"> 提供技术支持</h4>

</body>

<script type="text/javascript" src="../js/vue.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script src="../js/vue-lazyload.js"></script>

</html><?php /**PATH D:\LocalServer\XAMPP\htdocs\JITU\resources\views/bill.blade.php ENDPATH**/ ?>