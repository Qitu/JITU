﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
	
    <meta name="description" content="<?php echo e(trans('store.9')); ?> - <?php echo e($store[0]->name); ?>">
	
	<meta name="theme-color" id="theme_color" content="#fdb216" />
    <meta name="author" content="Andy">
	<title><?php echo e($store[0]->name); ?></title>
	<link rel="stylesheet" href="<?php echo e(URL::asset('css/iconfont.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/Store.css')); ?>">
	<link rel="icon" type="image/x-icon" href="<?php echo e(URL::asset('JT.ico')); ?>" />
	<link rel="shortcut icon" href="<?php echo e(URL::asset('JT.ico')); ?>" type="image/x-icon">
<style>
#category a{display: inline-block; crusor:point;background:#fff; border:1px solid #dbdbdb; border-radius: 5em; padding: 6px 18px; box-shadow: 1px 4px 6px solid #dbdbdb; margin: 0 2px 10px}
#category .active{background:#F5B041; color:#FFF}
</style>
</head>

<body>
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<div class="pre-view">
    <img src="<?php echo e(config('Qsetting.IMG_url')); ?>stores/<?php echo e($store[0]->SID); ?>.jpg">
    <p class="intro"><?php echo e($store[0]->detail); ?></p>
	<?php if(($store[0]->Status) == 0): ?>
	    <h3 style="color: #fdb216; margin-top: 30px"> <?php echo e(trans('store.30')); ?> </h3>
	<?php else: ?>
	    <p class="deliveryDate"><?php echo e(trans('store.10')); ?> : <?php echo e($optm); ?></p>
	    <div class="locationBox">
		    <?php $__currentLoopData = $locs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <div><?php echo e($k); ?></div>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </div>

		
	<?php endif; ?>
	<p style="display: none; margin-top: 70px; color: rgba(0,0,0,0.6)" id="mmrtt">History</p>
	<div style="display: none;" id="mmr"></div>
</div>

<div class="res-list" id="cart2">
    <div class="header">
	    <div class="left" onclick="sw(2,'res-list')"><span class="iconfont icon-Stone-arrow-back"></span></div>
		<h4><?php echo e(trans('store.11')); ?></h4>
	</div>
	
	<ul v-show="next == true">
	    <li><?php echo e(trans('store.29')); ?>

		    <div style="color: rgb(253, 178, 22); padding: 5px 28px;"><span style="font-size: 9px">RM</span></i> <span id="total2">0.00</span></div>
		</li>
	    <li><?php echo e(trans('store.12')); ?>

		    <div style="color: rgba(0,0,0,0.65); padding: 5px 28px;"><span style="font-size: 9px">RM</span></i> <span id="servefee">0.00</span></div>
		</li>
	    <li v-for="item in items" v-show="item.count > 0">
		    <span v-text="item.name"></span>
		    <div>
				<div class="add" v-on:click="AddG(item.ID)"><span class="iconfont icon-add"></span></div>
				<div style="color: #fdb216;" v-text="item.count"></div>
				<div class="del" v-on:click="delG(item.ID)"><span class="iconfont icon-baseline-remove-px"></span></div>
			</div>
		</li>
	</ul>
	
	<div v-show="next == true" class="res-btn" onclick="sw(1,'order')"><div><?php echo e(trans('store.13')); ?></div></div>
	<div v-show="next == false" class="kkry">
	    <img src="../../imgs/cart.png">
		<p><?php echo e(trans('store.14')); ?></p>
		<div onclick="sw(2,'res-list')"><?php echo e(trans('store.15')); ?></div>
	</div>
</div>

<div class="order">
    <div class="back" onclick="sw(2,'order')"><span class="iconfont icon-Stone-arrow-back"></span></div>
	<div class="nstep" onclick="sw(1,'payment')"><?php echo e(trans('store.16')); ?></div>
	<div class="infoBox">
	    <select id="user-location" class="lctBox">
		    <?php $__currentLoopData = $locs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

	    <div id="ipt1"><span class="iconfont icon-Stone-person"></span><input id="user-name" placeholder="<?php echo e(trans('store.17')); ?>"></div>
		<div id="ipt2"><span class="iconfont icon-Stone-phone-portrait"></span><input id="user-phone" placeholder="<?php echo e(trans('store.18')); ?>"></div>
		<p style="color: red; text-align: center" id="gaosuni"></p>
		<textarea id="user-locationDetail" placeholder="<?php echo e(trans('store.19')); ?>"></textarea>
		<br>
		
		
	</div>
	
	
	<div class="next">x</div>
</div>


<div class="payment" id="pay">
    <div class="back" onclick="sw(2,'payment')"><span class="iconfont icon-Stone-arrow-back"></span></div>
	<div class="Price">
	    <h3 style="color: #F39C12">Choose Payment:</h3>
	    <div class="deadline"><?php echo e(trans('store.20')); ?> <span id="remainTime"></span></div>
		<div class="Money">RM <span id="ttt">0.00</span></div>
		<div class="detail" id="gdtl"></div>
	</div>
	
	<ul>
		<li data-name="1" v-on:click="Selc($event)" style="color: #F39C12"><?php echo e(trans('store.31')); ?><img src="../../imgs/payments/cashpay.png"></li>
	 <!--<li data-name="2" v-on:click="Selc($event)" style="color: #F39C12"><?php echo e(trans('store.32')); ?><img src="../../imgs/payments/alipay.png"></li>-->
	</ul>
	<div id="pmt"><div class="done"  :style="{ background: pay?'#fdb216':'rgba(0,0,0,0.2)' }"><?php echo e(trans('store.21')); ?></div>
	</div>
</div>



<header>
	 <div class="right changeDQ"><?php echo e(trans('store.1')); ?></div>
</header>

<div class="cartBox" id="moneyBox">
    <div v-if="count > 0" class="cart" onclick="sw(1,'res-list')"><?php echo e(trans('store.22')); ?> <span v-text="count"></span> <?php echo e(trans('store.23')); ?><i><span style="font-size: 9px">RM</span></i> <span v-text="total"></span> (<?php echo e(trans('store.24')); ?>)</div>
	<div v-else class="cart" onclick="sw(1,'res-list')">- <?php echo e(trans('store.25')); ?> -</span></div>
</div>

<div class="loader">
    <div class="spinner">
       <div class="double-bounce1"></div>
       <div class="double-bounce2"></div>
    </div>
</div>


<div id="body">
	
	<div id="category" style="margin: 160px auto 20px; text-align: center">
	  <a :class="{ 'active':sel=='' }" @click="All()"><?php echo e(trans('store.34')); ?></a>
	  <a :class="{ 'active':sel==items }" v-for="items in list" v-show="items.length>0" @click="Selc(items)" v-text="items"></a> 
	</div>
	
	<div id="root">
	
	<div class="item" v-for="item in items">
        <img class="itemImg" :src="item.img" v-lazy="item.img" alt=""/>
        <div class="userInfo">
            <div class="head"><span v-text="item.size" style="font-size: 11px; color: rgba(0,0,0,0.5)"></span> <span v-text="item.name"></span></div> 
			<div class="detail">
				<div class="price"><span><i>RM</i></span> <b v-text="item.Price"></b></div>		
				<div v-if="item.count == 0" class="addc" :id="item.ID" v-on:click="Add(item.ID,item.img,$event)"><?php echo e(trans('store.26')); ?></div>
				<div v-else class="editc">
				    <span class="iconfont icon-baseline-remove-px" v-on:click="delG(item.ID)"></span>
				    <div v-text="item.count"></div>
				    <span class="iconfont icon-add" v-on:click="AddG(item.ID,item.img,$event)"></span>
			    </div>
		</div>
    </div>
    </div>
	
</div>
<h4 style="height: 50px; text-align: center; color: rgba(0,0,0,0.2)"><a href="../home"><img style="height: 19px;vertical-align: top; opacity: 0.8" src="<?php echo e(trans('store.logo')); ?>"></a> <?php echo e(trans('store.27')); ?></h4>

</div>

<form method="POST" action="../buy" style="display: none">
    <?php echo csrf_field(); ?>
	<input id="username" name="username" value="">
	<input id="phone" name="phone" value="">
	<input id="detail" name="detail" value="">
	<input id="store" name="store" value="<?php echo e($store[0]->SID); ?>">
	<input id="goods" name="goods" value="">
	<input id="payment" name="payment" value="">
	<input id="port" name="port" value="">
	<input id="sb" type="submit">
</form>

</body>
<script type="text/javascript" src="<?php echo e(URL::asset('js/vue.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/fly.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/vue-lazyload.js')); ?>"></script>
<script>

Vue.use(VueLazyload);  


var MainStep = 0;

function sw(type,className){
	if(type == 1) {
		if(className == 'res-list') {
			Chat2.items = Chat.items;
			var has=false;
				for(var i=0;i<Chat2.items.length;i++){
					if(Chat2.items[i].count>0){
						if(Chat2.items[i].count>0) has = true;
						break;
					}
				}
				if(!has) Chat2.next = false;
				else Chat2.next = true;
			$(".res-btn div").fadeIn(200);
			$('.'+className).slideDown(300);
			MainStep=2;
		}else if(className == 'order') {
			$(".res-btn div").text('');
			$(".res-btn div").addClass('OrderShow');
			setTimeout(function(){$('.'+className).fadeIn();},400);
			MainStep=3;
		}else if(className == 'payment') {
			if(Qchecker()){
				$(".next").text(''); $("#Wtip").text('');
				$(".next").addClass('OrderShow2');
				setTimeout(function(){$('.'+className).fadeIn();},400);
				MainStep=4;
			}else $("#Wtip").text('<?php echo e(trans('store.28')); ?>');
		}
		$('html').attr("style","overflow: hidden; height: 100%");
		$('body').attr("style","overflow: hidden; height: 100%");
	}else{
		if(className == 'res-list'){
			$(".res-btn div").fadeOut(200);
			$('.'+className).slideUp(300);
		    $('html').attr("style","overflow: auto");
		    $('body').attr("style","overflow: auto");
			MainStep=1;
		}else if(className == 'order') {
			$(".res-btn div").text("<?php echo e(trans('store.13')); ?>");
			$('.'+className).fadeOut(200);
			$(".res-btn div").removeClass('OrderShow');
			MainStep=2;
		}else if(className == 'payment') {
			$(".next").text("<?php echo e(trans('store.16')); ?>");
			$('.'+className).fadeOut(200);
			$(".next").removeClass('OrderShow2');
			MainStep=3;
		}else{$('.'+className).hide();}
	}
}





function isMobileNum(value) {
	/*
        var re = /^(\+?6?01){1}(([145]{1}(\-|\s)?\d{7,8})|([236789]{1}(\s|\-)?\d{7}))$/;
        var result = [];
        result = value.match(re);
        return !!result === true ? true : false;
		*/
		if(value.length>8) return true;
		return false
    }

//表单验证
function Qchecker(){
	var name = $("#user-name").val();
	var phone = $("#user-phone").val();
	var detail = $("#user-locationDetail").val();

	$('#ipt1').removeClass("wn");
	$('#ipt2').removeClass("wn");
	if(name.length<1){
		$('#ipt1').addClass("wn");
		$('#user-name').focus();
		return false;
	}else if(!isMobileNum(phone)){
		$('#ipt2').addClass("wn");
		$('#gaosuni').text('We only accept the Malaysia phone number');
		$('#user-phone').focus();
		return false;
	}else return true;
}

var hh = 0; 

 $(document).ready(function(){


	//记忆部分
	var datasave = localStorage.getItem("orders");

		if (datasave != '' && datasave != null){
			var dataar = datasave.split(";");
			for(var i=0;i<dataar.length;i++){
				var dataarr = dataar[i].split("#");
				if(dataarr.length == 2){
					$("#mmrtt").show();
					$("#mmr").show();
					$("#mmr").prepend("<a href='../bill/"+dataarr[1]+"'>"+dataarr[0]+"</a><br>");
				}
			}
		}


    var result= 30*60;
    var interval=setInterval(sub,1000); //定时器 调度对象

    /*封装减1秒的函数*/
    function sub(){
        if (result>1) {
            result = result - 1;
            var second = Math.floor(result % 60);     // 计算秒 ，取余
            var minite = Math.floor((result / 60) % 60); //计算分 ，换算有多少分
            $("#remainTime").text(minite + ":" + second);
        } else{
			//alert('?c ');
            window.clearInterval(interval);
        }
    }




	$('.loader').hide();
	
	$(".done").click(function(){
		if(payBox.pay) {
			$('#username').val($('#user-name').val());
			$('#phone').val($('#user-phone').val());
			$('#detail').val($('#user-locationDetail').val());
			$('#port').val($('#user-location').val());
			$('#payment').val(payBox.payment);
			
			//goods
			var gdt = '';
			for(var i=0;i<Chat.items.length;i++){
				if(Chat.items[i].count > 0) gdt += Chat.items[i].ID+","+Chat.items[i].count+".";
			}
			
			$('#goods').val(gdt.replace(/i/g,""));
			var datasaved = localStorage.getItem("orders");
			if (datasaved != '' && datasaved != null){

			}
			$("#sb").click();
		}
	});
	
	if (window.history && window.history.pushState) {
            $(window).on('popstate', function () {
				var hashLocation = location.hash;
				var hashSplit = hashLocation.split("#!/");
				var hashName = hashSplit[1];
				if(hashName !== '' || isNaN(hashName)){
					if(MainStep != 0){
						if(MainStep==1){
							$(".pre-view").fadeIn(300);
							setTimeout(function(){$(".cart").removeClass('cartShow')},400);
							setTimeout(function(){$("header").removeClass('fixShow')},1000);
							$('body').attr("style","overflow: hidden; height: 100%");
							MainStep=0;
						}else if(MainStep==2) sw(2,'res-list');
						else if(MainStep==3) sw(2,'order');
						else if(MainStep==4) sw(2,'payment');
					}
				}               
            });
        }
            window.history.pushState('forward', null, '#');
            window.history.forward(1);
			window.history.pushState('forward', null, '#');
            window.history.forward(1);
	
	
    $(window).scroll(function(){
        if ($(this).scrollTop() >= 55) {
          $(".cartBox").addClass('srolled');
		  $(".cart").addClass("srolledShadow");
		  $("header").addClass('fixit');
		  hh = 25; 
        }else {
          $(".cartBox").removeClass('srolled');
		  $(".cart").removeClass("srolledShadow");
		  $("header").removeClass('fixit');
		  hh = 0; 
        }
    });
	
	$(".changeDQ").click(function(){
		$(".pre-view").fadeIn(300);
		setTimeout(function(){$(".cart").removeClass('cartShow')},400);
		setTimeout(function(){$("header").removeClass('fixShow')},1000);
		$('html').attr("style","overflow: hidden; height: 100%");
		$('body').attr("style","overflow: hidden; height: 100%");
		MainStep=0;
	});
	
	$(".locationBox div").click(function(){
		$(".pre-view").fadeOut(600);
		$(".lctBox").find("option:contains('"+$(this).text()+"')").attr("selected",true);
		setTimeout(function(){$(".cart").addClass('cartShow')},400);
		setTimeout(function(){$("header").addClass('fixShow')},1000);
		$('html').attr("style","overflow: auto");
		$('body').attr("style","overflow: auto");
		MainStep=1;
	});
	$('html').attr("style","overflow: hidden; height: 100%");
	$('body').attr("style","overflow: hidden; height: 100%");

	$('#servefee').text(extra);
});




(function () {
 var calc = {
  Add: function (arg1, arg2) {
   arg1 = arg1.toString(), arg2 = arg2.toString();
   var arg1Arr = arg1.split("."), arg2Arr = arg2.split("."), d1 = arg1Arr.length == 2 ? arg1Arr[1] : "", d2 = arg2Arr.length == 2 ? arg2Arr[1] : "";
   var maxLen = Math.max(d1.length, d2.length);
   var m = Math.pow(10, maxLen);
   var result = Number(((arg1 * m + arg2 * m) / m).toFixed(maxLen));
   var d = arguments[2];
   return typeof d === "number" ? Number((result).toFixed(d)) : result;
  },
  Sub: function (arg1, arg2) {
   return Calc.Add(arg1, -Number(arg2), arguments[2]);
  },
  Mul: function (arg1, arg2) {
   var r1 = arg1.toString(), r2 = arg2.toString(), m, resultVal, d = arguments[2];
   m = (r1.split(".")[1] ? r1.split(".")[1].length : 0) + (r2.split(".")[1] ? r2.split(".")[1].length : 0);
   resultVal = Number(r1.replace(".", "")) * Number(r2.replace(".", "")) / Math.pow(10, m);
   return typeof d !== "number" ? Number(resultVal) : Number(resultVal.toFixed(parseInt(d)));
  },
  Div: function (arg1, arg2) {
   var r1 = arg1.toString(), r2 = arg2.toString(), m, resultVal, d = arguments[2];
   m = (r2.split(".")[1] ? r2.split(".")[1].length : 0) - (r1.split(".")[1] ? r1.split(".")[1].length : 0);
   resultVal = Number(r1.replace(".", "")) / Number(r2.replace(".", "")) * Math.pow(10, m);
   return typeof d !== "number" ? Number(resultVal) : Number(resultVal.toFixed(parseInt(d)));
  }
 };
 window.Calc = calc;
}());

var Amoney = 0;
var extra = <?php echo e($store[0]->Express + $store[0]->Packing); ?>;//服务费等...

function total_show(){
	Amoney = 0,Anum=0,gdtl='';
	for(var i=0;i<Chat.items.length;i++){
					if(Chat.items[i].count > 0){
						Amoney = Calc.Add(Amoney,Calc.Mul(Chat.items[i].count,Chat.items[i].Price));
						Anum = Anum+Chat.items[i].count;
						gdtl += Chat.items[i].name+'*'+Chat.items[i].count+' ';
					}
	}
	moneyBox.count = Anum;
	moneyBox.total = Amoney + extra;
	$('#ttt').text(moneyBox.total);
	$('#total2').text(moneyBox.total);
	$('#gdtl').text(gdtl);
}

var dt = <?php echo $goods; ?>;
/*[
	{title: "大芒果来咯", price: 10.3, ID: 10, img: '_Mango'}
];
*/

for (var i = 0; i < dt.length; i++) {
		dt[i].img = '<?php echo e(config('Qsetting.IMG_url')); ?>goods/'+dt[i].img+'.jpg';
		dt[i].ID = 'i'+dt[i].ID;
		dt[i].count = 0;
}

	
var Chat = new Vue({
  el: '#root',
  data: {
    items: dt
  },
  methods: {
		    Add: function(id,img,event){
				var flyer = $('<img src="'+img+'" style="width: 50px; z-index: 40; box-shadow: 1px 1px 8px #dbdbdb">');
				var ofs = $(event.currentTarget).offset();
				flyer.fly({
					start:{ left: ofs.left+10 , top: ofs.top-$(window).scrollTop(), },
					end:{ left: ($(window).width() / 2)-12, top: 47-hh, },
					speed: 1.5,
					onEnd: function(){this.destroy();}
				});
				for(var i=0;i<Chat.items.length;i++){
					if(Chat.items[i].ID == id){
						Chat.items[i].count++;
						Vue.set(Chat.items, i, Chat.items[i]);
						break;
					}
				}
				total_show();
			},
			AddG: function(id,img,event){
				var flyer = $('<img src="'+img+'" style="width: 50px; z-index: 40; box-shadow: 1px 1px 8px #dbdbdb">');
				var ofs = $(event.currentTarget).offset();
				flyer.fly({
					start:{ left: ofs.left-35 , top: ofs.top-$(window).scrollTop(), },
					end:{ left: ($(window).width() / 2)-12, top: 47-hh, },
					speed: 1.5,
					onEnd: function(){this.destroy();}
				});
				for(var i=0;i<Chat.items.length;i++){
					if(Chat.items[i].ID == id){
						Chat.items[i].count++;
						Vue.set(Chat.items, i, Chat.items[i]);
						break;
					}
				}
				total_show();
			},
			delG: function(id){
				for(var i=0;i<Chat.items.length;i++){
					if(Chat.items[i].ID == id){
						if(Chat.items[i].count>0) Chat.items[i].count--;
						Vue.set(Chat.items, i, Chat.items[i]);
						break;
					}
				}
				total_show();
			}
	}
});

var Chat2 = new Vue({
  el: '#cart2',
  data: {
    items: {},
	next: false
  },
  methods: {
			AddG: function(id){
				for(var i=0;i<Chat2.items.length;i++){
					if(Chat2.items[i].ID == id){
						Chat2.items[i].count++;
						Vue.set(Chat2.items, i, Chat2.items[i]);
						Vue.set(Chat.items, i, Chat2.items[i]);
						break;
					}
				}
				Chat2.next = true;
				total_show();
			},
			delG: function(id){
				for(var i=0;i<Chat2.items.length;i++){
					if(Chat2.items[i].ID == id){
						if(Chat2.items[i].count>0) Chat2.items[i].count--;
						Vue.set(Chat2.items, i, Chat2.items[i]);
						Vue.set(Chat.items, i, Chat2.items[i]);
						break;
					}
				}		
				var has=false;
				for(var i=0;i<Chat2.items.length;i++){
					if(Chat2.items[i].count>0){
						if(Chat2.items[i].count>0) has = true;
						break;
					}
				}
				if(!has) Chat2.next = false;
				total_show();
			}
	}
});
var l = '<?php echo e($category); ?>';
var list = l.split(";");
var category = new Vue({
  el: '#category',
  data: {
    list: list,
    sel: ""
  },
  methods: {
			 Selc: function(name){
			   category.sel=name;
			   var CurrentBox=new Array();
			   for(var i=0;i<dt.length;i++){
			     if(dt[i].class==name) CurrentBox.push(dt[i]);
			   }
			   Chat.items=CurrentBox;
	   },
	   All: function(){
	     Chat.items=dt;
	     category.sel="";
	   }
	 }
});

var payBox = new Vue({
  el: '#pay',
  data: {
    payment: 0,
	pay: false
  },
  methods: {
			Selc: function(event){
				$(".payment ul li").each(function(){
					if($(this).hasClass("clicked")) $(this).removeClass('clicked');
				});
				$(event.currentTarget).addClass('clicked');
				payBox.payment = $(event.currentTarget).data("name");
				payBox.pay = true;
			}
	}
});


var moneyBox = new Vue({
  el: '#moneyBox',
  data: {
    total: 0,
	count: 0
  }
});




</script>
</html><?php /**PATH /data/home/gyu3458260001/htdocs/JITU/resources/views/store.blade.php ENDPATH**/ ?>