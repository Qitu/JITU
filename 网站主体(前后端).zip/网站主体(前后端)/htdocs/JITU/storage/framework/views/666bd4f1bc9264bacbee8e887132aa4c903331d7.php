﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="keywords" content="JITU, Shopping, UKM">
    <meta name="description" content="JITU Platform">
    <meta name="author" content="Andy">
	<title>JITU</title>
	<link rel="stylesheet" type="text/css" href="../css/Lobby.css">
	<link rel="icon" type="image/x-icon" href="../JT.ico" />
	<link rel="shortcut icon" href="../JT.ico" type="image/x-icon">
</head>
<style>
    a{text-decoration: none; color: rgba(1,1,1,1)}
	.card{break-inside: avoid; cursor:pointer; padding-bottom: 10px; background: rgba(255,255,255,0.6); border-radius: 3px; box-shadow: 0px 2px 6px 0 rgba(0,0,0,0.04); margin-top: 16px}
	.card img{width: 100%; display: block; border-radius: 3px 3px 0px 0px;}
	.card .card-name{margin: 10px 15px 5px;}
	.card .card-date{color: rgba(0,0,0,0.4); margin: auto 20px; font-size: 13px}
	
</style>
<body>

<header>
    <div class="left"><img src="<?php echo e(trans('events.logo')); ?>.png"></div>
	<a href="app"><div class="right"><?php echo e(trans('events.1')); ?></div></a>
	<ul class="PCcategory">
	    <li><a href="home"><?php echo e(trans('events.2')); ?></a></li>
	    <li><a href="food"><?php echo e(trans('events.3')); ?></a></li>
	    <li style="font-weight:700; color: #fdb216; border-bottom: 3px solid #fdb216;"><?php echo e(trans('events.4')); ?></li>
	</ul>
</header>
<div class="loader">
    <div class="spinner">
       <div class="double-bounce1"></div>
       <div class="double-bounce2"></div>
    </div>
</div>


<div id="body">

<ul class="category">
<li><a href="home"><?php echo e(trans('events.2')); ?></a></li>
<li><a href="food"><?php echo e(trans('events.3')); ?></a></li>
<li class="active"><?php echo e(trans('events.4')); ?></li>
</ul>

    <div id="cards">
	    <div class="card" v-for="item in items" v-on:click="EV(item.ID)">
	    <div class="card-info">
	        <img class="itemImg" v-lazy="item.img">
		</div>
			<div class="card-name"><span v-text="item.title"></span></div>
		    <div class="card-date"><?php echo e(trans('events.5')); ?> <span v-text="item.deadline"></span> <b>(5<?php echo e(trans('events.6')); ?> )</b></div>
	    </div>
	</div>
 
	<div id="smart" style="text-align: center">
	    <a class="btn" href="app"><?php echo e(trans('events.7')); ?></a>
	</div>

<div id="ml" style="text-align: center;">
	<a class="btn" href="app"><?php echo e(trans('events.7')); ?></a>
</div>

</div>
</body>
<script type="text/javascript" src="../js/vue.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script src="../js/vue-lazyload.js"></script>
<script>

Vue.use(VueLazyload);

function bk(){
	Ghide();
	c2c = false;
}


 $(document).ready(function(){
	$('.loader').hide();
});

var dt = <?php echo json_encode($event); ?>;

for (var i = 0; i < dt.length; i++) {
		dt[i].img = '../imgs/banner.jpg';
}
	
	
var Chat = new Vue({
  el: '#cards',
  data: {
    items: dt
  },
  methods: {
		    EV: function(id){
				window.location.href="event/"+id;
		    }
	}
});

</script>
</html><?php /**PATH /data/home/gyu3458260001/htdocs/JITU/resources/views/events.blade.php ENDPATH**/ ?>