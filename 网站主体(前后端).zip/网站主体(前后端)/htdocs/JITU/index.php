<?php

header("Location:http://gyu3458260001.my3w.com/JITU/public/);
