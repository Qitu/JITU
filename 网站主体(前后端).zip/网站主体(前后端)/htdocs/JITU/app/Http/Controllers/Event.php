<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class Event extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function view($id)
    {
        $event = DB::table('Events')->where('EID', $id)->first();
        //var_dump($event);
        if($event != NULL) {

            $t = ['',''];
            $ar = explode("@",$event->Location);
            if(count($ar) > 1) $t = [$ar[0],$ar[1]];
            else $t = [$ar[0],''];

            $k = [];
            $ar = explode("@",$event->Type);
            for($i=0;$i<count($ar);$i++) {
                if($ar[$i] != '') $k[$i] = $ar[$i];
            }
            return view('eticket', ['event' => $event, 't' => $t, 'k' => $k, 'kc' => count($k)]);
        }
    }


    public function UD(Request $request)
    {
        
    }
}