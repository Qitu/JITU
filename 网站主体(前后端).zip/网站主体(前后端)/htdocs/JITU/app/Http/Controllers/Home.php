<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Home extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $mmt = DB::select('select `MomentID` as ID,`Sender`,`SenderID`,`Pictures`,`Like`,`Content` from `Moment` where `MType`="'.(app()->getLocale()).'" ORDER BY RAND() limit 6');
        foreach($mmt as $mmts){
			$str = $mmts->Content;
			$text=json_encode($str);
			$text = preg_replace_callback('/!I!/i',function($str){
				return '\\';
			},$text); 
			$mmts->Content = json_decode($text);
		}
		
        $value = $request->session()->get('home', '0');
        if($value != '0'){
            if(count($value) > 0 ){
                return view('Main', ['name' => $value, 'mmt' => $mmt]);
            }
        }   
        
        $users = DB::select('select `GID` as ID,`Goods`.`'.strtoupper(app()->getLocale()).'_Name` as name,`Price`,`sold`,`img` from `Goods`,`stores` where `SID`=`ShopID` AND `Status`=1 ORDER BY RAND() limit 3');
        session(['home' => $users]);
        return view('Main', ['name' => $users, 'mmt' => $mmt]);
    }
}