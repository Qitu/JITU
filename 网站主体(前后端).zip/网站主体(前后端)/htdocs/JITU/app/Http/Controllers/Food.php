<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Food extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $value = $request->session()->get('food', '0');
        if($value != '0'){
            if(count($value) > 0 ){
                return view('food', ['value' => $value]);
            }
        }
        $v = DB::select('select `GID` as ID,`Goods`.`'.strtoupper(app()->getLocale()).'_Name` as title,`Goods`.`'.strtoupper(app()->getLocale()).'_Size` as size,`Price` as price,`img` from `Goods`,`stores` where `SID`=`ShopID` AND `Status`=1 ORDER BY RAND() limit 12');
        session(['food' => $v]);
        return view('food', ['value' => $v]);
    }
}