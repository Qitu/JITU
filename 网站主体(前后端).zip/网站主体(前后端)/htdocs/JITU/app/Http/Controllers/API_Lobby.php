<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class API_Lobby extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $page = request()->route('page');
		$lang = request()->route('lang');
        //where `MType`="'.(app()->getLocale()).'" 
        if($page != 1) $md=1; else $md=0;
		//$mmt = DB::table('Moment')->select('MomentID as ID','Sender','SenderID','Pictures','Like','Content')->where('MType','=',$lang)->orderBy('MDate','desc')->skip(10*($page-1)->take(10)->get();
        $mmt = DB::select('select Moment_Comment.comments_count as ct,Moment_Reply.comments_count2 as ct2,`Moment`.`MomentID` as ID,`Sender`,`SenderID`,`Pictures`,`Like`,`Content`,`MDate` from (`Moment` LEFT JOIN (select MomentID,count(1) as comments_count from Moment_Comment group by MomentID) Moment_Comment ON Moment.MomentID=Moment_Comment.MomentID) LEFT JOIN (select RootID,count(1) as comments_count2 from Moment_Reply group by RootID) Moment_Reply ON Moment.MomentID=Moment_Reply.RootID where `MType`="'.$lang.'" Order By `MDate` Desc limit '.(10*($page-1)).',10');
        foreach($mmt as $each){
			
			if($each->ct == NULL) $each->ct=0;
			if($each->ct2 != NULL) $each->ct=($each->ct+$each->ct2);
			$str = $each->Content;
			$text=json_encode($str);
			$text = preg_replace_callback('/!I!/i',function($str){
				return '\\';
			},$text); 
			$each->Content = json_decode($text);
		}
		//else $dt = array('status'=>'3');
        //$value = 0;
        //$value = $request->session()->get('home', '0');
        //if($value != '0') if(count($value) > 0 ) return $mmt;

        //session(['home' => $mmt]);
        return $mmt;
    }
}