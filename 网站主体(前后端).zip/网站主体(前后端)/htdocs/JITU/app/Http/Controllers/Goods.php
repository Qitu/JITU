<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Goods extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $id = request()->route('id');
        $v = DB::select('select `GID` as ID,`ShopID` as SID,`Goods`.`'.strtoupper(app()->getLocale()).'_Name` as name,`'.strtoupper(app()->getLocale()).'_info` as info,`Price`,`sold`,`img` from `Goods` where `GID`=?', [$id]);
        if(count($v) > 0) {
            $v[0]->info = str_replace("=", "<br>",$v[0]->info);
            $v[0]->info = str_replace("_", " ",$v[0]->info);
            return view('goods', ['value' => $v[0]]);
        }
        return redirect(app()->getLocale().'/Nodata');
    }
}