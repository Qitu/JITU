<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Events extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $value = $request->session()->get('Events', '0');
        if($value != '0'){
            if(count($value) > 0 ){
                return view('events', ['event' => $value]);
            }
        }
        $users = DB::select('select `EID` as ID,`ZH_Name` as title,`EndDate` as deadline from `Events` limit 10');
        session(['Events' => $users]);
        return view('events', ['event' => $users]);
    }
}