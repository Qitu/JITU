<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class API_Payment extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $key = request()->route('key');
        $contact = request()->route('contact');
        $id = request()->route('id');
        $id = request()->route('id');
        $id = request()->route('id');
        $id = request()->route('id');
        //动态详情
        $request->validate([
            'username' => 'required|max:30',
            'phone' => 'required|min:8',
            'goods' => 'required',
            'port' => 'required',
            'store' => 'required',
            'payment' => 'required'
            //0现金，1微信，2支付宝，3银联， 4万事达
        ]);

        //网站下单用户，在店铺营业状态下最多下达2订单，选择现金支付则只能下一个订单

        //表单二次验证
        if(count(explode(".",$request->goods)) > 0){
            if(DB::table('stores')->where([['SID', $request->store],['Status', 1]])->exists()){//存在店铺且营业
                if(DB::table('Blacklist')->where('phone', $request->phone)->orWhere('phone', '6'.$request->phone)->exists()){//是黑户没错了
                    echo '该用户已被封禁 无法下单，解封请联系管理员<br>This account was in the black list, for the reason please contact our Adminitrator.<br><b>andy@jitu.fun</b>';
                    exit;
                }
                $max = 1;
                if($request->payment == 0) $max = 2;
    

                $ct = DB::table('AppOrder')->where([['webClient', $request->username.$request->phone],['Status','<',1]])->get();
                if(count($ct) < $max){//大于2进行中订单

                    //计费系统
                    $GData = array();
                    $quantity = array();
                    $arr = explode('.',$request->goods);
                    for($i=0;$i<count($arr);$i++){
                        $ar = explode(',',$arr[$i]);
                        if(count($ar) > 1){
                            array_push($GData,$ar[0]);
                            $quantity[$ar[0]] = $ar[1];
                        }
                    }
            
                    $goods = DB::table('Goods')
                        ->select('GID','Price')
                        ->whereIn ('GID', $GData)
                        ->get();

                    $total = 0;
                    for($i=0;$i<count($GData);$i++){
                        foreach ($goods as $dt) {
                            if($dt->GID == $GData[$i]){
                                $total = $total + $quantity[$GData[$i]] * $dt->Price;
                                break;
                            }
                        }
                    }

                    date_default_timezone_set('Asia/Shanghai');
                    //echo count($ct);
                    $id = DB::table('AppOrder')->insertGetId(
                        [
                            'webClient' => $request->username.'-'.$request->phone, 
                            'date' => date("Y-m-d H:i:s"),
                            'price' => $total,
                            'store' => $request->store, 
                            'goods' => $request->goods, 
                            'port' => $request->port,
                            'payment'=> $request->payment,
                            'Status' => 0,
                            'client_info' => $request->detail
                        ]
                    );
                    if($id != NULL) return redirect(app()->getLocale().'/bill'.'/'.$id);
                }else echo 'Please finish your ongoing order first.';
            }else echo 'Store closed';
        }else echo 'Data error';
    }
}