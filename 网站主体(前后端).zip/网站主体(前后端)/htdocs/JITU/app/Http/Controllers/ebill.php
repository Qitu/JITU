<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class ebill extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $id = request()->route('id');
        $event = DB::table('Eticket')->join('Events', 'Events.EID', '=', 'Eticket.EventID')->where('TID', $id)->first();
        if($event != NULL) {
            return view('ebill', ['value' => $event]);
        }
    }
}