<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class bill extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $id = request()->route('id');
        $value = DB::table('AppOrder')->join('stores', 'SID', '=', 'store')->where('ID', $id)->first();
        //var_dump($value);
        if($value != NULL) {
            if(app()->getLocale() == 'zh'){
                if($value->status == 0) $value->status = '等待确认支付';
                else if($value->status == 1) $value->status = '订单进行中';
                else if($value->status == 2) $value->status = '已完成';
                else if($value->status == 3) $value->status = '已取消';
            }else{
                if($value->status == 0) $value->status = 'Watting for confirm';
                else if($value->status == 1) $value->status = 'Order is processing';
                else if($value->status == 2) $value->status = 'Order finished';
                else if($value->status == 3) $value->status = 'Canceled';
            }
            

            //0现金，1微信，2支付宝，3银联， 4万事达
            if($value->payment == 1) $value->payment = 'Cash 现金支付';
            else if($value->payment == 2) $value->payment = 'Alipay 支付宝';
            else if($value->payment == 3) $value->payment = 'WechatPay 微信支付';
            else if($value->payment == 4) $value->payment = 'UnionPay 银联支付';
            else if($value->payment == 5) $value->payment = 'Mastercard 万事达卡';

            //商品数据操作模块
            $GData = array();
            $quantity = array();
            $arr = explode('.',$value->goods);
            for($i=0;$i<count($arr);$i++){
                $ar = explode(',',$arr[$i]);
                if(count($ar) > 1){
                    array_push($GData,$ar[0]);
					$quantity[$ar[0]] = $ar[1];
                }
            }
            $goods = DB::table('Goods')
                     ->select('GID','img',strtoupper(app()->getLocale()).'_Name as name','Price')
                     ->whereIn ('GID', $GData)
                     ->get();
            return view('bill', ['value' => $value, 'goods' => $goods, 'ct' =>$quantity ]);
        }else return redirect(app()->getLocale().'/Nodata');
    }
}