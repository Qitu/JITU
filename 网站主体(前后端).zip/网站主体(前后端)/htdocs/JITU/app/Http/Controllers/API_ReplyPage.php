<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class API_ReplyPage extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $id = request()->route('id');
        if(is_numeric($id) && $id > 0){
            $r = DB::select('select `ReplyID`,`FromUser`,`FromName`,`ContentR`,`ReplyDate` from Moment_Reply where CID = ? Order By `ReplyDate` ASC',[$id]);
            if($r != NULL) {
              $output=array();
              foreach($r as $reply){
				  
				$str = $reply->ContentR;
				$text=json_encode($str);
				$text = preg_replace_callback('/!I!/i',function($str){
					return '\\';
					},$text); 
				$reply->ContentR = json_decode($text);
				
				$str = $reply->FromName;
				$text=json_encode($str);
				$text = preg_replace_callback('/!I!/i',function($str){
					return '\\';
					},$text); 
				$reply->FromName = json_decode($text);
				
                array_push($output, array("ReplyID"=> $reply->ReplyID,"from"=>$reply->FromUser,"img"=>'',"name"=>$reply->FromName,"content"=>$reply->ContentR,"date"=>$reply->ReplyDate));
              }
              return json_encode($output);
            }
        }
        return json_encode(array("status"=>"1"));
    }
}