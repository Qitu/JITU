<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Social extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $id = request()->route('id');
        $v = DB::select('select (SELECT COUNT(*) FROM Moment_Comment where `MomentID`='.$id.') as ct,`MomentID`,`MType`,`SenderID`,`Sender`,`Content`,`Pictures`,`Like`,`TopicIDs`,`MDate` from `Moment` where `MomentID`='.$id);

	   if(count($v) > 0){
		//帖子
        $tar = explode(',',$v[0]->TopicIDs);
        $topics = DB::table('Moment_Topic')
                    ->select('TopicID', 'Topic'.strtoupper(app()->getLocale()).' as Tname')
                    ->whereIn('TopicID', $tar)
                    ->get();
        $Tnr = $topics;
		
		$str = $v[0]->Content;
		$text=json_encode($str);
		$text = preg_replace_callback('/!I!/i',function($str){
			return '\\';
		},$text); 
		$v[0]->Content = json_decode($text);

            //评论
            $c = DB::select('select `CommentID`,`UserID`,`User`,`PostDate`,`CommentContent` from `Moment_Comment` where `MomentID`=? limit 2', [$id]);
			foreach($c as $comments){
				$str = $comments->CommentContent;
				$text=json_encode($str);
				$text = preg_replace_callback('/!I!/i',function($str){
					return '\\';
					},$text); 
				$comments->CommentContent = json_decode($text);
			}
			
            //评论回复
            $r = DB::select('select `CID`,`FromName`,`ContentR` from Moment_Reply where RootID = ? limit 5',[$id]);
			foreach($r as $replies){
				$str = $replies->ContentR;
				$text=json_encode($str);
				$text = preg_replace_callback('/!I!/i',function($str){
					return '\\';
					},$text); 
				$replies->ContentR = json_decode($text);
			}
			
            //更多推荐
            $recom = DB::select('select `MomentID`,`Content` as title,`Sender` as user,`SenderID`,`Like`,`Pictures` from `Moment` where `TopicIDs`="'.$v[0]->TopicIDs.'" AND `MType`="'.(app()->getLocale()).'" AND `MomentID`<>'.$id.' limit 6');
            foreach($recom as $recoms){
				$str = $recoms->title;
				$text=json_encode($str);
				$text = preg_replace_callback('/!I!/i',function($str){
					return '\\';
					},$text); 
				$recoms->title = json_decode($text);
			}
			
            if($v[0]->Pictures > 4 || $v[0]->Pictures == 3) $Pstyle='32%';
            elseif($v[0]->Pictures > 1) $Pstyle='49%';
            else $Pstyle='100%';
            
            //$v[0]->Content = str_replace("=", "<br>",$v[0]->Content);
            return view('social', ['m' => $v[0], 'c'=> $c,'r'=>$r, 'recom'=>$recom,'Tnr' => $Tnr, 'Pstyle'=>$Pstyle]);
        }
        return redirect(app()->getLocale().'/Nodata');
    }
}