<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class API_MomentR extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        $id = request()->route('id');
        $page = request()->route('page');
        if(is_numeric($page) && $page > 0){
            $c = DB::select('select `CommentID`,`UserID`,`UserID` as reply,`User` as username,`PostDate` as date,`CommentContent` as content from `Moment_Comment` where `MomentID`=? limit '.(5*($page-1)).',5',[$id]);
            //评论回复
            $r = DB::select('select `CID`,`FromName`,`ContentR` from Moment_Reply where RootID=? Order By `ReplyDate` ASC',[$id]);
            if($c != NULL) {
                foreach($c as $com){
                    $com->reply=array();
					    $str = $com->content;
						$text=json_encode($str);
						$text = preg_replace_callback('/!I!/i',function($str){
							return '\\';
						},$text); 
						$com->content = json_decode($text);
                    foreach($r as $reply){
                        if($reply->CID == $com->CommentID){
							
							$str = $reply->FromName;
							$text=json_encode($str);
							$text = preg_replace_callback('/!I!/i',function($str){
								return '\\';
							},$text);
							$reply->FromName = json_decode($text);
							
							$str = $reply->ContentR;
							$text=json_encode($str);
							$text = preg_replace_callback('/!I!/i',function($str){
								return '\\';
							},$text);
							$reply->ContentR = json_decode($text);
							
                            array_push($com->reply, '<b>'.$reply->FromName.'</b> : '.$reply->ContentR);
                        }
                    }
                }
                return json_encode($c);
            }
        }
        return json_encode(array());
    }
}