<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Store extends Controller
{

    
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function view(Request $request)
    {
        $locname = array(
            '0' => 'UKM',
            '1' => 'Ibu Zain',
            '2' => 'Kolej Zaba',
            '3' => 'Villa Tropika',
            '4' => 'KKM',
            '5' => 'Kolej Omar',
            '6' => 'Saville Kajang',
        );
        $id = request()->route('id');
        if($id==0 || $id == '0'){
            echo 'Invaild StoreID';
            exit;
        } 
        $store = DB::table('stores')->select('SID','Status',''.strtoupper(app()->getLocale()).'_Name as name',''.strtoupper(app()->getLocale()).'_Detail as detail','LOC','Start','Express','Packing','OpenTime')->where('SID', $id)->get();
        if(count($store) <= 0)return redirect(app()->getLocale().'/Nodata');
		$store[0]->detail = str_replace("=", "<br>",$store[0]->detail);
        $store[0]->detail = str_replace("_", " ",$store[0]->detail);

        $optm = '';
        $arrr = explode(".",$store[0]->OpenTime);
        for($i=0;$i<count($arrr);$i++){
            $arrrr = explode(",",$arrr[$i]);
            if(count($arrrr) == 2){
                if(date("w") <= $arrrr[0]){
                  $hour = explode(":",$arrrr[1]);
                  date_default_timezone_set('Asia/Shanghai');
                  if(date("H") <= $hour[0]){
                      if(app()->getLocale() == 'zh') {
                        $rl=array("周日","周一","周二","周三","周四","周五","周六");
                        $optm = $rl[$arrrr[0]];
                      }else{         
                $rl=array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
                        $optm = $rl[$arrrr[0]];
                      }
                      $optm .= (' '.$arrrr[1]);
                      break;
                    
                  }                 
                }
            }
        }
        if($optm == '') {
            if(app()->getLocale() == 'zh') $optm = '下周';
            else $optm = 'Next week';
        }

        $locbox = array();

        $arr = explode(',',$store[0]->LOC);
        for($i=0;$i<count($arr);$i++){
            if(array_key_exists($arr[$i],$locname)){
                $locbox[$arr[$i]] = $locname[$arr[$i]];
            }
        }

        if(count($store) > 0) {
            if(is_numeric($store[0]->SID)){
                $goods = DB::table('Goods')->select('GID as ID',''.strtoupper(app()->getLocale()).'_Name as name',''.strtoupper(app()->getLocale()).'_Size as size','Price','img',''.strtoupper(app()->getLocale()).'_Class as class')->where('ShopID', '=', $store[0]->SID)->get();
                //var_dump($goods);
                
                $GClass=array();
                $TheClass="";
                $goods2=json_decode($goods,true);
                for($i=0;$i<count($goods2);$i++){
                  if(!in_array($goods2[$i]['class'],$GClass)) {array_push($GClass,$goods2[$i]['class']); $TheClass .= ($goods2[$i]['class'].";"); }
                }
                return view('store', ['goods' => $goods,'store' => $store, 'locs'=>$locbox, 'optm'=>$optm, 'category'=>$TheClass]);
            }
        }
        return "I couldn't find the date of this store (T.T)";
    }

    public function UD(Request $request){
        $request->validate([
            'username' => 'required|max:30',
            'phone' => 'required|min:8',
            'goods' => 'required',
            'port' => 'required',
            'store' => 'required',
            'payment' => 'required'
            //0现金，1微信，2支付宝，3银联， 4万事达
        ]);

        //网站下单用户，在店铺营业状态下最多下达2订单，选择现金支付则只能下一个订单

        //表单二次验证
        if(count(explode(".",$request->goods)) > 0){
            if(DB::table('stores')->where([['SID', $request->store],['Status', 1]])->exists()){//存在店铺且营业
                if(DB::table('Blacklist')->where('phone', $request->phone)->orWhere('phone', '6'.$request->phone)->exists()){//是黑户没错了
                    echo '该用户已被封禁 无法下单，解封请联系管理员<br>This account was in the black list, for the reason please contact our Adminitrator.<br><b>andy@jitu.fun</b>';
                    exit;
                }
                $max = 1;
                if($request->payment == 0) $max = 2;
                $ct = DB::table('AppOrder')->where([['webClient', $request->username.$request->phone],['Status','<',1]])->get();
                if(count($ct) < $max){//大于2进行中订单

                    //计费系统
                    $GData = array();
                    $quantity = array();
                    $arr = explode('.',$request->goods);
                    for($i=0;$i<count($arr);$i++){
                        $ar = explode(',',$arr[$i]);
                        if(count($ar) > 1){
                            array_push($GData,$ar[0]);
                            $quantity[$ar[0]] = $ar[1];
                        }
                    }
            
                    $goods = DB::table('Goods')
                        ->select('GID','Price')
                        ->whereIn ('GID', $GData)
                        ->get();

                    $total = 0;
                    for($i=0;$i<count($GData);$i++){
                        foreach ($goods as $dt) {
                            if($dt->GID == $GData[$i]){
                                $total = $total + $quantity[$GData[$i]] * $dt->Price;
                                break;
                            }
                        }
                    }

                    date_default_timezone_set('Asia/Shanghai');
                    //echo count($ct);
                    $id = DB::table('AppOrder')->insertGetId(
                        [
                            'webClient' => $request->username.'-'.$request->phone, 
                            'date' => date("Y-m-d H:i:s"),
                            'price' => $total,
                            'store' => $request->store, 
                            'goods' => $request->goods, 
                            'port' => $request->port,
                            'payment'=> $request->payment,
                            'Status' => 0,
                            'client_info' => $request->detail
                        ]
                    );
                    
                    if($id != NULL) return redirect(app()->getLocale().'/bill'.'/'.$id);
                }else echo 'Please finish your ongoing order first.';
            }else echo 'Store closed';
        }else echo 'Data error';
        //return redirect('Nodata');
    }
}