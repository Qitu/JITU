<?php
    return [
        'IMG_url' => 'https://jitugoods.oss-ap-southeast-3.aliyuncs.com/',
    ];
?>