<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
/*
Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

Route::group(array('prefix' => '{lang}', 'middleware' => 'switch_lang'), function () {
    Route::post('/Lobby/{page}', 'API_Lobby');
    //Route::post('/Profile/{key}', 'API_Profile');
    Route::post('/Moment/{id}', 'API_Moment');
    Route::post('/Pay/{id}', 'API_Payment'); 
    //Route::post('/CreateMoment', 'API_CreateMoment');
    Route::post('/MomentR/{id}/{page}', 'API_MomentR');
    Route::post('/ReplyPage/{id}', 'API_ReplyPage');
    //Route::post('/DeleteMoment/{id}', 'DeleteMoment');
});