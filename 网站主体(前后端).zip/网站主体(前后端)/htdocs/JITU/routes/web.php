<?php


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(array('prefix' => '{lang}', 'middleware' => 'switch_lang'), function (){

/*
Route::get('/', function () {
    return view('home');
});
*/

Route::get('/home', 'Home');
Route::get('/', 'Home');

Route::get('/food', 'Food');

Route::get('/events', 'Events');

Route::get('/app/{id}', function ($id) {
    return view('app', ['m' => $id]);
});

Route::get('/Nodata', function () {
    return view('Nodata');
});

Route::get('/official/{id}', 'Official');


Route::get('/social/{id}', 'Social');

Route::get('/store/{id}', 'Store@view')->where('id', '[0-9]+');

Route::get('/event/{id}', 'Event@view')->where('id', '[0-9]+');;



Route::get('/goods/{id}', 'Goods')->where('id', '[0-9]+');


Route::get('/bill/{id}', 'bill@show');
Route::get('/ebill/{id}', 'ebill');



Route::post('/buy', 'Store@UD');
//Route::post('/event', 'Event@UD');
});