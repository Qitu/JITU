﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Qitu">
    <title>JITU - Express</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css"> 
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">Home</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#" class="active">Dashboard</a></li>
        </ol>
    </div>
</div>

<div class="row">	
	
<div class="col-md-8">
    <div class="panel">
        <div class="panel-heading m-b-0">
            <h3>Express Notice</h3>
            <p class="text-muted">Please keep an eye on the platform announcement below.</p>
        </div>
        <div class="panel-body">
            
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          
          <div class="panel panel-default bg-purple m-t-0">
          <div class=" panel-heading active" role="tab" id="headingOne">
            <h4 class="panel-title">
              <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> Announsments <span class="rectangle center-block"></span></a>
            </h4>
          </div>

          <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel">
            <div class="panel-body">
            <p>No thing here now...</p>
            </div>
          </div>
          </div>

          <div class="panel panel-default bg-purple">
          <div class="panel-heading" role="tab" id="headingTwo">
            <h4 class="panel-title">
              <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"> Contact the admin <span class="rectangle center-block"></span></a>
            </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel">
              <div class="panel-body">
                <p>
				    <b>Contact :</b>
				        <br>Phone 60172917920		
						<br>WhatsApp： 969977237
						<br>QQ： 969977237
						<br>Wechat 13357220477
				</p>
              </div>
            </div>
          </div>


        </div>
        </div>
    </div>
</div>

    <br>
            <div class="col-md-4">
            <div class="panel m-t-0">
            <div class="panel-heading bg-purple font-white"><h3>JITU Express System</h3></div>
                <div class="panel-body panel-content">
                    <p>
					    <ul class="unordered"> 
                 <li>
				 JITU Express是积土官方使用的线上物流订单处理系统，送货员将能实时的操作所拥有订单的状态，订单总价值等等。
				 </li>
				 <li> 
				 相比传统的 线下/伪线上 物流送货，我们更加方便、快捷、思路清晰，送货员拥有更多的时间去思考、去创造自己独特的送货方式而不是局限于长时间的电话联系客户
				 </li>
				 <li> 
				 我们都正在不断成长 ... <br>来日方长，请多指教 ！
				 </li> 
             </ul> 
					</p>
			    </div>
            </div>
            </div>
        </div>

       

<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2018 Develop by Qitu. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
</div>

</div>
</div>


<script src="js/jquery.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
</body>

</html>