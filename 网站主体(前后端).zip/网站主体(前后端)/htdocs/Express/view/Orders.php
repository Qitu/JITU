﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Qitu">
    <title>Orders - Express</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">    
    <link rel="stylesheet" type="text/css" href="css/datatables/datatables.min.css">    
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>
<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">Orders</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#" class="active">Orders</a></li>
        </ol>
    </div>
</div>




<div class="row">
	<h2 style="text-align: center; color: #ff7f50; margin: 40px auto 25px; font-weight: 700"><?php echo $num; ?> Orders</h2>
    <div class="col-md-12">
	    
		<?php
		    $color = array('orange','green','red','blue','yellow');
		    $out = ''; $Fdex = 0;
		    foreach ($loc as $key => $value) {
				$Goods_data = '';
				foreach ($loc[$key] as $mmp => $valueMMP) {
					$Goods_data .= $GDATA[$mmp].' <b style="margin-left: 10px">x'.$valueMMP.'</b><br>';
				}
				if($Fdex > 4) $colorD = 'purple';
				else $colorD = $color[$Fdex];
				$Fdex++;
				$out .= '<div class="col-md-6 col-sm-6 col-xs-12 " style="margin-top: 30px">
                <div class="panel m-t-0">
                <div class="panel-heading bg-'.$colorD.' font-white"><h3>'.$key.'</h3></div>
                  <div class="panel-body panel-content">
					<p>
					'.$Goods_data.'
					</p>
					<br>
                  </div>
                </div>
                </div>';
			}
		    echo $out;
		?>
    </div>
</div>




<div class="modal fade bs-modal-sm" id="alll" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content" >
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                    <h4 class="modal-title" id="myModalLabel3">Edit Orders</h4>
            </div>
			
            <form action="updator.php" method="post" class="modal-body">
			
			    <b style="color: rgb(255, 117, 117)">Are you sure to finish all the order ?</b>
				<br>
				<b style="color: rgb(255, 117, 117)">Are you sure to finish all the order ?</b>
				<br>
				<b style="color: rgb(255, 117, 117)">Are you sure to finish all the order ?</b>
				<br>
				<br>
			    <div class="form-group">
                    <label for="des">Operation code</label>
                    <input type="number" class="form-control" name="Action" placeholder="Code">
                </div>
				
            </form>
			
            <div class="modal-footer">
                <button type="button" class="btn btn-md bg-red" data-dismiss="modal"><span>Back</span></button>
                <button type="button" class="btn btn-md bg-green" disabled><span>Submit</span></button>
            </div>
        </div>
    </div>
</div>






<div class="modal fade bs-modal-sm" id="action" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content" id="ttip">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
                    <h4 class="modal-title" id="myModalLabel3">Edit Orders</h4>
            </div>
			
            <form action="updator.php" method="post" class="modal-body">
			
			    <b v-show="status==0" style="color: #4EB152">Are you sure to finish the order ?</b>
				<b v-show="status>=1" style="color: rgb(255, 117, 117)">Are you sure to delete this order ?</b>
				<br><br>
			    <div class="form-group">
                    <label for="des">Operation code</label>
                    <input type="number" class="form-control" name="Action" placeholder="Code">
                </div>
				
				<input style="display: none" id="mdzz" type="submit" value="Submit" />
				<input type="hidden" id="Door" name="Door" value="1">
				<input type="hidden" id="OID" name="OID" value="0">
            </form>
			
            <div class="modal-footer">
                <button type="button" class="btn btn-md bg-red" data-dismiss="modal"><span>Back</span></button>
                <button type="button" onclick="GO()" class="btn btn-md bg-green"><span>Submit</span></button>
            </div>
        </div>
    </div>
</div>
			
<br><br><br>
</div>
</div>


<script src="js/jquery.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script type="text/javascript" src="js/datatables/datatables.min.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>
</body>

</html>