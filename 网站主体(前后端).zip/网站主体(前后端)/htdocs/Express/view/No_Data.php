﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Qitu">
    <title>No data</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">       
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>

<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">No order for your account now.</h1>
        <ol class="breadcrumb">
          <li><a href="?0"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
        </ol>
    </div>
</div> 
<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2018 Develop by qitu. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
</div>

</div>
</div>

<script src="js/jquery.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>

</body>

</html>