﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="Admin Template">
    <meta name="author" content="Zwolek">
    <title>Information - Express</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">    
    <link rel="stylesheet" href="css/nanoscroller.css">
</head>

<body>
<?php include_once 'view/top.php' ?>

<div id="content-panel">
<div class="container-fluid">

<div class="row">
    <div class="col-xs-12 dashboard-header">
        <h1 class="dash-title">Information</h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-home" aria-hidden="true"></i> home</a></li>
          <li><a href="#" class="active">Information</a></li>
        </ol>
    </div>
</div>

<form action="updator.php" method="post">

  <div class="row">
   
    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
        <div class="panel">
            <div class="panel-heading">
                <h3>Your information</h3>
                <p class="text-muted">Make sure your information is <code>vaild</code></p>
            </div>
            <div class="panel-body m-t-0">

            <div class="form-group">
                <label for="name">Name</label>
                <input disabled type="text" class="form-control" name="Name" id="name" placeholder="Your name" value="<?php echo $row[0] ?>">
            </div> 
			
			<div class="form-group">
                <label for="name">Phone</label>
                <input disabled type="text" class="form-control" name="Phone" id="phone" placeholder="Your phone" value="<?php echo $row[1] ?>">
            </div> 

            </div>
        </div>
    </div>
	
  </div>

</form>	
	
    

<div class="row">
    <footer>
      <div id="credits">
        <div class="col-xs-12">  
        <p> Copyright© 2018 Develop by qitu. All Rights Reserved.</p>
        </div> 
      </div>
    </footer>
</div>

</div>
</div>

<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/vue.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/menu/metisMenu.min.js"></script>
<script type="text/javascript" src="js/menu/nanoscroller.js"></script>
<script  type="text/javascript" src="js/jquery-functions.js"></script>

<script>

    var getFormatCode=function(strValue){
	    return strValue.replace(/\r\n/g, '<br/>').replace(/\n/g, '<br/>').replace(/\s/g, ' ');
	}


</script>
</body>

</html>