﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="description" content="HTML5 Template">
    <meta name="author" content="Zwolek">
    <title>Login - Express</title>
    <link rel="stylesheet" type="text/css" href="css/custom.css"> 
    <link rel="stylesheet" type="text/css" href="css/theme-purple.css">   
    <link rel="stylesheet" href="css/nanoscroller.css">
	
	<script type='text/javascript'>
        var username = localStorage.getItem("Eusername");
			if (username != "" && username != null){
				document.getElementById("inputEmail").value = username ;
			}
			var psw = localStorage.getItem("Epsw");
			if (psw != "" && psw != null){
				document.getElementById("inputPassword").value = psw ;
			}
        function validate(){
				var u = document.getElementById("inputEmail").value;
				var p = document.getElementById("inputPassword").value;
				localStorage["Eusername"]=u; 
				localStorage["Epsw"]=p; 
				document.getElementById("bb").click();
				return true;           
        }
        
        </script>
        <style type='text/css'>
        #code{
            font-family:Arial,宋体;
            font-style:italic;
            color:white;
            border:0;
            padding:2px 3px;
            letter-spacing:3px;
            font-weight:bolder;
			background:rgba(0,0,0,0)
        }
        </style>
</head>

<body>

<div id="login" class="bg-purple">
<div class="container">
<div class="row">
    <div class="col-xs-12 content">
    <div class="panel login-form">
        <div class="panel-heading">
        </div>
        <div class="panel-body m-t-0">

        <form data-toggle="validator" action="?0" method="post" onsubmit="validate()">
		        <h3 style="text-align: center; color: black; font-weight: 550; font-size: 25px; margin-bottom: 10px;">JITU - Express</h3>
				<p style="text-align: center; color: black;  margin-bottom: 16px; color: red"><?php echo $tip ?></p>
                <div class="form-group">
                    <label for="inputEmail" class="control-label">Account</label>
                    <div class="input-group">
                        <span class="input-group-addon bg-purple" id="basic-addon1"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                        <input  type="text" class="form-control" name="account" id="inputEmail" placeholder="Account" data-error="Invalid value" required>
                    </div>
                    <div class="help-block with-errors"></div>
                </div>

                <div class="form-group">
                    <label for="inputPassword" class="control-label">Token</label>                    
                    <div class="input-group">
                        <span class="input-group-addon bg-purple" id="basic-addon2"><i class="fa fa-key" aria-hidden="true"></i></span>
                        <input type="password" data-minlength="6" class="form-control" name="token" id="inputPassword" placeholder="Password" required>
                    </div>
                </div>
				
				<!--<div class="form-group">
                <div class="input-group">   
                    <input type="text" data-minlength="4" class="form-control" id = "input" id="inputPassword" autocomplete="off" placeholder="Code" required>
					<span class="input-group-addon bg-p" id="basic-addon2"><input type="button" id="code" onclick="createCode()" style="width:60px" title='Change Code' /></span>
                </div>
                </div>-->
				
				
                <div class="form-group">
                    <button onclick="validate()" type="submit" class="btn btn-md bg-purple"><span>Sign in</span></button>
                </div>

            </form>

        </div>
    </div>
    </div>
</div>
</div>
</div>


<script src="http://code.jquery.com/jquery-1.12.1.min.js"></script>
<script  type="text/javascript" src="js/bootstrap.min.js"></script>
<script  type="text/javascript" src="js/validator/validator.js"></script>
</body>

</html>