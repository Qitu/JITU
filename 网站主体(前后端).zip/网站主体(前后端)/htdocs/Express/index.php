<?php
   
   session_start(); //启用 session
   header("Content-type: text/html; charset=utf-8"); //启用中文支持
   
   require_once './safe.php'; //安全系统  
   require_once '../Database/Timer.php'; //延时系统
   
	if($_SERVER['HTTP_HOST'] == "jitu.fun"){ //简单安全判断
		if(canDo()){
			define('IN_SYS', TRUE); 
			require_once '../Database/Mysql.php'; //开启数据库模块
		    if(isset($_POST["account"]) && isset($_POST["token"])){ //尝试登入
			    $account = filter($_POST["account"]);
                $token = filter($_POST["token"]);
				if($sql = connectSQL()){
					$z=$sql->query("SELECT `KEY` FROM Express WHERE Account='".$account."' AND Token='".$token."'");	       
                	    if($z->num_rows>0){
                			$row = $z->fetch_row();
							$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
                            $password = ''; 
                            for ( $i = 0; $i < 32; $i++ ) { 
						        $password .= $chars[ mt_rand(0, strlen($chars) - 1) ]; 
						    }
							//echo $row[0];
							$z = "UPDATE `Express` SET `KEY`='".$password."' WHERE `KEY`='".$row[0]."'";
                            if ($sql->query($z)) {
								//店铺信息 + 获取数据
								$_SESSION['Etoken'] = $password;
							    //开大厅 + 获取数据
								echo "Please wait....";
								header("refresh:2;url=http://jitu.fun/Express?0");exit;
							}else echo 'Server busy...';							
						}else{
							//回登陆
							$tip = 'Login faild, because your input a wrong account/password';
							include_once 'view/Login.php';
						}
				}else echo 'Network connected error';
		    }else if(isset($_SESSION['Etoken'])){
				$token = filter($_SESSION['Etoken']);
	            $now = filter($_SERVER["QUERY_STRING"]); //可编辑字符串安全化
		        switch($now){
					
										
					case '0':
					    if($sql = connectSQL()){
							
								//ini data
									$total = 0;
									$placeDOC = array('UKM','Ibu Zain','Kolej Zaba','Villa Tropika','KKM','Kolej Omar','Saville Kajang');
									$loc = array();
									$totoal_per = array();
									$GDATA = array();
									$QDT='';
									$num = 0;
									
									$x=$sql->query("SELECT 
							                    AppOrder.ID,AppOrder.Port,AppOrder.goods
											FROM 
											    AppOrder,Express WHERE Express.KEY='".$token."' AND AppOrder.store=Express.ShopID AND AppOrder.status=1");	       
                	        	    if($x->num_rows>0){
										$num = $num + $x->num_rows; 
										while($row = $x->fetch_row()){
										    $place = $placeDOC[(int) $row[1]];
										    $gd = $row[2];
											
											$arr = explode('.', $gd);
										    for($i=0;$i<count($arr);$i++){
											    $ar = explode(',', $arr[$i]);
										        if(count($ar) == 2){
												    if(isset($loc[$place])) $loc[$place][$ar[0]] = $loc[$place][$ar[0]] + ((int) $ar[1]);
												    else $loc[$place][$ar[0]] = (int) $ar[1];
												
												    $has = false;
												    for($o=0;$o<count($GDATA);$o++){
													    if($ar[0] == $GDATA[$o]) $has = true;
												    }
												    if(!$has) $GDATA[$ar[0]] = '--';
											    }
										    }
										}
									}
									
									    $Gindex = 0;
										foreach ($GDATA as $key => $value) {
											if($Gindex == 0) $QDT .= 'GID='.$key.' ';
											else $QDT .= 'OR GID='.$key.' ';
											$Gindex++;
										}
										//var_dump($QDT);
									
									$c=$sql->query("SELECT ZH_Name,GID FROM Goods WHERE ".$QDT);
												if($c->num_rows>0){
													while($puy = $c->fetch_row()){
														$GDATA[$puy[1]] = str_replace('_', ' ', $puy[0]);
														$count = 0;
														foreach ($loc as $value) {
															if(isset($value[$puy[1]])) $count = $count+ (int)$value[$puy[1]];
												        }
													}
												}
									if($num > 0) include_once 'view/Orders.php';
									else include_once 'view/No_Data.php';
								
				        }else echo 'Network connected error';
					break;
					
					
					case '1':
					    //个人信息编辑
						if($sql = connectSQL()){
					        $z=$sql->query("SELECT 
							                    Name,Phone
											FROM 
											    Express WHERE `KEY`='".$_SESSION['Etoken']."'");	       
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
								include_once 'view/Info_Editor.php';
						    }else{
							    //回登陆
								session_destroy();
							    $tip = 'Please relogin';
							    include_once 'view/Login.php';
						    }
				        }else echo 'Network connected error';
					break;

					case 'Logout':
					    session_destroy();
						//回登陆
				        $tip = '';
				        include_once 'view/Login.php';
					break;
					
					
					
					default:
					    $tip = '';
				        include_once 'view/404.html';
					break;
		        }
		
		    }else{
				//回登陆
				$tip = '';
				include_once 'view/Login.php';
		    }
		}else echo 'Slowly please';
		
	
    }else{
       echo '505';
    }

?>