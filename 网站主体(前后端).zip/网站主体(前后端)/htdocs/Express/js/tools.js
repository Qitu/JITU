
          /*
		  
		                 /                   \
		                /                      \
					   
					          ------------
							  |           |
		                      |           |
							  ------------
		  */
		  
  
		  
		  
		  
          function Mu(arg1, arg2) {
             var r1 = arg1.toString(), r2 = arg2.toString(), m, resultVal, d = arguments[2];
             m = (r1.split(".")[1] ? r1.split(".")[1].length : 0) + (r2.split(".")[1] ? r2.split(".")[1].length : 0);
             resultVal = Number(r1.replace(".", "")) * Number(r2.replace(".", "")) / Math.pow(10, m);
             return typeof d !== "number" ? Number(resultVal) : Number(resultVal.toFixed(parseInt(d)));
          }
		  
		  
		  function Ge(value){
			  if (value.toString().indexOf(".") < 0) {
                  value = value.toString() + ".00";
			  }
			  return value;
		  }
		  
		  
		  function delHtmlTag(str){
             return str.replace(/<[^>]+>/g,"");
          }