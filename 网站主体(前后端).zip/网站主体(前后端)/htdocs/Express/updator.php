<?php

 session_start(); 
header("Content-type: text/html; charset=utf-8");
require_once './safe.php';  
require_once 'Timer.php'; 
   if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	   if(canDo()){
	   if(isset($_SESSION['Etoken'])){
	   if(isset($_POST["Door"])){

			       if(isset($_POST["Action"]) && isset($_POST["OID"])){
					   $Action = filter($_POST["Action"]);
					   $OID = filter($_POST["OID"]);
					   $Door = filter($_POST["Door"]);
					   define('IN_SYS', TRUE);
					   require_once '../Database/Mysql.php';                       
                       
						   if($sql = connectSQL()){
                	        
							$z=$sql->query("SELECT
					                    `Phone`
									FROM 
									    Express
									WHERE
										Action='".$Action."' AND `KEY`='".$_SESSION['Etoken']."'");	       
                	        if($z->num_rows>0){
                			    $row = $z->fetch_row();
								$z="UPDATE 
							                      WebOrder
											SET
											      `Status`='".$Door."'
										    WHERE 
											      Deliver='".$row[0]."' AND `OrderID`='".$OID."'";                	            
								if ($sql->query($z)){
									Header("Location: http://jitu.fun/Express/?2");
									exit;
								}else include_once 'view/500.html';
							}else exit('Action token error');
                		    //商品表获取
                		    
						   }else exit('Server busy');
					   		   
				   }else exit('die');
			  
	   }else exit('exm ????');
	   }else{
		    session_destroy();
			$tip = 'Please relogin';
			include_once 'view/Login.php';
	   }
	   }else exit('Slowly please ??');
   }else exit('faild');

?>
 
