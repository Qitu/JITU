
<?php

    header("Content-type: text/html; charset=utf-8");
    # 收银台接口
    if(!isset($_GET['price']) || !isset($_GET['oid'])){
      echo '?';
      return;    
    }
    
    $price = $_GET['price']; # 从 URL 获取充值金额 price
    $name = 'JTalk WebBill:'.$_GET['oid'];  # 订单商品名称
    $pay_type = 'alipay';     # 付款方式
    $order_id = $_GET['oid'];    # 自己创建的本地订单号
    $notify_url = 'http://jitu.fun/notify_url.php';   # 回调通知地址

    $secret = '3238d1bb398147c9adc648cb799413aa';     # app secret, 在个人中心配置页面查看
    $api_url = 'https://xorpay.com/api/pay/7421';   # 付款请求接口，在个人中心配置页面查看

    function sign($data_arr) {
        return md5(join('',$data_arr));
    };

    $sign = sign(array($name, $pay_type, $price, $order_id, $notify_url, $secret));

$postData=array(
 'name'=>$name,
	'pay_type'=>$pay_type,
	'price'=>$price,
	'order_id'=>$order_id,
	'notify_url'=>$notify_url,
	'sign'=>$sign,
);


$postData=http_build_query($postData);
$ops=array(
    'http'=>array(
    'method'=>'POST',
    'header'=>
          "Content-Type: application/x-www-form-urlencoded\r\n".
          "Content-length:".strlen($postData)."\r\n",
    'content'=>$postData,
    )
);
$context=stream_context_create($ops);
//$fp=fopen("http://localhost/data/mianshi/http/index.php","r",false,$context);
//fclose($fp);
$result = file_get_contents($api_url,false,$context);
echo $result;
//print_r($result['status']);
//echo '?';


?>