<?php

header("Content-type: text/html; charset=utf-8");
/*
0: success
1: faild
3: Invalid authorization
*/
$dt = array('status'=>'1');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	 define('IN_SYS', TRUE);
	 require_once '../Database/Mysql.php';
	 if(isset($_POST["key"]) && isset($_POST["name"]) && isset($_POST["des"]) && isset($_POST["gender"])){
		  require_once './safe.php';
		  $key = filter($_POST["key"]);
		  $name = filter($_POST["name"]);
		  $des = filter($_POST["des"]);
		  $gender = filter($_POST["gender"]);
		  
			 if($sql = connectSQL()){
			   $z=$sql->query("SELECT `UID` FROM `AppUser` WHERE Token='".$key."'");//验证身份
			   if($z->num_rows>0){
				   $user = $z->fetch_row();
				   
				   $z=$sql->query("SELECT `UID` FROM `AppUser` WHERE UserName='".$name."'");//用户名是否重复
				   if($z->num_rows>0){
					   $current = $z->fetch_row();
					   if($user[0]!=$current[0]){
						   echo json_encode(array('status'=>'1')); return;//重名不通过
					   }
				   }
				   
					if($sql->query("UPDATE `AppUser`SET UserName='".$name."', Des='".$des."', Gender=".$gender." WHERE UID=".$user[0])){
						echo json_encode(array('status'=>'0')); return;
					}
			   }else $dt = array('status'=>'3');
		  }
	 }
}
echo json_encode($dt);
?>
   
 
