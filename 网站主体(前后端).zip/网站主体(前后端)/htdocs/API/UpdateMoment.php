<?php

//header("Content-type: application/json; charset=utf-8");

/*
0: success
1: faild
2: baned
3: Invalid authorization
*/


function userTextEncode($str){
    if(!is_string($str))return $str;
    if(!$str || $str=='undefined')return '';

    $text = json_encode($str); //暴露出unicode
    $text = preg_replace_callback("/(\\\u[ed][0-9a-f]{3})/i",function($str){
        return "!I!".addslashes($str[0]);
    },$text); //将emoji的unicode留下，其他不动，这里的正则比原答案增加了d，因为我发现我很多emoji实际上是\ud开头的，反而暂时没发现有\ue开头。
    return json_decode($text);
}


$dt = array('status'=>'1');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	 define('IN_SYS', TRUE);
	 require_once '../Database/Mysql.php';
	 if(isset($_POST["key"]) && isset($_POST["info"]) && isset($_POST["Pictures"]) && isset($_POST["lang"])){
		  require_once './safe.php';
		  $key = filter($_POST["key"]);
		  $mid = filter($_POST["mid"]);
		  $info = userTextEncode($_POST["info"]);
		  $info = filter($info);
		  $lang='zh';
		  if($_POST["lang"]==1) $lang='en';
		  $pic=intval($_POST["Pictures"]);
		
			 if($sql = connectSQL()){
			   $z=$sql->query("SELECT `UID`,`UserName`,`MomentID` FROM `AppUser`,`Moment` WHERE SenderID AND Token='".$key."'");
			   if($z->num_rows>0){
						   $user = $z->fetch_row();
						   $z=$sql->query("SELECT `client` FROM `Blacklist` WHERE client='".$user[0]."'");
						   if($z->num_rows<1){//不是黑户
						     if($sql->query("UPDATE Moment SET `MType`='".$lang."',`SenderID`=".$user[0].",`Sender`='".$user[1]."',`Content`='".$info."',`LastEdit`='".date('Y-m-d H:i:s',time())."',`Pictures`=".$pic." WHERE MomentID=".$mid)){
									 	   echo json_encode(array('status'=>'0'));
									     return;
									   }
						   }else $dt = array('status'=>'2');
			   }else $dt = array('status'=>'3');
		  }
	 }
}
echo json_encode($dt);
?>
   
 
