<?php

//header("Content-type: application/json; charset=utf-8");

/*
0: success
1: faild
3: Invalid authorization
*/


$dt = array('status'=>'1');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	 define('IN_SYS', TRUE);
	 require_once '../Database/Mysql.php';
	 if(isset($_POST["key"]) && isset($_POST["cid"])){
		  require_once './safe.php';
		  $key = filter($_POST["key"]);
		  $CID = filter($_POST["cid"]);
		
			 if($sql = connectSQL()){
			   $z=$sql->query("SELECT `UID` FROM `AppUser` WHERE Token='".$key."'");//验证用户身份
			   if($z->num_rows>0){
						   $user = $z->fetch_row();
						   if($sql->query("DELETE FROM Moment_Comment WHERE CommentID=".$CID)){
								 	  echo json_encode(array('status'=>'0')); return;
								  }
			   }else $dt = array('status'=>'3');
		  }
	 } 
}
echo json_encode($dt);

?>
   
 
