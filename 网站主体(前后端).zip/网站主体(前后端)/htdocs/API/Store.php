<?php

header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
    require_once '../Database/Timer.php';
	if(canDo() && isset($_POST["SID"])){
		require_once './safe.php'; //安全系统
		if($sql = connectSQL()){
			$ID = filter($_POST["SID"]); $lang = 'EN';
		    if(isset($_SERVER["QUERY_STRING"])){
			    if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		    }
			$z=$sql->query("SELECT 
						            `Status`,`".$lang."_Name`,`".$lang."_Detail`,`Type`,`Start`,`Express`,`Packing`,`OpenTime`
									FROM `stores` WHERE SID=".$ID."");
			if($z->num_rows>0){
				$store = $z->fetch_row();
				$store[2] = str_replace("_"," ",$store[2]);
				$store[1] = str_replace("_"," ",$store[1]);
				$arr = array("ID"=>$ID,"status"=>$store[0], "name"=>$store[1],"Des"=>$store[2],"type"=>$store[3],"S"=> $store[4],"express"=> $store[5],"packing"=>$store[6],"open"=>$store[7]);
				echo json_encode($arr);
			}
		}
	}
}
?>
   
 
