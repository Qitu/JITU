<?php

//header("Content-type: application/json; charset=utf-8");

/*
0: success
1: faild
2: data not find
3: Invalid authorization
*/

function userTextEncode($str){
    if(!is_string($str))return $str;
    if(!$str || $str=='undefined')return '';

    $text = json_encode($str); //暴露出unicode
    $text = preg_replace_callback("/(\\\u[ed][0-9a-f]{3})/i",function($str){
        return "!I!".addslashes($str[0]);
    },$text); //将emoji的unicode留下，其他不动，这里的正则比原答案增加了d，因为我发现我很多emoji实际上是\ud开头的，反而暂时没发现有\ue开头。
    return json_decode($text);
}

function beSticker($str){
	$text=json_encode($str);
	$text = preg_replace_callback('/!I!/i',function($str){
		return '\\';
	},$text);
	return json_decode($text);
}


$dt = array('status'=>'1');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
	if(isset($_POST["key"]) && isset($_POST["info"]) && isset($_POST["mid"])){
		require_once './safe.php';
		$key = filter($_POST["key"]);
		$info = userTextEncode($_POST["info"]);
		$info = filter($info);
		$cid = filter($_POST["mid"]);
		
		if($sql = connectSQL()){
			$z=$sql->query("SELECT `UID`,`UserName` FROM `AppUser` WHERE Token='".$key."'");
			if($z->num_rows>0){
				$user = $z->fetch_row();
				$z=$sql->query("SELECT `MomentID`,`CommentContent`,`User` FROM `Moment_Comment` WHERE CommentID='".$cid."'");
				if($z->num_rows>0){//找到帖子id(RootID)
					$mid = $z->fetch_row();
					$datetime=date('Y-m-d H:i:s',time());
					if($sql->query("INSERT INTO Moment_Reply(`RootID`,`CID`,`FromUser`,`FromName`,`ContentR`,`ReplyDate`) VALUES(".$mid[0].",".$cid.",".$user[0].",'".$user[1]."','".$info."','".$datetime."')")){
						echo json_encode(array('status'=>'0','id'=>''.$cid,'name'=>''.$user[1]));
						
						
						$z=$sql->query("SELECT `AppUser`.`PushID` FROM `AppUser`,`Moment_Reply`,`Moment_Comment` WHERE AppUser.UID<>".$user[0]." AND ((AppUser.UID=Moment_Comment.UserID AND Moment_Comment.MomentID=".$mid[0].") OR (Moment_Reply.FromUser=AppUser.UID AND Moment_Reply.CID=".$cid."))");
						if($z->num_rows>0){
							$RIDs=array();
							while($RID=$z->fetch_row()){
								array_push($RIDs,$RID[0]);
							}
								require_once './push.php';//推送模块
							    $push = new Push();//配置信息
							    $params = array(
						            'plats' => array(1, 2),
							        # 设置推送范围
							        'target' => 4, 'content' => $_POST["info"], 'type' => 1, 'registrationIds' => $RIDs,
							        # 设置Android定制信息
							        'androidTitle' =>  $user[1], 'androidstyle' => 1, 'androidVoice' => 1, 'androidShake' => 1, 'androidLight' => 1,"androidContent"=>[$_POST["info"]],
							        # 设置iOS定制信息
							        'iosProduction' => 1, 'title' => 'JTalk', 'subtitle' => $user[1], 'sound' => 'default', 'badge' => 1, 'slientPush' => 1, 'contentAvailable' => 1, 'mutableContent' => 1,
									'extras' => array('Type' => 2, 'UID'=>$user[0], 'ID' => $cid, 'ContentInfo'=>beSticker($mid[1]), 'ContentSender'=>$mid[2]),
						        );
						$res = $push->postPush($params, 1);
						}
						return;
						
					}else $dt = array('status'=>'4');
				}else $dt = array('status'=>'2');
			}else $dt = array('status'=>'3');
		}
	}
}
echo json_encode($dt);

?>
   
 
