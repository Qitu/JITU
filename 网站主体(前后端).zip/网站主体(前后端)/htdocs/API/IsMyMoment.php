<?php

header("Content-type: text/html; charset=utf-8");

if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	 define('IN_SYS', TRUE);
	 require_once '../Database/Mysql.php';
  require_once '../Database/Timer.php';
	 if(canDo() && isset($_POST["key"]) && isset($_POST["mid"])){
	    require_once './safe.php'; //安全系统
	    $key = filter($_POST["key"]);
		$mid = filter($_POST["mid"]);
		if($sql = connectSQL()){
		    $z=$sql->query("SELECT `UID` FROM `AppUser` WHERE token='".$key."'");
			if($z->num_rows>0){
				$user = $z->fetch_row();
				$z=$sql->query("SELECT `Content`,`Pictures` FROM `Moment` WHERE `MomentID`='".$mid."' AND `SenderID`=".$user[0]."");
			    if($z->num_rows>0){
				    $content = $z->fetch_row();
					
					$str = $content[0];
					$text=json_encode($str);
					$text = preg_replace_callback('/!I!/i',function($str){
						return '\\';
					},$text); 
					
					$content[0] = json_decode($text);
				    echo json_encode(array('status'=>'0', 'content'=>$content[0], 'Pictures'=>$content[1]));
			    }else echo json_encode(array('status'=>'5'));
			}else echo json_encode(array('status'=>'4'));
		}else echo json_encode(array('status'=>'3'));
	}else echo json_encode(array('status'=>'2'));
	echo json_encode(array('status'=>'1'));
}
?>
   
 
