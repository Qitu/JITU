<?php

header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
    require_once '../Database/Timer.php';
	if(canDo() && isset($_POST["Token"]) && isset($_POST["ID"])){
		require_once './safe.php'; //安全系统
		if($sql = connectSQL()){
			$ID = filter($_POST["ID"]); $token = filter($_POST["Token"]); $lang = 'EN';
		    if(isset($_SERVER["QUERY_STRING"])){
			    if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		    }
			$z=$sql->query("SELECT `UID` FROM `AppUser` WHERE Token='".$token."'");
			if($z->num_rows>0){
				$user = $z->fetch_row();
				$z=$sql->query("SELECT 
				                    `AppOrder`.`status`,
									`AppOrder`.`date`,
									`AppOrder`.`client_info`,
									`stores`.`Express`,
									`stores`.`Packing`,
									`AppOrder`.`goods`,
									`AppOrder`.`payment`,
									`AppOrder`.`paied`
									FROM `AppOrder`,`stores` WHERE AppOrder.ID='".$ID."' AND AppOrder.client='".$user[0]."' AND AppOrder.store=stores.SID");
				if($z->num_rows>0){
				    $goods = $z->fetch_row();
					
					$loc = ''; $cont1 = ''; $cont2 = '';
					$goods_data = array();
					
					$arr = explode(';', $goods[2]);
					$quantity = array();
					if(count($arr) > 1){
						$loc = $arr[0];
						$ar = explode(',', $arr[1]);
						if(count($ar) == 2){
							$cont1 = $ar[0];
							$cont2 = $ar[1];
						}
					}
					
					
					$arr = explode('.', $goods[5]);
					$quantity = array();
					if(count($arr) > 0){
						for($i=0;$i<count($arr);$i++){
							$ar = explode(',', $arr[$i]);
							if(count($ar) == 2){
								if($tj == '')$tj = 'WHERE GID='.$ar[0];
								else $tj .= ' OR GID='.$ar[0];
								$quantity[$ar[0]] = $ar[1];
							}
					    }
					}
					
					$total = 0;
					$x=$sql->query("SELECT `GID`,`img`,`".$lang."_Name`,`Price`,`".$lang."_Size` FROM `Goods` ".$tj);
					if($x->num_rows>0){
					    while($GDT = $x->fetch_row()){
							array_push($goods_data,array($GDT[1],$GDT[2],$GDT[4],$GDT[3],$quantity[$GDT[0]]));
							$total = $total + ($quantity[$GDT[0]] * $GDT[3]);
						}
					}
					
					$total = $total + $goods[3] + $goods[4];
					echo json_encode(
					    array(
						    'status'=>$goods[0],
							'date'=>$goods[1],
							'express'=>$goods[3],
							"packing"=> $goods[4], 
							"payment"=> $goods[6],
							"paied"=> $goods[7], 
							"Total"=> $total, 
							"location"=> $loc, 
							"contact1"=> $cont1,
							"contact2"=> $cont2,
							"goods"=> $goods_data
						)
					);
				}
			}
		}
	}
}
?>
   