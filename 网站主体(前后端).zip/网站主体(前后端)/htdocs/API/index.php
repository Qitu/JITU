<?php
session_start();
header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
	
	if (!isset($_SESSION['CREATED'])) {
        $_SESSION['CREATED'] = time();
	} else if (time() - $_SESSION['CREATED'] > 1800) {
		if(isset($_SESSION['hc'])) unset($_SESSION['hc']);
        session_regenerate_id(true);
        $_SESSION['CREATED'] = time(); 
	}
	
	
	
	if(!isset($_SESSION['hc'])){
		require_once './safe.php'; //安全系统
		$lang = 'EN';
		if(isset($_SERVER["QUERY_STRING"])){
			if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		}
		if($sql = connectSQL()){
			$z=$sql->query("SELECT 
						            `Goods`.`GID`,`Goods`.`".$lang."_Name`,`Goods`.`".$lang."_info`,`Goods`.`img`,`".$lang."_Class`
									FROM `Goods`,`stores` WHERE Goods.ShopID=stores.SID AND Goods.ShopID>0 AND stores.Status<>0 order by rand() limit 6");
			if($z->num_rows>0){
				while($_store = $z->fetch_row()){
						$_store[1] = str_replace("_"," ",$_store[1]);
						$_store[2] = str_replace("_"," ",$_store[2]);
						$_store[2] = str_replace("="," ",$_store[2]);
						$arr = array("ID"=>$_store[0],"img"=>$_store[3], "name"=>$_store[1],"detail"=>$_store[2],"Class"=>$_store[4]);
						array_push($dt,json_encode($arr));
				}
				    $_SESSION['hc'] = $dt;
			    }
		    }
	    }else $dt = $_SESSION['hc'];
}
echo json_encode($dt);

?>
   
 
