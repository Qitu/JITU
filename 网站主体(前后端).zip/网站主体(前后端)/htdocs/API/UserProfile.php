<?php

header("Content-type: text/html; charset=utf-8");

if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
    require_once '../Database/Timer.php';
	if(isset($_POST["UID"])){

		require_once './safe.php'; //安全系统
		if($sql = connectSQL()){
			$ID = filter($_POST["UID"]);
			$z=$sql->query("SELECT `MomentID`,`MDate`,`Content`,`Like`,`Pictures` FROM `Moment` WHERE SenderID='".$ID."' Order By `MDate` Desc");
			if($z->num_rows>0){
			    $data = array();
			    while($moment = $z->fetch_row()){
				    array_push($data,array("ID"=>$moment[0],"time"=>$moment[1],"Content"=>decode($moment[2]),"sub"=>$moment[3],"img"=>"https://jitugoods.oss-ap-southeast-3.aliyuncs.com/moments/".$moment[0].'-1.jpg',"pic"=>$moment[4]));
					}
					echo json_encode($data);
		    }else echo json_encode(array('status'=>'faild2'));
		}else echo json_encode(array('status'=>'faild'));
	}
 }
 
 
  function decode($str){
	$text=json_encode($str);
	$text = preg_replace_callback('/!I!/i',function($str){
		return '\\';
	},$text); 
	return json_decode($text);
 }
?>
   
 
