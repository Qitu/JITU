<?php

header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
    require_once '../Database/Timer.php';
	if(canDo() && isset($_POST["Token"])){
		require_once './safe.php'; //安全系统
		if($sql = connectSQL()){
			$token = filter($_POST["Token"]); $lang = 'EN';
		    if(isset($_SERVER["QUERY_STRING"])){
			    if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		    }
			$z=$sql->query("SELECT `UID` FROM `AppUser` WHERE Token='".$token."'");
			if($z->num_rows>0){
				$user = $z->fetch_row();
				
				$c=$sql->query("SELECT `AppOrder`.`store`,`AppOrder`.`status`,`AppOrder`.`goods`,`AppOrder`.`ID`,`stores`.`".$lang."_Name` FROM `AppOrder`,`stores` WHERE AppOrder.client=".$user[0]." AND stores.SID=AppOrder.store ORDER BY ID desc");
			    if($c->num_rows>0){
					while($_store = $c->fetch_row()){
						$goods_data = array();
						
						$tj = '';
						$arr = explode('.', $_store[2]);
						$quantity = array();
						if(count($arr) > 0){
							for($i=0;$i<count($arr);$i++){
								$ar = explode(',', $arr[$i]);
								if(count($ar) == 2){
									if($tj == '')$tj = 'AND GID='.$ar[0];
									else $tj .= ' OR GID='.$ar[0];
									$quantity[$ar[0]] = $ar[1];
								}
						    }
						}
						
						if($tj != ''){
						$x=$sql->query("SELECT `GID`,`img`,`".$lang."_Name`,`Price` FROM `Goods` WHERE ShopID='".$_store[0]."' ".$tj);
						if($x->num_rows>0){
						    while($GDT = $x->fetch_row()){
								array_push($goods_data,array($GDT[1],$GDT[2],$quantity[$GDT[0]],$GDT[3]));
							}
						}
						}
						
						//$goods_data = array(array("../../image/1.png","呵呵","x2","12"),array("../../image/1.png","呵呵hhh","x2","12"));
						$arr = array("ID"=> $_store[3], "name"=> $_store[4], "status"=> $_store[1], "goods"=> $goods_data,"s"=> $_store[0]);
						array_push($dt,json_encode($arr));
				    }
			    }
			
			}else $dt = array('????');
		}
	}
}
echo json_encode($dt);
?>
   