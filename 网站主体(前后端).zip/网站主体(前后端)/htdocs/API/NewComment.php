<?php

//header("Content-type: application/json; charset=utf-8");

/*
0: success
1: faild
2: baned
3: Invalid authorization
*/

function userTextEncode($str){
    if(!is_string($str))return $str;
    if(!$str || $str=='undefined')return '';

    $text = json_encode($str); //暴露出unicode
    $text = preg_replace_callback("/(\\\u[ed][0-9a-f]{3})/i",function($str){
        return "!I!".addslashes($str[0]);
    },$text); //将emoji的unicode留下，其他不动，这里的正则比原答案增加了d，因为我发现我很多emoji实际上是\ud开头的，反而暂时没发现有\ue开头。
    return json_decode($text);
}

function beSticker($str){
	$text=json_encode($str);
	$text = preg_replace_callback('/!I!/i',function($str){
		return '\\';
	},$text);
	return json_decode($text);
}

$dt = array('status'=>'1');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
	if(isset($_POST["key"]) && isset($_POST["info"]) && isset($_POST["mid"])){
		require_once './safe.php';
		$key = filter($_POST["key"]);
		$info = userTextEncode($_POST["info"]);
		$info = filter($info);
		$moment = filter($_POST["mid"]);
		
		if($sql = connectSQL()){
			$z=$sql->query("SELECT `UID`,`UserName` FROM `AppUser` WHERE Token='".$key."'");
			if($z->num_rows>0){
				$user = $z->fetch_row();
				$z=$sql->query("SELECT `Content`,`Sender` FROM `Moment` WHERE MomentID='".$moment."'");
				if($z->num_rows>0){//有这回事
				    $mid = $z->fetch_row();
					$datetime=date('Y-m-d H:i:s',time());
					if($sql->query("INSERT INTO Moment_Comment(`MomentID`,`UserID`,`User`,`CommentContent`,`PostDate`) VALUES('".$moment."',".$user[0].",'".$user[1]."','".$info."','".$datetime."')")){
						echo json_encode(array('status'=>'0','id'=>''.$user[0],'name'=>''.$user[1]));
						
						$z=$sql->query("SELECT `AppUser`.`PushID`,`AppUser`.`Lang` FROM `AppUser`,`Moment` WHERE AppUser.UID<>".$user[0]." AND AppUser.UID=Moment.SenderID AND Moment.MomentID=".$moment);
						if($z->num_rows>0){
							$RID = $z->fetch_row();
							if($RID[0] != "0"){//推送条件达到
								require_once './push.php';//推送模块
							    $push = new Push();//配置信息
							    $params = array(
						            'plats' => array(1, 2),
							        # 设置推送范围
							        'target' => 4, 'content' => $_POST["info"], 'type' => 1, 'registrationIds' => array($RID[0]),
							        # 设置Android定制信息
							        'androidTitle' =>  $user[1], 'androidstyle' => 1, 'androidVoice' => 1, 'androidShake' => 1, 'androidLight' => 1,"androidContent"=>[$_POST["info"]],
							        # 设置iOS定制信息
							        'iosProduction' => 1, 'title' => 'UniTalk', 'subtitle' => $user[1], 'sound' => 'default', 'badge' => 1, 'slientPush' => 1, 'contentAvailable' => 1, 'mutableContent' => 1,
									'extras' => array('Type' => 1, 'UID'=>$user[0], 'ID' => $moment, 'ContentInfo'=>beSticker($mid[0]), 'ContentSender'=>$mid[1]),
						        );
								$res = $push->postPush($params, 1);
							}
						}
						return;
					}
				}else $dt = array('status'=>'2');
			}else $dt = array('status'=>'3');
		}
	}
}
echo json_encode($dt);

?>
   
 
