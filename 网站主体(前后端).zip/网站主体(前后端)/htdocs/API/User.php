<?php

header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
    require_once '../Database/Timer.php';
	if(canDo() && isset($_POST["phone"])){

		require_once './safe.php'; //安全系统
		if($sql = connectSQL()){
			$ID = filter($_POST["phone"]); $RID = filter($_POST["RID"]); $lang = 'EN';
			//if(count($RID) < 5) {echo json_encode(array('status'=>'vaildRegID'));return;}
		    if(isset($_SERVER["QUERY_STRING"])){
			    if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		    }
			$z=$sql->query("SELECT `UID`,`UserName`,`Des` FROM `AppUser` WHERE Phone='".$ID."'");
				require_once './Random.php'; 
				$token=randomkeys(30);
			if($z->num_rows>0){
				$user = $z->fetch_row();
				if($sql->query("UPDATE `AppUser` SET `Token`='".$token."',`PushID`='".$RID."' WHERE Phone='".$ID."'")){
					echo json_encode(array('status'=>'success', 'token'=>$token, 'id'=>$user[0], 'username'=>$user[1], 'des'=>$user[2] ));
				}else{
					echo json_encode(array('status'=>'faild'));
				}
			}else{
				if($sql->query("INSERT INTO AppUser(`Phone`,`Token`,`Lang`,`PushID`) VALUES('".$ID."','".$token."','".$lang."','".$RID."')")){
					echo json_encode(array('status'=>'success', 'token'=>$token, 'username'=>'', 'des'=>'' ));
				}else{
					echo json_encode(array('status'=>'faild'));
				}
			}
		}
	}
}
?>
   
 
