<?php

header("Content-type: text/html; charset=utf-8");

if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
	if(isset($_POST["key"])){

		require_once './safe.php'; //安全系统
		if($sql = connectSQL()){
			$ID = filter($_POST["key"]);
			$z=$sql->query("SELECT `UID` FROM `AppUser` WHERE Token='".$ID."'");
			if($z->num_rows>0){
				 $user = $z->fetch_row();
				 $z=$sql->query("SELECT `MomentID`,`MDate`,`Content`,`Like`,`Pictures` FROM `Moment` WHERE SenderID='".$user[0]."' Order By `MDate` Desc");
			 if($z->num_rows>0){
			    $data = array();
			    while($moment = $z->fetch_row()){
					array_push($data,array("ID"=>$moment[0],"time"=>$moment[1],"Content"=>decodeIt($moment[2]),"sub"=>$moment[3],"img"=>"https://jitugoods.oss-ap-southeast-3.aliyuncs.com/moments/".$moment[0].'-1.jpg',"pic"=>$moment[4]));
				}
				echo json_encode($data);
			}else echo json_encode(array('status'=>'faild2'));
			}else echo json_encode(array('status'=>'faild'));
			
		}
	}
 }
 
 
 function decodeIt($str){
	$text=json_encode($str);
	$text = preg_replace_callback('/!I!/i',function($str){
		return '\\';
	},$text); 
	return json_decode($text);
 }
?>
   
 
