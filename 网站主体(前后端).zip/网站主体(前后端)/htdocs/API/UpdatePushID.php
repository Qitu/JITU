<?php

//header("Content-type: application/json; charset=utf-8");

/*
200: success
401: No authorization
403: Not allowed, rejected
*/

$dt = array('status'=>'401');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
	if(isset($_POST["key"]) && isset($_POST["pushid"])){
		require_once './safe.php';
		$key = filter($_POST["key"]);
		$pushid = filter($_POST["pushid"]);
		  
			if($sql = connectSQL()){
			    $z=$sql->query("SELECT `UID` FROM `AppUser` WHERE Token='".$key."'");//验证身份
			    if($z->num_rows>0){
				    $user = $z->fetch_row();
						if($sql->query("UPDATE `AppUser` SET `PushID`='".$pushid."' WHERE UID=".$user[0])){
						    echo json_encode(array('status'=>'200')); return;
					    }
			   }else $dt = array('status'=>'403');
		   }
	 }
}
echo json_encode($dt);
?>
   
 
