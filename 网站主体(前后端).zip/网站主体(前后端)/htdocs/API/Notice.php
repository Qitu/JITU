<?php
header("Content-type: text/html; charset=utf-8");

if($_SERVER['HTTP_HOST'] == "jitu.fun"){
		require_once './safe.php'; //安全系统
		$msg = '';
		if(isset($_SERVER["QUERY_STRING"])){
			if(filter($_SERVER["QUERY_STRING"])  == '0') $msg = '';
			else $msg = "We will close order system for a while, and we will come back soon";
		}
		echo json_encode(array('status'=>'successs', 'msg'=>$msg));
}

?>
   
 
