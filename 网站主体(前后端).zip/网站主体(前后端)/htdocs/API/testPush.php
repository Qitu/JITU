<?php

require_once './push.php';//推送模块
$push = new Push();//配置信息
$params = array(
'plats' => array(1, 2),
# 设置推送范围
'target' => 4, 'content' => 'testInfo', 'type' => 1, 'registrationIds' => array('7b4a03311ac497c54cfd6ac5'),
# 设置Android定制信息
'androidTitle' =>  'test', 'androidstyle' => 1, 'androidVoice' => 1, 'androidShake' => 1, 'androidLight' => 1, "androidContent"=>["第一行","第二行"],
'iosProduction' => 1, 'title' => 'UniTalk', 'subtitle' => $user[1], 'sound' => 'default', 'badge' => 1, 'slientPush' => 1, 'contentAvailable' => 1, 'mutableContent' => 1,
'extras' => array('Type' => 1, 'UID'=>1, 'ID' => 2, 'ContentInfo'=>'???', 'ContentSender'=>1),
);
$res = $push->postPush($params, 1);

var_dump($res)
?>
   
 
