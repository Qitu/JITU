<?php

header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	 define('IN_SYS', TRUE);
	 require_once '../Database/Mysql.php';
	 if(isset($_POST["token"])){
	   require_once './safe.php'; //安全系统
		  if($sql = connectSQL()){
			    $ID = filter($_POST["token"]); $lang = 'EN';
		     if(isset($_SERVER["QUERY_STRING"])){
			      if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		     }
			   $z=$sql->query("SELECT `UserName`,`Des`,`Gender` FROM `AppUser` WHERE token='".$ID."'");
			   if($z->num_rows>0){
				    $user = $z->fetch_row();
				    echo json_encode(array('status'=>'success', 'username'=>$user[0], 'des'=>$user[1], 'gender'=>$user[2]));
			   }
		  }
	 }
}
?>
   
 
