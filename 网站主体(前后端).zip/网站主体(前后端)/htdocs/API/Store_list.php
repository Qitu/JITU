<?php

header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
	if(isset($_POST["SID"])){
		require_once './safe.php'; //安全系统
		$lang = 'EN';
		if(isset($_SERVER["QUERY_STRING"])){
			if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		}
		if($sql = connectSQL()){
			$ID = filter($_POST["SID"]);
			$z=$sql->query("SELECT 
						            `GID`,`".$lang."_Name`,`".$lang."_Size`,`Price`,`img`,`".$lang."_Class`,`sold`
									FROM `Goods` WHERE ShopID=".$ID);
			if($z->num_rows>0){
					while($_store = $z->fetch_row()){
						    $_store[1] = str_replace("_"," ",$_store[1]);
							$arr = array("ID"=>$_store[0],"Name"=>$_store[1], "Tag"=>$_store[2],"Price"=>$_store[3],"Image"=>$_store[4],"Type"=>$_store[5],"Sold"=>$_store[6],"Quantity"=> 0);
							array_push($dt,json_encode($arr));
				}
			}
		}
	}
}
shuffle($dt);
echo json_encode($dt);



/*
$arr = array(
                  "goods"=> array(
                    array("ID"=> 1, "Type"=> "Apple", "Name"=> "苹果1", "Price"=> 100, "Tag"=> "便宜实惠", "Image"=> "../../image/7.jpg", "Quantity"=> 0),
                    array("ID"=> 2, "Type"=> "Apple", "Name"=> "苹果2", "Price"=> 20, "Tag"=> "便宜实惠1", "Image"=> "../../image/7.jpg", "Quantity"=> 0),
					array("ID"=> 3, "Type"=> "Apple", "Name"=> "苹果3", "Price"=> 0.5, "Tag"=> "便宜实惠", "Image"=> "../../image/7.jpg", "Quantity"=> 0),
					array("ID"=> 5, "Type"=> "Apple", "Name"=> "苹果4", "Price"=> 4, "Tag"=> "便宜实惠", "Image"=> "../../image/7.jpg", "Quantity"=> 0),
					)
            );
     echo json_encode($arr);
	 */
?>
   
 
