<?php

header("Content-type: text/html; charset=utf-8");

/*
0: success
1: faild
2: overload
*/


$dt = array('status'=>'1');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
	if(isset($_POST["data"]) && isset($_POST["token"]) && isset($_POST["store"]) && isset($_POST["info"]) && isset($_POST["payment"])){
		
		require_once './safe.php';
		$token = filter($_POST["token"]);
		$goods = filter($_POST["data"]);
		$store = filter($_POST["store"]);
		$info = filter($_POST["info"]);
		$payment = filter($_POST["payment"]);
		
		$arr = explode(";",$info);
		if(count($arr) == 2) {
			$ar = explode(",",$arr[1]);
		if(count($ar) < 2) {echo json_encode(array('status'=>'1')); exit;}
	    }else {echo json_encode(array('status'=>'1')); exit;}
		
		$port = 0;
		if(isset($_POST["port"])) $port = filter($_POST["port"]);
		
			if($sql = connectSQL()){
			    $z=$sql->query("SELECT `UID` FROM `AppUser` WHERE Token='".$token."'");
			    if($z->num_rows>0){
						$user = $z->fetch_row();
						
						$z=$sql->query("SELECT `ID` FROM `AppOrder` WHERE client='".$user[0]."' AND status=0");
						if(($z->num_rows)<2){
							$tj = ''; $arr = explode('.', $goods);
							if(count($arr) > 0){
								for($i=0;$i<count($arr);$i++){
									$ar = explode(',', $arr[$i]);
									if(count($ar) == 2) $tj .= $ar[0].','.$ar[1].'.';
								}
								if($tj != ''){
									if($sql->query("INSERT INTO AppOrder(`goods`,`client`,`store`,`client_info`,`date`,`Port`,`payment`) VALUES('".$goods."','".$user[0]."',".$store.",'".$info."','".date('Y-m-d H:i:s',time())."',".$port.",".$payment.")")){
									 	echo json_encode(array('status'=>'0','id'=>''.mysqli_insert_id($sql)));
									}else echo json_encode(array('status'=>'1'));
									return;
								}
							}
						}else{
							echo json_encode(array('status'=>'2'));
							return;
						}
						
			    }
		    }
	}
}
echo json_encode($dt);

?>
   
 
