<?php

//header("Content-type: application/json; charset=utf-8");

/*
0: success
1: faild
2: baned
3: Invalid authorization
*/

$dt = array('status'=>'1');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	 define('IN_SYS', TRUE);
	 require_once '../Database/Mysql.php';
	 if(isset($_POST["key"]) && isset($_POST["info"]) && isset($_POST["MID"])){
		  require_once './safe.php';
		  $key = filter($_POST["key"]);
		  $info = filter($_POST["info"]);
		  $MID = filter($_POST["MID"]);
		  
			 if($sql = connectSQL()){
			   $z=$sql->query("SELECT `UID`,`UserName` FROM `AppUser` WHERE Token='".$key."'");//验证身份
			   if($z->num_rows>0){
						   $user = $z->fetch_row();
						   $z=$sql->query("SELECT `client` FROM `Blacklist` WHERE client='".$user[0]."'");
						   if($z->num_rows<1){//不是黑户
						     if($sql->query("UPDATE Moment SET Content='".$info."' WHERE MomentID=".$MID)){
									 	   echo json_encode(array('status'=>'0')); return;
									   }
						   }else $dt = array('status'=>'2');
			   }else $dt = array('status'=>'3');
		  }
	 }
}
echo json_encode($dt);
?>
   
 
