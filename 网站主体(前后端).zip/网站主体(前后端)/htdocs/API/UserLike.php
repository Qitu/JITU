<?php

header("Content-type: text/html; charset=utf-8");

if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	 define('IN_SYS', TRUE);
	 require_once '../Database/Mysql.php';
  require_once '../Database/Timer.php';
	 if(canDo() && isset($_POST["key"]) && isset($_POST["mid"])){
	    require_once './safe.php'; //安全系统
	    $key = filter($_POST["key"]);
		$mid = filter($_POST["mid"]);
		if($sql = connectSQL()){
		    $z=$sql->query("SELECT `UID` FROM `AppUser` WHERE token='".$key."'");
			if($z->num_rows>0){
				$user = $z->fetch_row();
				$z=$sql->query("SELECT `LID` FROM `UserLike` WHERE `RootID`='".$mid."' AND `UID`=".$user[0]."");
			    if($z->num_rows>0){
				    echo json_encode(array('status'=>'0'));
			    }else echo json_encode(array('status'=>'5'));
			}else echo json_encode(array('status'=>'4'));
		}else echo json_encode(array('status'=>'3'));
	}else echo json_encode(array('status'=>'2'));
	echo json_encode(array('status'=>'1'));
}
?>
   
 
