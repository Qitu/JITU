<?php

header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
    require_once '../Database/Timer.php';
	if(canDo() && isset($_POST["GID"])){
		require_once './safe.php'; //安全系统
		if($sql = connectSQL()){
			$ID = filter($_POST["GID"]); $lang = 'EN';
		    if(isset($_SERVER["QUERY_STRING"])){
			    if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		    }
			$z=$sql->query("SELECT 
						            `Goods`.`".$lang."_Name`,`Goods`.`".$lang."_info`,`Goods`.`Price`,`Goods`.`img`,`ShopID`,`halal`
									FROM `Goods`,`stores` WHERE Goods.GID=".$ID."");
			if($z->num_rows>0){
				$goods = $z->fetch_row();
				$goods[0] = str_replace("_"," ",$goods[0]);
				$goods[1] = str_replace("_"," ",$goods[1]);
				$goods[1] = str_replace("=","<br>",$goods[1]);
				$arr = array("Store"=>$goods[4],"name"=>$goods[0], "info"=>$goods[1],"price"=>$goods[2],"img"=>$goods[3], "halal"=> $goods[5], "promote"=>array());
				$dt = array();
				$z=$sql->query("SELECT 
						            `Goods`.`img`,`Goods`.`".$lang."_Name`,`Goods`.`Price`,`Goods`.`GID`
									FROM `Goods`,`stores` WHERE Goods.ShopID=stores.SID AND Goods.ShopID>0 AND stores.Status<>0 order by rand() limit 6");
				if($z->num_rows>0){
					while($_store = $z->fetch_row()){
						$ar = array('https://jitugoods.oss-ap-southeast-3.aliyuncs.com/goods/'.$_store[0].'.jpg',$_store[1],$_store[2],$_store[3]);
						array_push($dt,$ar);
				    }
			    }
				
				
				$arr["promote"] = $dt;
				/*
				  array(
                    array("../image/5.jpg","商品1","18.5", '3'),
                    array("../image/5.jpg","商品2","18.5", '1'),
                    array("../image/5.jpg","商品2","18.5", '2'),
                    array("../image/5.jpg","商品2","18.5", '5'),
                  )
				  */
				  
				echo json_encode($arr);
			}
		}
	}
}
?>
   
 
