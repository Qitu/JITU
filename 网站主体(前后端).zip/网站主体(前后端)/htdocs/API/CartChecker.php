<?php

header("Content-type: text/html; charset=utf-8");

$dt = array();
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	define('IN_SYS', TRUE);
	require_once '../Database/Mysql.php';
	if(isset($_POST["data"])){
		require_once './safe.php'; //安全系统
		$lang = 'EN';
		if(isset($_SERVER["QUERY_STRING"])){
			if(filter($_SERVER["QUERY_STRING"])  == '0') $lang = 'ZH';
		}
		$tj = '';
		$arr = explode('.', $_POST["data"]);
		$quantity = array();
		if(count($arr) > 0){
			for($i=0;$i<count($arr);$i++){
				$ar = explode(',', $arr[$i]);
				if(count($ar) == 2){
					if($tj == '')$tj = 'WHERE GID='.$ar[0];
					else $tj .= ' OR GID='.$ar[0];
					$quantity[$i] = $ar[1];
				}
			}
			if($tj != '' && $sql = connectSQL()){
			        $z=$sql->query("SELECT 
						            `GID`,`Price`
									FROM `Goods` ".$tj);
			        if($z->num_rows>0){
						$total = ''; $index = 0;
						while($_goods = $z->fetch_row()){
							$total = $total + ($_goods[1] * $quantity[$index]);
							$index++;
				        }
						echo json_encode(array('status'=>'success','total'=>"?".$total));
			        }else echo json_encode(array('status'=>'faild'));
		        }else echo json_encode(array('status'=>'faild'));
		}else echo json_encode(array('status'=>'faild'));
	}else echo json_encode(array('status'=>'faild'));
}else echo json_encode(array('status'=>'faild'));



/*
$arr = array(
                  "goods"=> array(
                    array("ID"=> 1, "Type"=> "Apple", "Name"=> "苹果1", "Price"=> 100, "Tag"=> "便宜实惠", "Image"=> "../../image/7.jpg", "Quantity"=> 0),
                    array("ID"=> 2, "Type"=> "Apple", "Name"=> "苹果2", "Price"=> 20, "Tag"=> "便宜实惠1", "Image"=> "../../image/7.jpg", "Quantity"=> 0),
					array("ID"=> 3, "Type"=> "Apple", "Name"=> "苹果3", "Price"=> 0.5, "Tag"=> "便宜实惠", "Image"=> "../../image/7.jpg", "Quantity"=> 0),
					array("ID"=> 5, "Type"=> "Apple", "Name"=> "苹果4", "Price"=> 4, "Tag"=> "便宜实惠", "Image"=> "../../image/7.jpg", "Quantity"=> 0),
					)
            );
     echo json_encode($arr);
	 */
?>
   
 
