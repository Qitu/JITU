<?php

header("Content-type: text/html; charset=utf-8");
/*
0: success
1: faild
3: Invalid authorization
*/
$dt = array('status'=>'1');
if($_SERVER['HTTP_HOST'] == "jitu.fun"){
	 define('IN_SYS', TRUE);
	 require_once '../Database/Mysql.php';
	 if(isset($_POST["key"]) && isset($_POST["mid"]) && isset($_POST["Action"])){
		  require_once './safe.php';
		  $key = filter($_POST["key"]);
		  $mid = filter($_POST["mid"]);
		  $Action = filter($_POST["Action"]);
		  
			 if($sql = connectSQL()){
			   $z=$sql->query("SELECT `UID` FROM `AppUser` WHERE Token='".$key."'");//验证身份
			   if($z->num_rows>0){
				   $user = $z->fetch_row();
				   
				   if($Action=="0"){
					    if($sql->query("DELETE FROM `UserLike` WHERE RootID='".$mid."' AND UID='".$user[0]."'")){
						    echo json_encode(array('status'=>'4')); return;
					    }else $dt = array('status'=>'1');
				   }else {
					    if($sql->query("INSERT INTO `UserLike` (`UID`, `RootID`, `LDate`) VALUES('".$user[0]."', ".$mid.", '".date('Y-m-d H:i:s',time())."')")){
						    echo json_encode(array('status'=>'0')); return;
					    }else $dt = array('status'=>'1');
				   }
			   }else $dt = array('status'=>'3');
		  }
	 }
}
echo json_encode($dt);
?>
   
 
