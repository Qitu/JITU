-- MySQL dump 10.13  Distrib 5.1.73, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: gdm340875110_db
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AppOrder`
--

DROP TABLE IF EXISTS `AppOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AppOrder` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) DEFAULT '0',
  `goods` varchar(300) DEFAULT NULL,
  `client` int(11) DEFAULT NULL,
  `webClient` varchar(50) DEFAULT NULL,
  `payment` int(11) DEFAULT '0',
  `payStatus` int(11) DEFAULT '0',
  `paied` int(11) DEFAULT NULL,
  `store` int(11) DEFAULT NULL,
  `deliver` char(50) DEFAULT '01126861762',
  `client_info` char(50) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `Port` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=156 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AppOrder`
--

LOCK TABLES `AppOrder` WRITE;
/*!40000 ALTER TABLE `AppOrder` DISABLE KEYS */;
INSERT INTO `AppOrder` VALUES (16,2,'82,1.',4,NULL,0,0,NULL,1,'0166180630','UKM,VillaTropika,816;luoxiao,01128727872',1,'2019-03-28 19:29:14',3),(17,3,'2,5.',4,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,KolejRahimKajaiBangiUKM;Muhtasim,01126',1,'2019-03-29 01:31:12',2),(15,2,'4,1.9,2.22,1.',4,NULL,0,0,NULL,1,'0166180630','UKM,SavileKajang,blockb;王翰卿,01116317293',0,'2019-03-28 19:04:53',4),(14,2,'8,2.3,1.2,1.23,1.12,2.7,2.',4,NULL,0,0,NULL,1,'0166180630','UKM,VillaTropika,15floor;Andy,0172388926',17,'2019-03-28 14:52:23',3),(37,2,'31,1.66,1.',26,NULL,0,0,NULL,2,'0166180630','UKM,IbuZain,k18b;郝浩文,0183567293',8,'2019-04-02 11:15:23',2),(20,2,'4,1.22,1.24,1.',19,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,19B;申sq,01164532625',12.5,'2019-03-29 11:21:36',2),(21,2,'13,3.16,2.24,1.',15,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,K19B;王腾腾,01137900362',32,'2019-03-29 12:13:48',2),(22,2,'9,1.21,1.4,1.7,2.',4,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain;史娅雯,0176670730',13.5,'2019-03-29 12:45:33',2),(26,2,'1,5.4,1.6,2.7,2.3,3.9,1.',24,NULL,0,0,NULL,1,'0166180630','UKM,VillaTropika,15-04;Alben,01161282099',28,'2019-03-31 22:18:13',3),(24,2,'1,2.9,1.',22,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,ibuzain19B;',9,'2019-03-31 19:45:44',2),(25,2,'15,2.16,1.21,1.',20,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19b305;堂堂正正爱丽丝,01164565913',55.5,'2019-03-31 22:01:16',2),(27,2,'21,1.',21,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19b302;',6,'2019-04-01 00:37:53',2),(28,2,'3,3.5,1.13,3.15,1.16,1.',15,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,K19B;王腾腾,01137900362',58.5,'2019-04-01 10:22:22',2),(29,2,'4,3.19,1.',19,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,19B;申sq,01164532625',22.5,'2019-04-01 10:53:34',2),(30,2,'66,1.71,1.',26,NULL,0,0,NULL,2,'0166180630','UKM,IbuZain,k19b302;张夕茗,0104278270',28.5,'2019-04-01 12:41:50',2),(39,3,'1,2.2,3.',4,NULL,0,0,NULL,1,'0','UKM,VillaTropika;Andy,0172388926',NULL,'2019-04-02 11:46:08',3),(38,2,'18,1.23,1.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k18b;郝浩文,0183567293',7,'2019-04-02 11:16:28',2),(40,2,'70,1.74,2.75,2.31,1.',26,NULL,0,0,NULL,2,'0166180630','UKM,IbuZain,k18b;韩潇潇,0183252430',12,'2019-04-02 12:16:08',2),(41,2,'1,2.7,2.23,1.',27,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain;贾子尧,0128570925',10,'2019-04-02 12:32:15',2),(42,2,'15,1.23,1.11,1.',15,NULL,0,0,NULL,1,'0','UKM,IbuZain,K19B;王腾腾,01137900362',32,'2019-04-02 14:48:17',2),(43,2,'15,3.',20,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19b305;堂堂正正爱丽丝,01164565913',66,'2019-04-03 09:07:53',2),(44,2,'4,2.16,1.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k18b;韩潇潇,0183252430',20.5,'2019-04-03 09:46:34',2),(45,3,'4,1.9,1.',26,NULL,0,0,NULL,1,'0','UKM,IbuZain,k19a412;哈哈哈大哥,0176659377',NULL,'2019-04-03 10:10:49',2),(46,2,'4,2.9,1.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19a412;哈哈哈,0176659377',10,'2019-04-03 10:35:53',2),(47,2,'24,1.9,1.6,1.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19b;史鸭文,0176670730',9.5,'2019-04-03 10:46:47',2),(48,2,'4,3.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19b;申sq,01164532625',10.5,'2019-04-03 11:20:11',2),(49,2,'4,1.23,2.18,1.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,19b;许昕昕,0186605274',13.5,'2019-04-03 11:47:58',2),(50,2,'4,1.18,1.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19a;马昊#,0176452880',7.5,'2019-04-03 11:54:09',2),(51,2,'13,2.15,1.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,19b;陈思言,0172380992',26,'2019-04-03 12:06:03',2),(52,2,'5,1.15,1.',15,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,K19B;王腾腾,01137900362',34,'2019-04-03 16:15:42',2),(53,2,'21,1.23,1.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19a;曲正洋,0173389410',6,'2019-04-04 10:18:09',2),(54,2,'4,1.7,1.',26,NULL,0,0,NULL,1,'0','UKM,IbuZain,k19a407;江斌?,01137629312',5.5,'2019-04-04 14:10:33',2),(55,2,'3,1.7,2.9,2.11,1.21,1.22,1.23,1.',26,NULL,0,0,NULL,1,'0','UKM,IbuZain,k19a;杨童,0149152104',30,'2019-04-05 09:21:40',2),(56,2,'15,1.24,1.16,1.13,4.',15,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,K19B;王腾腾,01137900362',48,'2019-04-15 11:26:45',2),(57,2,'22,1.6,2.',19,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,19B;申sq,01164532625',9,'2019-04-15 11:53:26',2),(58,2,'22,1.3,3.',26,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,k19a;王腾辉,0176674676',11,'2019-04-15 11:53:40',2),(59,2,'3,2.7,2.12,1.24,1.',4,NULL,0,0,NULL,1,'0166180630','UKM,VillaTropika,15Floorcallme!;Andy,0172388926',17.5,'2019-04-16 09:13:07',3),(60,2,'66,4.',26,NULL,0,0,NULL,2,'0166180630','UKM,IbuZain,k18c;郝号文,0176674676',24,'2019-04-17 11:17:24',2),(61,2,'13,4.24,1.16,1.15,1.',15,NULL,0,0,NULL,1,'0','UKM,IbuZain,K19B;王腾腾,01137900362',51.5,'2019-04-19 11:26:21',2),(62,2,'17,1.7,1.4,2.11,1.27,1.',15,NULL,0,0,NULL,1,'0','UKM,IbuZain,K19B307;张瑾。,01137067469',33.5,'2019-04-20 13:12:38',2),(63,2,'15,1.16,1.13,5.',15,NULL,0,0,NULL,1,'0','UKM,IbuZain,K19B307;王腾腾,01137900362',49,'2019-04-20 20:16:10',2),(64,2,'15,1.21,1.',20,NULL,0,0,NULL,1,'0','UKM,IbuZain,k19b305;堂堂正正爱丽丝,01164565913',28.5,'2019-04-22 14:06:52',2),(65,2,'7,3.6,2.12,1.11,1.',4,NULL,0,0,NULL,1,'0166180630','UKM,SavileKajang,龙毓;龙毓。。,0172388926',21.5,'2019-04-23 19:12:17',4),(66,2,'12,1.21,1.22,1.4,1.',4,NULL,0,0,NULL,1,'0166180630','UKM,VillaTropika,1504;Andy,0172388926',16.5,'2019-04-24 13:52:26',3),(67,2,'15,1.13,5.16,1.11,1.',15,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,K19B307;王腾腾,01137900362',56,'2019-04-30 11:32:30',2),(68,2,'4,2.22,1.24,1.',31,NULL,0,0,NULL,1,'0','UKM,IbuZain,19B307;JENNY,01137067469',20,'2019-05-01 13:53:17',2),(69,2,'75,2.106,3.',31,NULL,0,0,NULL,2,'0','UKM,IbuZain,19B307;JENNY,01137067469',14.5,'2019-05-01 13:54:59',2),(70,2,'85,5.69,2.',4,NULL,0,0,NULL,2,'0','UKM,VillaTropika,1504;Andy,0172388926',0,'2019-05-03 11:25:21',3),(71,2,'16,1.13,5.4,1.15,1.',15,NULL,0,0,NULL,1,'0','UKM,IbuZain,K19B307;王腾腾,01137900362',52,'2019-05-03 21:58:53',2),(72,2,'12,1.7,2.',4,NULL,0,0,NULL,1,'0','UKM,VillaTropika,1504;Andy,0172388926',0,'2019-05-04 00:49:12',3),(73,2,'16,1.13,7.5,1.',15,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,K19B307;王腾腾,01137900362',43,'2019-05-07 11:55:58',2),(74,2,'109,1.74,5.',31,NULL,0,0,NULL,2,'0','UKM,IbuZain,19B307;JENNY,01137067469',19,'2019-05-07 17:55:34',2),(75,2,'13,3.4,1.',31,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,19B307;JENNY,01137067469',13,'2019-05-07 17:57:29',2),(76,2,'7,3.4,1.',4,NULL,0,0,NULL,1,'0166180630','UKM,VillaTropika,1504;Andy,0172388926',0,'2019-05-08 11:35:19',3),(77,2,'106,5.',31,NULL,0,0,NULL,2,'0','UKM,IbuZain,19B307;JENNY,01137067469',19,'2019-05-09 10:36:04',2),(78,2,'21,1.7,1.4,2.16,2.',31,NULL,0,0,NULL,1,'0','UKM,IbuZain,19B307;layna,01121033913',42,'2019-05-09 10:43:00',2),(79,2,'13,6.15,1.16,1.',15,NULL,0,0,NULL,1,'0166180630','UKM,IbuZain,K19B307;王腾腾,01137900362',51,'2019-05-12 09:58:49',2),(80,2,'7,4.9,1.4,2.24,1.',4,NULL,0,0,NULL,1,'0166180630','UKM,VillaTropika,1504;Andy,0172388926',26,'2019-05-12 12:28:24',3),(81,3,'9,1.1,1.23,1.22,1.',33,NULL,0,0,NULL,1,'0','UKM,KolejZaba,BustopAtasKolejPendetaZaaba;Atikah,0',18,'2019-05-15 01:44:54',1),(82,3,'9,1.1,1.23,1.22,1.',33,NULL,0,0,NULL,1,'0','UKM,KolejZaba,BustopAtasKolejPendetaZaaba;Atikah,0',18,'2019-05-15 02:08:58',1),(83,2,'13,10.8,3.11,1.3,3.',15,NULL,0,0,NULL,1,'0','UKM,IbuZain,K19B307;王腾腾,01137900362',43,'2019-05-16 13:38:26',2),(102,2,'23,2.',NULL,'Mohd Firdaus0172377589',0,0,NULL,1,'0','Kolej pendeta zaba, H1, 2125',6,'2019-09-18 12:40:32',0),(103,2,'74,1.75,2.76,5.',NULL,'Firdaus0172377589',0,0,NULL,2,'0',NULL,9.5,'2019-09-18 14:04:07',1),(101,2,'3,5.',NULL,'Jiang Zhimu01121881849',0,0,NULL,1,'0','KPZ, H1, 1321',10,'2019-09-18 07:01:31',0),(107,2,'2,7.7,2.24,1.',NULL,'李可心-01121026439',0,0,NULL,1,'0','k18b',20,'2019-09-23 17:46:55',1),(129,2,'30,1.',4,NULL,2,0,1,3,'0','UKM,KolejZaba;徐瑞迪,13357220477',NULL,'2020-01-22 10:09:14',1),(140,3,'29,1.',NULL,'李文博-01126861762',1,0,NULL,3,'0',NULL,50,'2020-02-19 20:58:46',1),(141,3,'29,1.',NULL,'李文博-01126861762',1,0,NULL,3,'0',NULL,50,'2020-02-19 21:01:26',1),(142,3,'29,1.',NULL,'Andy-0172388926',1,0,NULL,3,'0',NULL,52,'2020-02-19 21:06:01',2),(139,3,'122,1.',NULL,'测试订单-0172388926',1,0,NULL,3,'0','雨花区福乐名园',40,'2020-02-17 16:23:31',6),(136,2,'29,1.',NULL,'徐瑞迪-0172388926',2,0,1,3,'0','k19A，203',3,'2020-02-11 20:46:35',0),(138,3,'122,2.',NULL,'Andy-0172388926',1,0,NULL,3,'0','Kolej ibu zain, 43600 Bangi Selangor, Malaysia',80,'2020-02-17 16:18:50',1),(143,3,'29,1.',NULL,'Andy-13357220477',1,0,NULL,3,'01126861762','雨花区福乐名园',52,'2020-02-19 21:13:20',1),(144,2,'151,2.156,1.',NULL,'zhang jin-01137067469',1,0,NULL,3,'01126861762','k19b',22,'2020-02-25 19:31:31',1),(145,1,'130,1.138,1.',NULL,'Zhao Xiwen-01133546880',1,0,NULL,3,'01126861762','k19B',37,'2020-02-26 10:49:51',1),(146,1,'145,1.149,2.151,2.',NULL,'马欣茹MaXinRu-0172214516',1,0,NULL,3,'01126861762','k19b',63,'2020-02-26 11:16:48',1),(147,1,'29,1.',NULL,'刘玉书-0176673546',1,0,NULL,3,'01126861762','kiz k18b',52,'2020-02-26 11:48:30',1),(148,1,'30,1.50,1.144,1.',NULL,'LIUHANG-0176670730',1,0,NULL,3,'01126861762','Block B 12/16',104,'2020-02-26 12:00:21',6),(149,3,'130,1.',NULL,'dengyihan-0173635727',1,0,NULL,3,'01126861762','saville kajang block A',20,'2020-02-26 12:35:25',6),(150,0,'135,1.',NULL,'孙浩-0172348557',1,0,NULL,3,'01126861762','saville kajang blockA',20,'2020-02-26 20:15:39',6),(151,0,'132,1.',NULL,'wayne-0177937197',1,0,NULL,3,'01126861762','block A',20,'2020-02-27 12:38:16',6),(152,0,'130,1.',NULL,'dengyihan-0173635727',1,0,NULL,3,'01126861762','saville kajang blcok A',20,'2020-02-27 21:48:05',6),(153,3,'141,1.149,4.',NULL,'王家乐-0146607937',1,0,NULL,3,'01126861762','block-A-07-11',61,'2020-02-29 19:00:17',6),(154,0,'137,1.',NULL,'Nancy-+60 1112810318',1,0,NULL,3,'01126861762','Block 19B Kolej Ibu Zain UKM',16,'2020-03-03 12:54:43',1),(155,0,'29,3.137,3.',NULL,'Xu-13357220477',1,0,NULL,3,'01126861762','Kolej ibu zain, 43600 Bangi Selangor, Malaysia',198,'2020-05-10 23:36:16',2);
/*!40000 ALTER TABLE `AppOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AppUser`
--

DROP TABLE IF EXISTS `AppUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AppUser` (
  `UID` int(11) NOT NULL AUTO_INCREMENT,
  `PushID` varchar(100) DEFAULT NULL COMMENT 'Registration ID of MobPush',
  `Token` char(50) DEFAULT NULL,
  `Phone` char(50) DEFAULT NULL,
  `Lang` char(10) NOT NULL DEFAULT 'EN',
  `UserName` varchar(30) DEFAULT NULL,
  `Des` varchar(100) DEFAULT NULL,
  `Gender` int(11) DEFAULT '1',
  PRIMARY KEY (`UID`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AppUser`
--

LOCK TABLES `AppUser` WRITE;
/*!40000 ALTER TABLE `AppUser` DISABLE KEYS */;
INSERT INTO `AppUser` VALUES (2,'c4738b960efbbcb81198e814','jvk9uhbsglq1vlaap01g7tqas0nkud','0172388926','EN','JTalk官方','推陈出新',2),(1,'7b4a03311ac497c54cfd6ac5','nax8egerxpattks9yexqumgtyyc0bw','172388926','ZH','Andy','37℃',2),(5,'0','mej0ei81mummb6twhhysx92d7boe65','172378295','ZH',NULL,NULL,1),(6,'ae3c7e9388acb1a74dabd639','zsftcsgh29bywku1ijij2ckszmonog','183533095','EN','Baraa','It is not over, until I win.',2),(7,'0','92qpnwkvmvw0vc7mr28k1jt5qs62nm','194409731','ZH',NULL,NULL,1),(8,'0','hblinm9l9lxbrtb5e16frfh4l4k97r','1126631785','EN',NULL,NULL,1),(9,'0','k90zbf911754ly7ytcarqnved3esse','122022523','ZH',NULL,NULL,1),(10,'0','adpf5io492w05r6hmmftvnhfjqi52c','122021649','ZH',NULL,NULL,1),(11,'0','uaub5dbxekjks1eto81r215nwtgqdj','1128727872','ZH',NULL,NULL,1),(12,'0','n373mpto1os9ijuamr5ll998bjlwcz','176657749','ZH',NULL,NULL,1),(13,'0','ojt878lncr6iexyt9dlv6gmtp1sv2m','182897182','ZH',NULL,NULL,1),(14,'0','yruqg0c6wlahfoaca2im9iy2743bnt','1164518949','ZH',NULL,NULL,1),(15,'0','lixud26i025ytbns4rm9j18d4hm0t5','1137900362','ZH',NULL,NULL,1),(16,'0','kvvnd6g5q2g366wfi96srjay5hbdoz','1116317293','ZH',NULL,NULL,1),(17,'0','emkakxqadpusdosfy8wpirg4e2ft4b','182328209','EN',NULL,NULL,1),(18,'0','6w6xea56asggfjqk6q0s7jjhqjq50p','1164536240','ZH',NULL,NULL,1),(19,'0','jljbew9gfxupxxm2jwmxfblsw37f3v','1164532625','ZH',NULL,NULL,1),(20,'0','oapht1i54ihmdxl8vk9axpbo9tje4f','1164565913','ZH',NULL,NULL,1),(21,'0','1gt7bhdespkt583nmobe5ui1p9t0kp','183655924','ZH',NULL,NULL,1),(22,'0','nla9qu2qqabndvy5py47n8jeo97sj7','183256713','ZH',NULL,NULL,1),(23,'0','gftd9gn0n7vfnax33ws9ovieq6ljda','122022531','EN',NULL,NULL,1),(24,'4b7fe9fb5e83146e0a3c64bd','2oh76psnfohzumnzezjbx6in5gbbcu','1161282099','ZH','冰冰侠客','',2),(25,'0','ik7ofs93kb3xyrk5f0muhl845pla6o','1164568094','ZH',NULL,NULL,1),(26,'0','6l4vvjo29x9o535obdydwwavetqtag','1151691877','ZH',NULL,NULL,1),(27,'0','whdktd0rywp5zmhdorzlff9ltcp82n','128570925','ZH',NULL,NULL,1),(28,'bc4abf0c51b3926b4bd081a2','m4hau3ztkv9v3qvnqhrosls79g5tsy','172377589','ZH','Wenqi','',2),(29,'0','4ycbsn4saudu93h7fy9zmx1s84tvyp','122018406','ZH',NULL,NULL,1),(30,'0','zuxejaueluyo07defynrlz6g289ctw','1164556403','ZH',NULL,NULL,1),(31,'0','b4blp5yc56ezu47j7pvcj49nmg0l15','1137067469','ZH',NULL,NULL,1),(32,'0','dcst7e6qmtcn9193y8yztd4rnqwe2l','187778566','EN',NULL,NULL,1),(33,'0','6l40kx5pdgtic2f7yzf17l7y4z7ld5','1121598409','EN',NULL,NULL,1),(34,'0','3jdozdwthwhjws3wpt91ec51eia4xn','122017139','ZH',NULL,NULL,1),(35,'0','h477v1e8szbclomlnhyjinvre98ukl','1137113877','ZH',NULL,NULL,1),(36,'0','vjq2nn687tadtcw3wl6w6arohd9fo2','122016519','ZH',NULL,NULL,1),(37,'58d13b65d36bdb46a9fee0a9','7cvcerw6f2bhfkqkf6b0ziby2mgztr','1123504023','ZH','缤雪的雨季','',2),(38,'22bf3ea28aa5d718bfeda60e','933340bovh3djr4v9lpdajhnp2dn22','173242966','ZH',NULL,NULL,1),(39,'7e7ad6c22cf75f17a2ff4e67','uuk8sqgwn83d82rq0rp0pk1g41cm3g','1136681281','ZH','Ahy！','',1),(40,'','5iq7nnnimju9jt81zm03anxrhmfqfs','1111821886','ZH',NULL,NULL,1),(3,'c4738b960efbbcb81198e814sss','dsdasdsafasfasfasf','0172388928','ZH','XPY','hehe',2);
/*!40000 ALTER TABLE `AppUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Blacklist`
--

DROP TABLE IF EXISTS `Blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Blacklist` (
  `phone` varchar(50) DEFAULT NULL,
  `client` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Blacklist`
--

LOCK TABLES `Blacklist` WRITE;
/*!40000 ALTER TABLE `Blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `Blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Eticket`
--

DROP TABLE IF EXISTS `Eticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Eticket` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CreatedDate` datetime DEFAULT NULL,
  `Payment` varchar(20) DEFAULT NULL,
  `PayToken` varchar(50) DEFAULT NULL,
  `Username` varchar(20) DEFAULT NULL,
  `Contact` varchar(20) DEFAULT NULL,
  `EType` varchar(50) DEFAULT NULL,
  `Status` tinyint(4) DEFAULT NULL,
  `client` varchar(20) DEFAULT NULL,
  `EventID` int(11) DEFAULT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Eticket`
--

LOCK TABLES `Eticket` WRITE;
/*!40000 ALTER TABLE `Eticket` DISABLE KEYS */;
INSERT INTO `Eticket` VALUES (1,'2019-08-09 13:07:54','1','123456','Andy','0172388926','9：30 VIP场',1,'web',1);
/*!40000 ALTER TABLE `Eticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Events`
--

DROP TABLE IF EXISTS `Events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Events` (
  `EID` int(11) NOT NULL AUTO_INCREMENT,
  `ZH_Name` varchar(50) DEFAULT NULL,
  `EN_Name` varchar(50) DEFAULT NULL,
  `ZH_Detail` varchar(500) DEFAULT NULL,
  `EN_Detail` varchar(500) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `Location` varchar(50) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Contact` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`EID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Events`
--

LOCK TABLES `Events` WRITE;
/*!40000 ALTER TABLE `Events` DISABLE KEYS */;
INSERT INTO `Events` VALUES (1,'测试活动','TestActivity','爱情在很多人心中都是那么美好的一件事，很多人都渴望拥有美好爱情，可是有时候看到恩爱夫妻最终婚姻破碎，又难免感到伤心难过。文章和马伊琍公开了离婚的消息，引起很多人的热议，两人的情感一波三折，最终的结局似乎冥冥之中已经注定。曾经两人都在节目中谈过自己对于婚姻和爱情的看法，两人的回答大不相同，令人唏嘘。 ','......',200,'北京市 | 国瑞购物中心LG层@北京东城区崇文门外大街18号','2019-08-00','2019-08-06','09:30开场@10:30夜场@12:45午夜场','13357220478');
/*!40000 ALTER TABLE `Events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Express`
--

DROP TABLE IF EXISTS `Express`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Express` (
  `Name` char(50) NOT NULL,
  `Account` char(50) DEFAULT NULL,
  `Phone` char(20) DEFAULT NULL,
  `KEY` char(100) DEFAULT NULL,
  `Action` char(10) DEFAULT NULL,
  `Token` char(50) DEFAULT NULL,
  `ShopID` int(11) DEFAULT '0',
  PRIMARY KEY (`Name`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Express`
--

LOCK TABLES `Express` WRITE;
/*!40000 ALTER TABLE `Express` DISABLE KEYS */;
INSERT INTO `Express` VALUES ('Andy','WZX','0173837324','junrt0w1br94u5ddvwxjig43is3w6kni','123654','WZXWZXWZX',1),('JITU','Admin2','01126861762','x6nhyinrumjuidtrom9f7138al9iz2i2','123456','jitu2020',3),('Omar','Omar','0166180630','ipywxzpsu4bgwhkkg24qpc9bqdcj4m00','9565','UKM2019',0),('Heng','erihengz','0174015622','nof8d1gjg828hjucxm3uzh27icxoblc9','1234','a0rs25',0),('machengxiang','ga03809','01128977122','ywytlxc2mh5pmos24t7vhejj9bcl62a6','123456','xiang03809',1);
/*!40000 ALTER TABLE `Express` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Goods`
--

DROP TABLE IF EXISTS `Goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Goods` (
  `GID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ShopID` int(11) DEFAULT NULL,
  `Price` double DEFAULT '1',
  `ZH_Name` varchar(50) DEFAULT NULL,
  `ZH_Size` varchar(30) DEFAULT NULL,
  `ZH_info` varchar(500) DEFAULT NULL,
  `ZH_Class` varchar(50) DEFAULT NULL,
  `EN_Name` varchar(50) DEFAULT NULL,
  `EN_Size` varchar(50) DEFAULT NULL,
  `EN_info` varchar(550) DEFAULT NULL,
  `EN_Class` varchar(50) DEFAULT NULL,
  `img` varchar(50) DEFAULT NULL,
  `halal` int(11) DEFAULT '0',
  `sold` int(11) DEFAULT '0',
  PRIMARY KEY (`GID`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=gbk COMMENT='商品数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Goods`
--

LOCK TABLES `Goods` WRITE;
/*!40000 ALTER TABLE `Goods` DISABLE KEYS */;
INSERT INTO `Goods` VALUES (1,1,1.5,'青苹果','一个','青苹果富含：碳水化合物、苹果酸、柠檬酸、胡萝卜素等。=口感会比别的苹果酸一些，建议榨汁食用，非常健康==多食用有减肥作用，肥胖者适当多吃青苹果，可减少对其他食物的摄入量，达到减肥效果 ! ==最后分享一个自制苹果面膜方法：苹果去皮，捣烂如泥，干性皮肤加适量鲜牛奶或植物油，油性皮肤加蛋清，搅拌均匀敷面，20分钟后用清水洗净，不仅可除皮肤暗疮、雀斑、黑斑，而且使人皮肤细嫩，柔滑而白皙。','苹果','Green_Apple','One','All apples have health benefits, but the thing that makes green apples special is that they have a high nutritional density packed with minerals, vitamins, proteins, and fiber. They help prevent digestive problems, help regulate blood glucose and good cholesterol.==Quantity:_1pc','Apple','_green_apple',0,68),(2,1,1.5,'橙子','一个','记得小时候橙子，橘子_傻傻分不清楚。==橙子也是一个营养贼鸡儿丰富的好东西，味道也是棒棒哒，还能健脾、醒酒==下面来一点花里胡哨吃橙子方法==橙皮红茶：把脐橙皮去掉白色的瓤，在泡红茶时适量放入，再放入少许糖、桂皮、丁香，这样泡出来的红茶，很好喝哦==果酱：一斤橙子剥皮切块，一斤冰糖，放锅内和姜一起煎熬。脐橙水分多，要熬一个小时以上，适当放一些去掉白色部分的橙子皮，等果酱熬黏稠以后，就可以放进玻璃盒子储存起来吃了。','橘','Citrus_Sinensis(Small)','One','The orange fruit is an important agricultural product, used for both the juicy fruit pulp and the aromatic peel (rind). Orange blossoms (the flowers) are used in several different ways, as are the leaves and wood of the tree.==Quantity:_1pc','Orange','_ChengZi',0,20),(3,1,2,'红苹果','一个','苹果被评为世界公认健康水果之一，更有话说\"An_apple_a_day_keeps_the_doctor_away\"_==如果说其他苹果能让你看起来更美丽，那红苹果是能让你的身体更加稳定、健康，给你的身体内部提供充足的能量==所以请收下这颗能量胶囊 ！~','苹果','Red_Apple','One','\"An_apple_a_day_keeps_the_doctor_away\"==Quantity:_1pc','Apple','_red_apple',0,51),(4,1,4,'菠萝蜜','一盒','菠萝蜜来啦','其他','Jackfruit','One box','In Indonesia and Malaysia, jackfruit is called nangka. The ripe fruit is usually sliced and mixed with shaved ice as a sweet concoction dessert such as es campur and es teler. The ripe fruit might be dried and fried as kripik nangka, or jackfruit cracker. ==Quantity:_1_box','Fruit','_blm',0,30),(5,1,14,'橘子','1千克','哇，这可是一个浑身都是宝贝的水果==记得小时候，每次回到家后奶奶都会把存着的橘子皮摆在客厅房间顿时充斥着橘子香~_橘子皮是除燥，清新空气的神器 ！==此外橘子对肺部、肝部和胃是非常有好处的==所以和小伙伴们多吃点橘子吧 ！','橘','Orange','1 Kilogram','The orange is a hybrid between pomelo (Citrus maxima) and mandarin (Citrus reticulata). The chloroplast genome, and therefore the maternal line, is that of pomelo.The sweet orange has had its full genome sequenced.==Quantity:_1_kilogram','Orange','_orange',0,11),(6,1,2,'橙子（大）','一个','记得小时候橙子，橘子_傻傻分不清楚。==橙子也是一个营养贼鸡儿丰富的好东西，味道也是棒棒哒，还能健脾、醒酒==下面来一点花里胡哨吃橙子方法==橙皮红茶：把脐橙皮去掉白色的瓤，在泡红茶时适量放入，再放入少许糖、桂皮、丁香，这样泡出来的红茶，很好喝哦==果酱：一斤橙子剥皮切块，一斤冰糖，放锅内和姜一起煎熬。脐橙水分多，要熬一个小时以上，适当放一些去掉白色部分的橙子皮，等果酱熬黏稠以后，就可以放进玻璃盒子储存起来吃了。','橘','Citrus_Sinensis(Big)','One','The orange fruit is an important agricultural product, used for both the juicy fruit pulp and the aromatic peel (rind). Orange blossoms (the flowers) are used in several different ways, as are the leaves and wood of the tree.==Quantity:_1pc','Orange','_ChengZi',0,6),(7,1,2.5,'世纪梨','一个','梨是“百果之宗”，因其鲜嫩多汗、酸甜适口，所以又有“天然矿泉水”之称。==梨子的功效有=1.降血压=2.清肺=3.开胃护肝=4.防癌抗癌=5.促进胃肠蠕动','梨','Oriental_Pear','One','It has a high water content and a crisp, grainy texture. They are commonly served raw and peeled.=Oriental_Pear tends to be quite large and fragrant.==Quantity:_1pc','Pear','_pear',0,146),(8,1,2,'优质鸭梨','一个','优秀的鸭梨~','梨','Good_Pear','One','It has a high water content and a crisp, grainy texture. They are commonly served raw and peeled.=Oriental_Pear tends to be quite large and fragrant.==Quantity:_1pc','Pear','_green_pear',0,9),(9,1,3,'青皮芒','一个','当你第一次收到此商品时，你应该会被惊到。=会比你想象中芒果的更大的2333==它不仅味道好，还能美容护肤，解渴治头晕==最后提醒一下，饱饭后不可食用芒果，也不能和大蒜等辛辣物质共食，以免引起发黄病。=患有皮肤病者最好少吃','芒果','BIg_Green_Mango','One','Mangoes are juicy stone fruit (drupe) from numerous species of tropical trees belonging to the flowering plant genus Mangifera, cultivated mostly for their edible fruit.==Quantity:_1pc','Mango','_green_mango_big',0,29),(11,1,7,'香蕉(长)','一千克','香蕉是热带水果，含水量高达70%，相信大家对这个水果肯定不陌生的吧！==功效:=1.补充能量=2.保护胃粘膜=3.降血压=4.润肠道=5.有助于睡眠','其他','Banana_Large','1 Kilogram','......','Others','_Banana_large',0,88),(12,1,2,'柠檬','一个','柠檬实在是个好东西，每天早晨空腹一大杯柠檬水，是我一直在用的排毒方法。==这个方法简单实用，既可排毒，又帮助减肥，还有预防感冒的效果呢，但是一定要坚持才有效==吃柠檬不仅瘦身，而且富含维生素C，对保持皮肤张力和弹性十分有效。==得注意的是，再好的食物，摄入时也不能肆无忌惮！_柠檬也不例外，适量食用，日久见成效！','果子','Lemon','One','Lemons are a rich source of vitamin C, providing 64% of the Daily Value in a 100 g serving (table)==It''s_so_good_if_your_drink_a_cup_of_lemon_water_on_the_morning!==QUantity:_1pc','Fruit','_lemon',0,92),(13,1,2.5,'李子','一个','李子又叫“恐龙蛋”，我个人是很喜欢吃这个的，随手来一颗，甘甜清爽~==功效：=1.促进消化=2.清肝利水=3.降压、导泻、镇咳=4.美容养颜=可以“去粉滓黑黯”，“令人面泽”，对汗斑、脸生黑斑等有良效','果子','Plum','One','......','Fruit','_plum',0,241),(15,1,26,'超甜进口提子','一袋','店家最爱的水果！没有之一！==洗一洗不用剥皮就可以吃，简直了！=味道真的是很可以的，本人强烈推荐=热带地区的提子，个大肉饱满，吃得很爽的','果子','Grape','One packet','......','Fruit','_grape',0,60),(16,1,14,'草莓','一盒','水果颜王不接受反驳，味道也是相当的极品。==食用功效：=1、养肝明目=2、补血=3、治疗嗓子=4、润肺生津=5、通便','果子','Strawberry','One box','......','Fruit','_strawberry',0,55),(17,1,3,'奇异果','一个','它也叫猕猴桃，人称“维C之王”==功效：=1、美容养颜、减肥=2、排毒清肠=3、预防抑郁症','果子','Kiwi','Two','......','Fruit','_kiwi',0,32),(18,0,4,'杨桃','一盒','杨桃是一种具有非常高营养价值的热带水果=洗净后直接吃，口感那是相当的好，切成片长得也很好看==功效：=1、降低血脂、胆固醇=2、生津止渴，利小便=3、促进食物消化=4、清热利咽，可消除咽喉炎症及口腔溃疡','果子','Carambola','Onebox','......','Fruit','_carambola',0,1),(19,1,10,'莲雾(水翁)','一包','1、莲雾可以作为清热解毒的一剂良药，对抑制咳嗽、哮喘等疾病起到不小的作用。==2、莲雾被人们视为消暑解渴的佳果，莲雾带有特殊的类似于苹果的香味，是天然的解热剂。=炎热的夏天正是吃莲雾的好季节，莲雾因为含有许多水分，有润肺凉血、消炎止咳、解热、利尿、宁心安神的作用。==3、经常参加酒席应酬的朋友，可以在餐桌上准备莲雾沙拉，一来可以作为水果甜点享用；二来莲雾具有解酒的功效，可以帮助醒酒醒脑。','果子','Wax_apple','One packet','......','Fruit','_waxapple',0,8),(21,1,4,'哈密瓜块儿','一盒','哈密瓜是一种热带水果，在天气炎热的季节，食用哈密瓜能起到解渴的作用，还能美容，是不错的美容食物。==功效:=1、利尿止渴：=2、缓解烦热、解暑=3、治疗贫血','瓜果','Cantaloupe in box','One box','......','Melon','_cantaloupe',0,31),(22,1,7,'西瓜','四分之一','此等夏日解暑神物何人不知，何人不晓？==又大又甜的热带西瓜=勺子舀着吃、=切片分着吃、=切块儿戳着吃==西瓜还是天然的美容圣果。可滋润面部皮肤、防晒、增白。==不过建议一次性不要吃太多，吃多了可能会拉肚子...','瓜果','Watermelon','1/4','......','Melon','_wtaermelon',0,78),(23,1,4,'菠萝块儿','一盒','菠萝是含水量、高热量低的水果，适合减肥期食用。==功效:=1.消除水肿=2.减肥=3.助消化，促进食欲=4.去油腻，清理肠胃=5.美容=6.消除感冒','瓜果','Pineapple_1/2','Onebox','......','Melon','_pineapple',0,25),(24,1,5,'小香蕉','一串儿','香蕉是热带水果，含水量高达70%，相信大家对这个水果肯定不陌生的吧！==功效:=1.补充能量=2.保护胃粘膜=3.降血压=4.润肠道=5.有助于睡眠','其他','Banana','A bunch','......','Others','_Banana',0,77),(26,1,8,'龙宫果','一千克','也叫杜古','其他','Duku langsat','1 Kilogram','......','Fruit','_lgg',0,16),(27,0,10,'龙眼','一千克','桂圆嘛','其他','Longan','1 Kilogram','......','Fruit','_ly',0,10),(28,1,26,'进口超甜葡萄','一袋','果肉又大又多汁的进口超甜葡萄来了==葡萄含有铁质=可保护脑神经、强化免疫、改善晕眩身体无力等状况。','果子','Vitis','One packet','Grape contains flavonoids, which can have antioxidant effects, lower the levels of low density lipoproteins (LDLs, or “bad cholesterol”), relax blood vessels, and reduce the risk of coronary heart disease. The antioxidants in grape might help to prevent heart disease and have other potentially beneficial effects','Fruit','_putao',0,24),(29,3,50,'招牌大盘鸡','3人份','适合2-3人','热菜','Special_Hot_Chicken','Middle','Suit for 2-3 person','Hot Meal','105',0,0),(30,3,60,'辣子鸡','5人份','适合4－5人','热菜','Spicy_Chicken','Big set','Suit for 4-5 person','Hot Meal','103',1,2),(31,2,3.5,'开心果','一包','要开心就吃开心果','零食','Pistachios','One packet','Eating pistachios always make you happy！','Snacks','_pistachios',1,0),(45,0,4,'杏仁','一包','杏仁的功效与作用==1.润肺==2.降低胆固醇==3.促进皮肤血液循环==4.抗氧化==5.减肥','零食','Honey Almond','One packet','mua','Snacks','_ha',1,0),(46,2,8,'KISSES','一袋','全世界很多人都喜欢吃美国好时公司(Hershey)生产的巧克力。他们的产品出口90多个国家===Kisses好时-----代表的爱（あいしてる）==特浓纯奶巧克力　 代表　浓烈的爱==曲奇奶香白巧克力　 代表　纯真的爱==杏仁巧克力　代表　 深厚的爱\r\n==1颗　KISSES　代表　抠门\r\n==2颗　KISSES　代表　你侬我侬\r\n==3颗　KISSES　代表　我爱你\r\n==11颗　 KISSES　代表　一心一意\r\n==12颗　 KISSES　代表　心心相印\r\n==13颗　 KISSES　代表　暗恋\r\n==24颗　 KISSES　代表　思念\r\n==36颗　 KISSES　代表　我心属于你\r\n==57颗　 KISSES　代表　吾爱吾妻\r\n==77颗　 KISSES　代表　有缘相聚\r\n==88颗　 KISSES　代表　我心弥补\r\n==99颗　 KISSES　代表　长相守\r\n==101颗　KISSES　代表　求婚\r\n==111颗　KISSES　代表　无尽的爱\r\n==365颗　KISSES　代表　天天想你\r\n==999颗　KISSES　代表　天长地久','零食','KISSES (Black)','One packet','muamua','Snacks','_kisses',1,0),(47,2,8,'KISSES','一袋','全世界很多人都喜欢吃美国好时公司(Hershey)生产的巧克力。他们的产品出口90多个国家===Kisses好时-----代表的爱（あいしてる）==特浓纯奶巧克力　 代表　浓烈的爱==曲奇奶香白巧克力　 代表　纯真的爱==杏仁巧克力　代表　 深厚的爱\r\n==1颗　KISSES　代表　抠门\r\n==2颗　KISSES　代表　你侬我侬\r\n==3颗　KISSES　代表　我爱你\r\n==11颗　 KISSES　代表　一心一意\r\n==12颗　 KISSES　代表　心心相印\r\n==13颗　 KISSES　代表　暗恋\r\n==24颗　 KISSES　代表　思念\r\n==36颗　 KISSES　代表　我心属于你\r\n==57颗　 KISSES　代表　吾爱吾妻\r\n==77颗　 KISSES　代表　有缘相聚\r\n==88颗　 KISSES　代表　我心弥补\r\n==99颗　 KISSES　代表　长相守\r\n==101颗　KISSES　代表　求婚\r\n==111颗　KISSES　代表　无尽的爱\r\n==365颗　KISSES　代表　天天想你\r\n==999颗　KISSES　代表　天长地久','零食','KISSES (White)','One packet','muamuamua','Snacks','_kissesw',1,0),(48,2,5.5,'(大包装) MISTER POTATO','一大包','一包美味的薯片给你的一天带来好的心情','零食','Big MISTER POTATO R1','BIG','Delicious~','Snacks','_MISTERR',1,0),(50,3,30,'土豆炒肉丝(牛肉)','1份','','热菜','Beef_with_Patato',NULL,'......','Hot Meal','107',1,13),(67,2,4,'(中包装) MISTER POTATO','一大包','一包美味的薯片给你的一天带来好的心情','零食','Middle MISTER POTATO B2','Regular','Delicious~','Snacks','_MISTERB',1,0),(68,2,2,'Hot Cup (海鲜)','小杯','一款味道不错方便携带的方便面','方便面','HOT CUP Seafood','One cup','Instand noodles','Noodles','_hotcupz',1,0),(69,2,2,'Hot Cup 番茄','小杯','一款味道不错方便携带的方便面','方便面','HOT CUP Tomato','One cup','Instand noodles','Noodles','_hotcupl',1,0),(70,2,2.5,'瓜子','一包','寝室休闲、待客神器！','零食','Melon seed','One packet','Delicious~','Snacks','_guazi',1,0),(71,2,22,'火鸡面 聚餐版','一大包','韩国特辣火鸡面，挑战一下你自己吧','方便面','SAMYANG 1','Whole packet','Instand noodles','Noodles','_hjmz',1,0),(72,2,22,'火鸡面 聚餐版','一大包','韩国特辣火鸡面，挑战一下你自己吧','方便面','SAMYANG 2','Whole packet','Instand noodles','Noodles','_hjmn',1,0),(73,2,18,'辛拉面 聚会版','一大包','自从1986年10月开发以来，一直受到全国民青睐的辛拉面，一上市就吸引住了众多消费者，如今也还在受到全民的喜爱。','方便面','Sinramyeon','Whole packet','Instand noodles','Noodles','_xlm',1,0),(74,2,1.5,'Q劲豆干','一包','香辣、五香等口味的中国豆干零零嘴','零食','Dried tofu','1pc','It is halal~','Snacks','_dg',1,0),(75,2,1.5,'拉丝素肉','一包','香辣、五香等口味的中国零零嘴','零食','Vegetarian meat','1pc','It is halal~','Snacks','_sr',1,0),(76,2,1,'糯米小麻花','一包','糯米小麻花，分为麻辣、五香口味','零食','Glutinous rice twist','1pc','It is halal~','Snacks','_xmh',1,0),(77,2,3.5,'可乐 (大瓶)','大瓶','可口可乐','饮品','Coca-Cola','BIG','Coca-Cola~~','Drink','_kl',0,0),(78,2,6.5,'Vinda 便携版','一条','暖男必备，软妹刚需','生活用品','Vinda','One','~~~','Life','_vindat',0,0),(79,2,12.5,'JACOBS饼干(原味)','750G/桶','此乃居家旅行，朋友聚会必备零食，早餐有它配牛奶非常适合哦','零食','JACOBS crackers','750G','~~~','Snacks','_jacobs_original',1,0),(80,2,13,'JACOBS饼干(营养)','750G/桶','这款是原味的升级版，内含高纤维营养成分，很有益健康的哦','零食','JACOBS crackers','750G','~~~','Snacks','_jacobs_fibre',1,0),(81,2,0.5,'怪兽干脆面','25G/包','一小包怪兽干脆面零食，在上课下课前光速解决它！回味无穷','零食','MONSTER Mee','25G','~~~','Snacks','_MAMEE',1,0),(82,2,1,'(小包装) MISTER POTATO','15G/包','一包美味的薯片给你的一天带来好的心情','零食','MISTER POTATO 15G','15G','~~~','Snacks','_MISTER_blue',1,0),(83,2,4.5,'Julie‘s wheat 饼干','200G/袋','早餐饼干','零食','Julie’s wheat crackers','200G','~~~','Snacks','_wheat_pink',1,0),(84,2,4.5,'Julie‘s butter 饼干','200G/袋','早餐饼干','零食','Julie’s butter crackers','200G','~~~','Snacks','_wheat_green',1,0),(85,2,7,'Goody 芒果布丁','6*80G','芒果味的布丁 80G','零食','Goody Pudding','6*80G','~~~','Snacks','_gmp_yellow',1,0),(86,2,12.9,'Goody 布丁 (大)','12*80G','内含三种口味：草莓、芒果、荔枝','零食','Goody Pudding','12*80G','~~~','Snacks','_gmp',1,0),(87,2,12.9,'DairyMilk巧克力','10*150G','可口的巧克力','零食','Dairy Milk','10*150G','~~~','Snacks','_DairyMilk2',1,0),(88,2,9,'DairyMilk 起泡巧克力','1*120G','可口的巧克力','零食','Dairy Milk Bubbly','1*120G','~~~','Snacks','_DairyMilkBubbly',1,0),(89,2,15,'DairyMilk Q版巧克力','40*180G','一包一共有40个Q版巧克力','零食','Dairy Milk40S','40*180G','~~~','Snacks','_DairyMilk1',1,0),(90,2,18.9,'Julie‘s 巧克力蛋卷','700G/桶','一大桶 巧克力蛋卷 让你的每天都是甜甜的','零食','Julie’s Love Letters','700G','~~~','Snacks','_Love_Letters',1,0),(91,2,17.9,'Julie‘s 巧克力饼干','168G','巧克力小吃零食！','零食','Julie’s Dark Chocolate Cookies','168G','~~~','Snacks','_hershey_dark',1,0),(92,2,7.5,'MINI曲奇饼','8*32G','一包曲奇饼','零食','Mini Chips more','8*32G','~~~','Snacks','_Mini',1,0),(93,2,7.5,'迷你奥利奥饼干','8*32G','奥利奥饼干来也','零食','MINI Oreo','8*28G','~~~','Snacks','_Oreo',1,0),(99,2,2,'Hot Cup 咖喱','小杯','一款味道不错方便携带的方便面','方便面','HOT CUP Kari','One cup','Instand noodles','Noodles','_hotcupk',1,0),(106,2,2.5,'雀巢咖啡','小瓶 225ml','此乃修仙圣器，考前救命神器','饮品','NestCafe small','225ml','','Drink','_nescafe',1,0),(107,2,4,'雀巢咖啡 (袋)','5袋*19G','此乃修仙圣器，考前救命神器','饮品','NestCafe','5*19G','','Drink','_nescafe_original',1,0),(108,2,12.5,'焦糖雀巢','5袋*25G','此乃修仙圣器，考前救命神器','饮品','NestCafe Caramel','5*25G','','Drink','_nescafe_caramel',1,0),(109,2,7.5,'Hershey 巧克力','6盒*200ml','修仙圣器，考前救命神器','饮品','Hershey chocolate','6*200ml','','Drink','_hershey_chocolate',1,0),(110,2,7,'Hershey 牛奶夹心','6盒*200ml','好时巧克力公司出品的饮品','饮品','Hershey Cookie N','6*200ml','','Drink','_hershey_cookies',1,0),(111,2,7,'Hershey 摩卡','6盒*200ml','好时巧克力公司出品的饮品','饮品','Hershey Mocha','6*200ml','','Drink','_hershey_mocha',1,0),(112,2,18.5,'Milo 奶茶','1kg','马来西亚知名奶茶','饮品','Milo','1kg','','Drink','_milo_1kg',1,0),(113,2,14,'Milo 奶茶','18*33G','马来西亚知名奶茶','饮品','Milo','18*33G','','Drink','_milo_33g',1,0),(114,2,8.5,'Milo 奶茶','400G','马来西亚知名奶茶','饮品','Milo','400G','','Drink','_milo_400g',1,0),(115,0,22,'乡村原鸡','L 大只','乡村基，放心基','鸡肉','Village chicken','L Size','','Chicken','chiken',1,0),(116,0,20,'乡村原鸡','M 中份','乡村基，放心基','鸡肉','Village chicken','M Size','','Chicken','chiken',1,0),(117,0,18,'乡村原鸡','S 小份','乡村基，放心基','鸡肉','Village chicken','S Size','','Chicken','chiken',1,0),(118,3,38,'辣子鸡','3人份','适合2－3人份','热菜','Spicy_Chicken','Regular','Suit for 2-3 person','Hot meal','103',1,8),(119,3,60,'招牌大盘鸡','5人份','适合4－5人','热菜','Special_Hot_Chicken','Large','Suit for 4-5 person','Hot Meal','105',1,1),(120,3,35,'青椒牛柳','1份',NULL,'热菜','Spicy_Beef','Regular',NULL,'Hot Meal','120',1,8),(121,3,35,'红烧鱼','1份',NULL,'热菜','Tasty_Fish','Regular',NULL,'Hot Meal','104',1,16),(122,3,45,'水煮肉片','1份',NULL,'热菜','SiChuan_Boild_Fish','Regular',NULL,'Hot Meal','113',1,23),(123,3,30,'农家小炒肉','1份',NULL,'热菜','SpicyMeal','Regular',NULL,'Hot Meal','111',1,17),(124,3,25,'麻婆豆腐','1份',NULL,'热菜','SpicyToufu','Regular',NULL,'Hot Meal','114',1,26),(125,3,18,'耗油生菜','1份',NULL,'热菜','Veg','Regular',NULL,'Hot Meal','122',1,4),(126,3,18,'酸辣土豆丝','1份',NULL,'热菜','Patato','Regular',NULL,'Hot Meal','116',1,4),(127,3,27,'干锅土豆片','1份',NULL,'热菜','FriedPatato','Regular',NULL,'Hot Meal','110',1,9),(128,3,20,'山药木耳','1份',NULL,'热菜','Veg2','Regular',NULL,'Hot Meal','108',1,9),(129,3,14,'麻辣海带丝','1份',NULL,'凉菜','SpicyVeg','Regular',NULL,'Extra dish','106',1,9),(130,3,20,'土豆牛肉盖浇饭','1份',NULL,'盖浇饭','Set1','Regular',NULL,'Sets','115',1,9),(131,3,20,'红烧牛肉盖浇饭','1份',NULL,'盖浇饭','Set2','Regular',NULL,'Sets','112',1,9),(132,3,20,'招牌大盘鸡盖浇饭','1份',NULL,'盖浇饭','Set3','Regular',NULL,'Sets','111',1,9),(133,3,20,'辣条鸡排盖浇饭','1份',NULL,'盖浇饭','Set4','Regular',NULL,'Sets','119',1,9),(134,3,20,'西红柿鸡蛋盖浇饭','1份',NULL,'盖浇饭','Set5','Regular',NULL,'Sets','118',1,9),(135,3,20,'孜然牛肉盖浇饭','1份',NULL,'盖浇饭','Set6','Regular',NULL,'Sets','123',1,9),(136,3,40,'麻辣鲜虾盖浇饭','1份',NULL,'盖浇饭','Set7','Regular',NULL,'Sets','117',1,9),(137,3,16,'扬州炒饭','1份',NULL,'盖浇饭','Set8','Regular',NULL,'Sets','109',1,9),(138,3,15,'老干妈的爱','1份',NULL,'盖浇饭','Set9','Regular',NULL,'Sets','112',1,9),(139,3,20,'咖喱牛肉盖浇饭','1份',NULL,'盖浇饭','Set9','Regular',NULL,'Sets','101',1,9),(140,3,73,'一品炒鸡','大份',NULL,'热菜','Fried Chicken','Large',NULL,'Hot Meal','124',1,8),(141,3,53,'重庆烤鱼','大份',NULL,'热菜','Fried Fish','Large',NULL,'Hot Meal','125',1,8),(142,3,33,'口水鸭','1份',NULL,'热菜','Yummy Duck','Regular',NULL,'Hot Meal','126',1,8),(143,3,21,'干锅花菜','1份',NULL,'热菜','Fried Veg','Regular',NULL,'Hot Meal','127',1,8),(144,3,21,'干锅手撕包菜','1份',NULL,'热菜','Fried Veg2','Regular',NULL,'Hot Meal','128',1,8),(145,3,53,'小火锅','1份',NULL,'精品','Hot Pot','Regular',NULL,'Special','130',1,8),(146,3,93,'麻辣小龙虾','大份',NULL,'精品','Fried Shrimp','Large',NULL,'Special','129',1,8),(147,3,45,'水煮鱼','1份',NULL,'精品','Boiled Fish','Regular',NULL,'Hot Meal','131',1,8),(148,3,73,'海鲜香锅','1份',NULL,'精品','Hot Pot Seafood','Large',NULL,'Special','132',1,8),(149,3,2,'米饭','1份',NULL,'主食','Rice','one',NULL,'Main food','133',1,8),(150,3,2,'雪碧','1罐',NULL,'饮料','Sprite','one',NULL,'Beverage','134',1,8),(151,3,2,'可乐','1罐',NULL,'饮料','Coke','one',NULL,'Beverage','135',1,8),(152,3,6,'酸奶','1瓶',NULL,'饮料','Yogurt','one',NULL,'Beverage','136',1,8),(153,3,12,'山楂汁','1瓶',NULL,'饮料','Hawthorn juice','one',NULL,'Beverage','137',1,8),(154,3,14,'牛肉水饺','1份',NULL,'主食','Beef dumplings','one',NULL,'Main food','138',1,8),(155,3,5,'冰红茶','1瓶',NULL,'饮料','Red ice tea','one',NULL,'Beverage','139',1,8),(156,3,16,'凉拌皮蛋','1份',NULL,'凉菜','CN SpecialEgg','Regular',NULL,'Extra dish','140',1,9);
/*!40000 ALTER TABLE `Goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `History1`
--

DROP TABLE IF EXISTS `History1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `History1` (
  `ID` int(11) NOT NULL,
  `data` char(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `destination` char(30) DEFAULT NULL,
  `sender` char(30) DEFAULT NULL,
  `reciver` char(30) DEFAULT NULL,
  `position` char(30) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `type` char(10) DEFAULT NULL,
  `freeTime` char(50) DEFAULT NULL,
  `shop` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `History1`
--

LOCK TABLES `History1` WRITE;
/*!40000 ALTER TABLE `History1` DISABLE KEYS */;
INSERT INTO `History1` VALUES (19,'运费，菠萝蜜一盒*1，大芒果一个*1，橘子1kg*1，猕猴桃一盒*1',0,25,'Kajang鲜果坊','600172917920','6001729179200','KKM，陶佳','2017-12-03 18:15:57',NULL,NULL,NULL),(18,'运费，菠萝蜜一盒*2，袖珍沁甜小菠萝一袋*1',4,17,'Kajang鲜果-坊','600172917920','601161282099','KKM，block3,room109','2017-12-01 09:39:44',NULL,NULL,NULL),(9,'运费，哈密瓜一盒*3，大芒果一个*2，橘子1kg*2，菠萝蜜一盒*2，大菠萝半个*2',4,59,'Kajang鲜果-坊','600172917920','601161253661','KKM，Block9,Room431','2017-11-29 18:02:42',NULL,NULL,NULL),(17,'运费，菠萝蜜一盒*1',4,6,'Kajang鲜果-坊','600172917920','6001128637654','ZABA，BlockB1-No1203','2017-11-30 23:22:45',NULL,NULL,NULL),(10,'运费，袖珍沁甜小菠萝一袋*1',3,11,'Kajang鲜果-坊','600172917920','600172917920','ZABA，Block3-No109','2017-11-29 18:12:25',NULL,NULL,NULL),(15,'运费，菠萝蜜一盒*1，哈密瓜一盒*2，大芒果一个*1，提子1kg*1，猕猴桃一盒*1，梨七个*1',4,41,'Kajang鲜果-坊','600172917920','601128689473','KKM，11block','2017-11-30 10:04:10',NULL,NULL,NULL),(16,'运费，菠萝蜜一盒*3',4,12,'Kajang鲜果-坊','600172917920','60182573909','ZABA，nadayu92','2017-11-30 10:35:10',NULL,NULL,NULL),(13,'运费，橘子1kg*1，杨桃一个*2，大芒果一个*1',4,21,'Kajang鲜果-坊','600172917920','601128068680','ZABA，B1302王一玮','2017-11-29 22:41:54',NULL,NULL,NULL),(14,'运费，橘子1kg*1，新鲜草莓一盒*2，猕猴桃一盒*1，袖珍沁甜小菠萝一袋*1，提子1kg*2，大芒果一个*1，菠萝蜜一盒*2',4,78,'Kajang鲜果-坊','600172917920','601127124463','KKM，Block9Room511马玥','2017-11-29 23:10:00',NULL,NULL,NULL),(11,'运费，哈密瓜一盒*1，袖珍沁甜小菠萝一袋*1',3,15,'Kajang鲜果-坊','600172917920','600172917920','ZABA，Block3-No109-徐瑞迪','2017-11-29 18:22:42',NULL,NULL,NULL),(12,'运费，袖珍沁甜小菠萝一袋*1，哈密瓜一盒*1',4,15,'Kajang鲜果-坊','600172917920','600172917920','KKM，Block3,No.109','2017-11-29 18:25:01',NULL,NULL,NULL),(20,'运费，橘子1kg*1，大芒果一个*2，袖珍沁甜小菠萝一袋*1，猕猴桃一盒*1',4,34,'Kajang鲜果坊','600172917920','601161253661','KKM，Block9,Room431','2017-12-03 21:04:59',NULL,NULL,NULL),(21,'运费，橘子1kg*1',4,13,'Kajang鲜果坊','600172917920','6001729179200','KKM，周文雅','2017-12-04 16:16:23',NULL,NULL,NULL),(22,'运费，杨桃一个*3，哈密瓜一盒*1，猕猴桃一盒*2，橘子1kg*2',3,40,'Kajang鲜果坊','600172917920','600172917920','KKM，Block3,No.109','2017-12-04 16:33:11',NULL,NULL,NULL),(23,'运费，菠萝蜜一盒*1，橘子1kg*1',4,16,'Kajang鲜果坊','600172917920','601128689473','KKM，11block','2017-12-04 19:29:24',NULL,NULL,NULL),(24,'运费，菠萝蜜一盒*4，大菠萝半个*1，大芒果一个*1，袖珍沁甜小菠萝一袋*1',4,32,'Kajang鲜果坊','600172917920','6001128638683','ZABA，BlockBRoom1203','2017-12-04 23:51:52',NULL,NULL,NULL),(25,'运费，菠萝蜜一盒*1，袖珍沁甜小菠萝一袋*1',4,14,'Kajang鲜果坊','600172917920','601161282099','KKM，block3,room109','2017-12-05 00:43:28',NULL,NULL,NULL),(26,'运费，哈密瓜一盒*1，菠萝蜜一盒*1',4,10,'Kajang鲜果坊','600172917920','6001161272385','KKM，Block3,room103,saber','2017-12-05 16:16:14',NULL,NULL,NULL),(27,'运费，菠萝蜜一盒*1，哈密瓜半个*1，西瓜四分之一个*1',4,15,'Kajang鲜果坊','600172917920','6001161272385','KKM，Block3,room103,saber','2017-12-08 12:01:35',NULL,NULL,NULL),(28,'运费，菠萝蜜一盒*1，猕猴桃一盒*1，蓝莓一盒*1，我也不知道叫啥一个*2',4,25,'Kajang鲜果坊','600172917920','601128068680','ZABA，B1302王一玮','2017-12-08 21:01:22',NULL,NULL,NULL),(29,'运费，菠萝蜜一盒*2，橘子1kg*1，袖珍沁甜小菠萝一袋*1，西瓜四分之一*2，我也不知道叫啥一个*1，梨子七个*1',4,45,'Kajang鲜果坊','600172917920','601128689473','KKM，11block','2017-12-08 21:34:39',NULL,NULL,NULL),(30,'运费，菠萝蜜一盒*2，橘子1kg*2，西瓜四分之一*2，鸭梨一个*1',4,36,'Kajang鲜果坊','600172917920','601161253661','KKM，Block9,Room431','2017-12-08 21:37:06',NULL,NULL,NULL),(31,'运费，三个椰子*1，菠萝蜜*3，大芒果*1，五块钱苹果',4,33,'Kajang鲜果坊','600172917920',NULL,'KKM，Block9','2017-12-09 11:10:24',NULL,NULL,NULL),(32,'大芒果，杨桃*2，橘子*1，菠萝蜜*1',4,20,'Kajang鲜果坊','600172917920',NULL,'周文雅','2017-12-09 22:19:53',NULL,NULL,NULL),(33,'运费，菠萝蜜一盒*1',3,6,'Kajang鲜果坊','600172917920','601161282099','KKM，block3,room109','2017-12-09 22:20:48',NULL,NULL,NULL),(34,'香蕉，苹果，橘子，葡萄',4,31,'Kajang鲜果坊','600172917920',NULL,'苏恩特','2017-12-09 22:22:29',NULL,NULL,NULL),(35,'运费，大菠萝半个*1',4,7,'Kajang鲜果坊','600172917920','6001128637654','ZABA，BlockB1-No1203','2017-12-09 23:52:11',NULL,NULL,NULL),(36,'运费，菠萝蜜一盒*1，哈密瓜半个*1，西瓜四分之一*1',3,13,'Kajang鲜果坊','600172917920','6001161272385','KKM，Block3,room103,saber','2017-12-10 18:47:30',NULL,NULL,NULL),(37,'运费，螺狮粉*2，康师傅牛肉面桶装*2，冰红茶*2，亲嘴烧*4',4,70,'中华小卖部','60182573909','601111681510','zaba打我电话','2017-12-12 10:51:09',NULL,NULL,NULL),(38,'运费，椰树*1，老坛酸菜干拌面*1，康师傅方便面袋装*5，乐事薯片*4，何辉凤凰卷*1，娃哈哈AD钙奶*2，双汇王中王400g*1，烤馍片小包装*2，安慕希原味*6，安慕希蓝莓味*1',4,140,'中华小卖部','60182573909','600172917920','KKM，Block3,No.109','2017-12-12 20:29:19',NULL,NULL,NULL),(39,'运费，手工豆皮一包*1，香辣味毛毛鱼一包*1，盐焗鸡精一包*1，牛蛙肉两包*1',4,10,'国产辣味部落','6001139363112','6001128024907','KKM，Block9,Room431,朱博','2017-12-12 21:39:10',NULL,NULL,NULL),(40,'运费，亲嘴烧川香麻辣四包*2，亲嘴烧红烧牛肉四包*2',3,13,'国产辣味部落','6001139363112','60183145799','KKM，Block9,room511,马玥','2017-12-12 23:17:35',NULL,NULL,NULL),(41,'运费，香辣手撕素肉排两包*1，绝辣味毛毛鱼一包*1，黑山羊肉串孜然味三包*1，黑椒手撕素肉排两包*1，盐焗鸡精一包*1',3,15,'国产辣味部落','6001139363112','601128068680','ZABA，B1302王一玮','2017-12-13 01:02:04',NULL,NULL,NULL),(42,'运费，蒙牛原麦牛奶*2，双汇王中王400g*2，康师傅方便面袋装*2',4,50,'中华小卖部','60182573909','60172348557','ZABA，block3,room323,张欢','2017-12-13 01:06:18',NULL,NULL,NULL),(43,'运费，手工豆皮一包*2，黑山羊肉串孜然味三包*2，盐焗鸡精一包*3，牛蛙肉两包*1',4,25,'国产辣味部落','6001139363112','601161253661','KKM，Block9,Room431','2017-12-13 11:47:41',NULL,NULL,NULL),(44,'运费，娃哈哈AD钙奶*1，洽洽瓜子*1，娃哈哈桂圆莲子*1，双汇王中王400g*1，侯氏麻花*1',4,46,'中华小卖部','60182573909','601128689473','KKM，11block','2017-12-13 21:29:47',NULL,NULL,NULL),(45,'运费，康师傅方便面袋装*2，双汇王中王400g*2，蒙牛原麦牛奶*2',4,50,'中华小卖部','60182573909','60172348557','ZABA，block3,room323,张欢','2017-12-15 17:55:56',NULL,NULL,NULL),(46,'运费，西瓜四分之一*1，哈密瓜半个*1，菠萝蜜一盒*1',4,13,'Kajang鲜果坊','600172917920','6001161272385','KKM，Block3,room103,saber','2017-12-15 20:10:06',NULL,NULL,NULL),(47,'运费，菠萝蜜一盒*1，大芒果一个*1，西瓜四分之一*3，鸡蛋果*2',4,23,'Kajang鲜果坊','600172917920','601128689473','KKM，11block','2017-12-16 08:18:18',NULL,NULL,NULL),(48,'运费，菠萝蜜一盒*3，猕猴桃一盒*2，青苹果一个*5',4,27,'Kajang鲜果坊','600172917920','600172917920','KKM，Block3,No.109','2017-12-16 11:55:00',NULL,NULL,NULL),(49,'运费，黑山羊肉串孜然味三包*1，盐焗鸡精一包*1，亲嘴烧川香麻辣四包*1，牛蛙肉两包*1',4,14,'国产辣味部落','6001139363112','600172917920','KKM，Block3,No.109','2017-12-16 13:06:49',NULL,NULL,NULL),(50,'运费，菠萝蜜一盒*1，袖珍沁甜小菠萝一袋*1，红苹果5个*1',4,25,'Kajang鲜果坊','600172917920','601133150046','KKM，KKM,Block9,Room505申鹏琨','2017-12-16 16:25:18',NULL,NULL,NULL),(51,'运费，菠萝蜜一盒*1，杨桃一个*5，猫山王榴莲1kg*2，袖珍沁甜小菠萝一袋*1',4,109,'Kajang鲜果坊','600172917920','6001128637654','ZABA，BlockB1-No1203','2017-12-16 19:23:44',NULL,NULL,NULL),(52,'运费，新鲜草莓一盒*1，猕猴桃一盒*1',4,21,'Kajang鲜果坊','600172917920','6001139909851','ZABA，Block2.roomb1123','2017-12-16 20:01:33',NULL,NULL,NULL),(53,'运费，菠萝蜜一盒*2，猕猴桃一盒*1，新鲜椰子三个*1',4,26,'Kajang鲜果坊','600172917920','600182862766','KKM，KKM九栋519','2017-12-17 12:13:11',NULL,NULL,NULL),(54,'运费，手工豆皮一包*1，绝辣味毛毛鱼一包*1，香辣味毛毛鱼一包*1，盐焗鸡精一包*2，牛蛙肉两包*2',4,17,'国产辣味部落','6001139363112','6001128024907','KKM，Block9,Room431,朱博','2017-12-21 17:15:05',NULL,NULL,NULL),(55,'运费，手工豆皮一包*2，黑山羊肉串孜然味三包*2，盐焗鸡精一包*2，牛蛙肉两包*2，亲嘴烧麦辣鸡汁四包*1',4,28,'国产辣味部落','6001139363112','601161253661','KKM，Block9,Room431','2017-12-21 17:28:45',NULL,NULL,NULL),(56,'运费，菠萝蜜一盒*2，新鲜椰子三个*1，袖珍沁甜小菠萝一袋*1',3,29,'Kajang鲜果坊','600172917920','600182862766','KKM，KKM九栋519','2017-12-27 12:37:30',NULL,NULL,NULL),(57,'运费，菠萝蜜一盒*1，哈密瓜半个*3，杨桃一个*2，新鲜椰子三个*2',3,44,'Kajang鲜果坊','600172917920','600172917920','KKM，Block3,No.109','2018-01-24 14:20:00',NULL,NULL,NULL),(58,'运费，大菠萝半个*4',3,19,'Kajang鲜果坊','600172917920','600172917920','KKM，Block3,No.109','2018-01-28 20:58:25',NULL,NULL,NULL),(59,'运费，菠萝蜜一盒*3，哈密瓜半个*2，杨桃一个*2，大芒果一个*1',4,26,'Kajang鲜果坊','600172917920','600172917920','KKM，Block3,No.109','2018-02-03 14:51:48',NULL,NULL,NULL),(60,'运费,菠萝蜜一盒*3,哈密瓜半个*1,杨桃一个*2',3,3,'Kajiang-华人区','600172917920','60172917920','sadasdasd，0','2018-02-27 23:41:39','wx','',NULL),(61,'运费,菠萝蜜一盒*4',3,3,'Kajiang-华人区','600172917920','60172917920','sadasdasd，0','2018-02-27 23:44:10','wx','',NULL),(62,'运费,菠萝蜜一盒*3,哈密瓜半个*2,杨桃一个*1',3,3,'Kajiang-华人区','600172917920','600172917920','多喝点好好说说，0','2018-02-28 01:50:19','wx','',NULL),(63,'运费,菠萝蜜一盒*1,哈密瓜半个*2,杨桃一个*1',3,3,'Kajiang-华人区','600172917920','600172917920','多喝点好好说说，0','2018-02-28 14:30:47','wx','',NULL),(64,'运费，小面筋*2，绿豆糕三盒*3',1,6,'国产辣味部落','6001139363112','600172917920','FTSM，DMM,Andy,CallmePlease','2018-03-05 12:00:29',NULL,NULL,NULL),(65,'运费，菠萝蜜一盒*2，哈密瓜半个*4',1,25,'Kajang鲜果坊','600172917920','600172917920','ZABA，djdjdjdj','2018-03-15 15:54:35',NULL,NULL,NULL),(66,'Andy&amp;0172917920&amp;Wednesday&amp;FTSM&amp;0:3&amp;1:1&amp;',1,19,NULL,NULL,'0172917920',NULL,'2018-04-07 01:18:31',NULL,NULL,0),(67,'Andy&amp;0172917920&amp;Wednesday&amp;FTSM&amp;0:3&amp;1:1&amp;',1,19,NULL,NULL,'0172917920',NULL,'2018-04-07 01:18:52',NULL,NULL,0);
/*!40000 ALTER TABLE `History1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `History2`
--

DROP TABLE IF EXISTS `History2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `History2` (
  `OrderID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `UserName` varchar(50) DEFAULT NULL,
  `UserPhone` varchar(50) DEFAULT NULL,
  `Contact` char(10) DEFAULT 'Phone',
  `Price` double DEFAULT NULL,
  `ShopID` int(11) DEFAULT NULL,
  `Detail` varchar(32) DEFAULT '???',
  `Status` int(11) DEFAULT '0',
  `Deliver` varchar(32) DEFAULT '0',
  `Data` varchar(200) DEFAULT NULL,
  `Time` datetime DEFAULT NULL,
  `Port` int(11) DEFAULT '0',
  PRIMARY KEY (`OrderID`)
) ENGINE=MyISAM AUTO_INCREMENT=283 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `History2`
--

LOCK TABLES `History2` WRITE;
/*!40000 ALTER TABLE `History2` DISABLE KEYS */;
INSERT INTO `History2` VALUES (93,'谢渝齐林','0182788470','whatsApp',10,1,'Ibu_Zain,Tuesday,7pm-9pm',3,'60183805019','20,哈密瓜,2.','2018-09-24 18:55:07',0),(94,'徐瑞迪','60172388926','Phone',14,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'13357220477','22,C瓜,1.1,青苹果,5.21,哈密瓜块儿,1.12,柠檬,2.','2018-09-24 19:20:51',0),(248,'李可心','01121026439','Wechat',16.5,1,'UKM,IbuZain,k18b',2,'0166180630','4,菠萝蜜,1.11,香蕉一串(长的),1.18,杨桃一盒,1.21,哈密瓜块儿,1.','2019-03-28 22:06:03',2),(87,'wangaobing','01161282099','Phone',5,1,'Villa_Tropika,Sat,10am-12pm',2,'60183805019','1,青苹果,5.','2018-09-21 22:00:05',0),(88,'Loretta','0149152088','whatsApp',33.5,1,'Saville_Kajang,Tuesday,7pm-9pm',3,'60183805019','1,青苹果,6.3,红苹果,3.10,金煌芒_大,3.9,青皮芒_大,1.24,香蕉,2.','2018-09-23 21:14:08',0),(84,'saber','01161272385','whatsApp',6,1,'KKM,Sat,10am-12pm',2,'60183805019','22,C瓜,1.21,哈密瓜块儿,1.','2018-09-21 00:33:33',0),(85,'Andy','13357220477','whatsApp',32.5,1,'Villa_Tropika,Sat,10am-12pm',2,'60183805019','12,柠檬,2.15,提子,1.22,C瓜,1.2,黄苹果,4.10,金煌芒_大,1.','2018-09-21 13:08:08',0),(86,'吴美伟','01111780353','whatsApp',17,1,'Ibu_Zain,Sat,10am-12pm',2,'60183805019','22,C瓜,1.17,奇异果,1.10,金煌芒_大,2.','2018-09-21 18:18:14',0),(89,'罗晓','01128602611','Phone',47,1,'Villa_Tropika,Tuesday,7pm-9pm',3,'60183805019','10,金煌芒_大,2.5,橘子,2.21,哈密瓜块儿,1.20,哈密瓜,2.22,C瓜,1.','2018-09-23 21:14:51',0),(90,'梁漪辰','60173007001','whatsApp',13,1,'Ibu_Zain,Tuesday,7pm-9pm,19A',3,'60183805019','1,青苹果,1.17,奇异果,1.21,哈密瓜块儿,1.24,香蕉,1.','2018-09-23 22:46:50',0),(91,'张锦妍','0176536738','whatsApp',2,1,'Ibu_Zain,Tuesday,7pm-9pm',3,'60183805019','21,哈密瓜块儿,1.','2018-09-24 12:55:36',0),(92,'saber','01161272385','whatsApp',13,1,'KKM,Tuesday,7pm-9pm',3,'60183805019','24,香蕉,1.22,C瓜,1.20,哈密瓜,1.','2018-09-24 14:54:18',0),(95,'张文祺','0172377589','whatsApp',11,1,'ZABA,Tuesday,7pm-9pm',3,'60183805019','23,菠萝,1.24,香蕉,1.22,C瓜,1.','2018-09-24 20:10:05',0),(96,'特仑苏','01162039499','Phone',3,1,'Villa_Tropika,Tuesday,7pm-9pm',3,'60183805019','1,Green_Apple,3.','2018-09-24 20:11:19',0),(97,'Ma','0183805019','Phone',22,1,'Ibu_Zain,Tuesday,7pm-9pm',3,'60183805019','20,哈密瓜,1.10,金煌芒_大,2.17,奇异果,1.24,香蕉,1.','2018-09-24 20:28:19',0),(98,'Baraa','0183533095','whatsApp',9,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'60183805019','10,Big_Yellow_Mango,3.2,Yellow_Apple,2.','2018-09-25 04:40:36',0),(103,'陶佳','01133152839','whatsApp',43,1,'Villa_Tropika,Thursday,7pm-9pm',2,'60183805019','3,红苹果,3.9,青皮芒_大,3.17,奇异果,3.20,哈密瓜,1.26,龙宫果,1','2018-09-26 00:25:37',0),(101,'梁馨蕊','01112809956','Phone',15,1,'Ibu_Zain,Thursday,7pm-9pm',2,'60183805019','1,青苹果,2.2,黄苹果,1.6,橙子,1.12,柠檬,2.20,哈密瓜,1.13,李子,1.','2018-09-25 22:59:52',0),(104,'Saddam','01121881849','whatsApp',14,1,'Villa_Tropika,Thursday,1pm-3pm',2,'60183805019','1,Green_Apple,10.22,Watermelon,1.','2018-09-26 00:41:06',0),(108,'李晗瑀','0182571801','whatsApp',16.5,1,'Omar,Thursday,4pm-6pm',2,'60183805019','26,龙宫果,1.25,菠萝蜜,1.22,C瓜,1.9,青皮芒_大,1.','2018-09-26 17:59:14',0),(107,'CHUAMEIKEI','0172377589','whatsApp',75,1,'ZABA,Tuesday,7pm-9pm',2,'60183805019','13,李子,3.24,香蕉,8.20,哈密瓜,1.21,哈密瓜块儿,5.16,草莓,1.19,莲雾,1.17,奇异果,2.','2018-09-26 13:11:46',0),(109,'TANGRUIJUN','01126362986','whatsApp',9,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'60183805019','26,龙宫果,1.23,菠萝,2.','2018-09-26 18:14:30',0),(110,'王子月','01121335799','Phone',16.5,1,'Ibu_Zain,Thursday,4pm-6pm',2,'60183805019','12,柠檬,1.22,C瓜,1.25,菠萝蜜,1.23,菠萝,1.20,哈密瓜,1.','2018-09-26 18:18:15',0),(111,'白天晴','0172351098','whatsApp',15,1,'Ibu_Zain,Thursday,4pm-6pm',2,'60183805019','22,C瓜,1.25,菠萝蜜,2.24,香蕉,1.','2018-09-26 18:46:00',0),(112,'HuRui','0176276005','whatsApp',27,1,'seri wirani8 是个排屋小区 我住52A ，seri ',2,'60183805019','1,青苹果,3.6,橙子,3.9,青皮芒_大,1.17,奇异果,1.21,哈密瓜块儿,1.22,C瓜,1.26,龙宫果,1.23,菠萝,1.','2018-09-26 18:56:56',0),(113,'徐瑞迪','60172388926','whatsApp',14.5,1,'Villa_Tropika,Thursday,4pm-6pm',2,'60183805019','25,菠萝蜜,2.23,菠萝,1.21,哈密瓜块儿,3.','2018-09-26 19:22:09',0),(114,'李科沩','01112859923','whatsApp',33,1,'Ibu_Zain,Thursday,4pm-6pm',2,'60183805019','6,橙子,4.13,李子,8.26,龙宫果,2.25,菠萝蜜,1.23,菠萝,1.21,哈密瓜块儿,1.','2018-09-26 20:29:36',0),(115,'老段','01112405616','Phone',22,1,'Villa_Tropika,Thursday,4pm-6pm',2,'60183805019','9,青皮芒_大,2.22,C瓜,4.21,哈密瓜块儿,1.','2018-09-26 20:54:30',0),(116,'周文雅','0133075132','whatsApp',35.5,1,'Villa_Tropika,Thursday,4pm-6pm',2,'60183805019','3,红苹果,2.9,青皮芒_大,2.17,奇异果,2.21,哈密瓜块儿,1.24,香蕉,1.25,菠萝蜜,1.27,龙眼,1.','2018-09-26 20:59:36',0),(117,'zhangkaixuan','01136903150','Phone',11.5,1,'Ibu_Zain,Tuesday 19A,7pm-9pm',2,'60183805019','21,哈密瓜块儿,1.22,C瓜,1.23,菠萝,1.24,香蕉,1.','2018-09-27 18:41:59',0),(118,'Lisanchuan','0183960416','whatsApp',19,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'60183805019','25,菠萝蜜,1.27,龙眼,1.23,菠萝1/4,1.24,香蕉一串儿,1.','2018-09-30 18:32:05',0),(119,'Nalifan','0168160520','whatsApp',30,1,'Ibu_Zain 18D,Tuesday,7pm-9pm',2,'60183805019','5,橘子一袋,1.12,柠檬,1.9,青皮芒,1.25,菠萝蜜,1.27,龙眼,1.','2018-10-01 11:42:23',0),(120,'段若尧','01112405616','whatsApp',14.5,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'60183805019','25,菠萝蜜,1.19,莲雾一包,1.9,青皮芒,1.','2018-10-01 12:08:47',0),(121,'何琪','1161772765','whatsApp',20,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'60183805019','1,青苹果,1.6,橙子,2.20,哈密瓜,1.22,西瓜1/4,1.25,菠萝蜜,1.','2018-10-01 13:35:02',0),(122,'梁漪辰','60173007001','whatsApp',10.5,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'60183805019','1,青苹果,1.17,奇异果一盒,1.21,哈密瓜块儿,1.3,红苹果,1.','2018-10-01 15:58:46',0),(123,'张梦璐','01121102023','whatsApp',22.5,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'60183805019','12,柠檬,1.17,奇异果一盒,1.23,菠萝1/2,2.24,香蕉一串儿,1.25,菠萝蜜,2.','2018-10-01 17:07:07',0),(124,'周文雅','0133075132','whatsApp',38,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'60183805019','13,李子,6.20,哈密瓜,1.23,菠萝1/2,1.25,菠萝蜜,2.5,橘子一袋,1.','2018-10-01 22:45:30',0),(125,'saber','01161272385','Phone',17.5,1,'KKM,Tuesday,7pm-9pm',2,'60183805019','22,西瓜1/4,1.6,橙子,6.25,菠萝蜜,1.','2018-10-01 22:56:12',0),(126,'李广新','0176536518','Phone',16,1,'Ibu_Zain,Thursday 19B,4pm-6pm',2,'60183805019','25,菠萝蜜,2.9,青皮芒,3.','2018-10-03 10:07:19',0),(127,'zhangkaixuan','01136903150','Phone',24,1,'Ibu_Zain,Thursday 19A,4pm-6pm',2,'60183805019','24,香蕉一串儿,1.21,哈密瓜块儿,2.25,菠萝蜜,4.','2018-10-03 10:07:21',0),(128,'张锦妍','0176536738','Phone',3.5,1,'Ibu_Zain,Tuesday 19A,7pm-9pm',2,'60183805019','25,菠萝蜜,1.','2018-10-03 10:19:28',0),(129,'程雨康','0147342672','whatsApp',19,1,'Villa_Tropika,Thursday,7pm-9pm',2,'60183805019','27,龙眼,1.26,龙宫果,1.23,菠萝1/2,1.','2018-10-03 14:00:42',0),(130,'穆汉穆德阿里巴巴','60172388926','whatsApp',12,1,'Villa_Tropika,Thursday Level.15,',2,'60183805019','23,菠萝1/2,2.6,橙子,1.17,奇异果一盒,1.','2018-10-03 14:37:24',0),(131,'李科沩','01112859923','whatsApp',43,1,'Ibu_Zain,Thursday 18A,7pm-9pm',2,'60183805019','3,红苹果,3.8,优质鸭梨,3.13,李子,5.23,菠萝1/2,1.22,西瓜1/4,3.12,柠檬,2.','2018-10-03 15:40:54',0),(132,'谢欣洋','0149166759','whatsApp',18,1,'Saville_Kajang,Thursday,7pm-9pm',2,'60183805019','9,青皮芒,1.16,草莓一盒,1.17,奇异果一盒,1.','2018-10-03 16:58:16',0),(133,'ChinTongMei','01111652893','whatsApp',26,1,'KKM,Tuesday,7pm-9pm',2,'60183805019','24,香蕉一串儿,5.21,哈密瓜块儿,2.','2018-10-03 18:02:21',0),(134,'Baraa','0183533095','whatsApp',9,1,'Villa_Tropika,Thursday,7pm-9pm',2,'60183805019','8,Good_Pear,2.22,Watermelon_1/4,1.','2018-10-04 00:57:48',0),(135,'HengZhuangDing','0165553239','whatsApp',7,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'60183805019','24,香蕉一串儿,1.21,哈密瓜块儿,1.','2018-10-04 16:00:13',0),(136,'NGQIAORU黄愀茹','0107702196','whatsApp',6.5,1,'ZABA,Tuesday,7pm-9pm',2,'60183805019','1,青苹果,1.12,柠檬,2.13,李子,1.','2018-10-04 21:39:19',0),(137,'郑田玺羽','01128079049','whatsApp',12.5,1,'KKM,Tuesday,7pm-9pm',2,'60183805019','17,奇异果一盒,1.25,菠萝蜜,1.22,西瓜1/4,1.','2018-10-05 16:03:15',0),(138,'何琪','1161772765','Phone',56.5,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'60183805019','1,青苹果,2.23,菠萝1/2,1.25,菠萝蜜,5.9,青皮芒,3.21,哈密瓜块儿,4.13,李子,4.17,奇异果一盒,1','2018-10-06 22:08:42',0),(139,'张梦璐','01121102023','Phone',24.5,1,'Ibu_Zain,Thursday,7pm-9pm',2,'0173837324','9,青皮芒,1.22,西瓜1/4,1.25,菠萝蜜,3.21,哈密瓜块儿,1.23,菠萝1/2,1.','2018-10-08 12:19:23',0),(140,'ZhaoJing','1112407015','whatsApp',7,1,'Ibu_Zain 18C,Tuesday,7pm-9pm',2,'60183805019','24,Banana,1.21,Cantaloupe in box,1.','2018-10-08 12:36:33',0),(142,'穆汉穆德阿里巴巴','60172388926','whatsApp',11,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'60183805019','6,橙子,2.17,奇异果一盒,1.9,青皮芒,1','2018-10-08 16:28:22',0),(143,'Lisanchuan','0183960416','whatsApp',27,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'60183805019','22,西瓜1/4,1.26,龙宫果,1.24,香蕉一串儿,1.6,橙子,1.9,青皮芒,2.17,奇异果一盒,1.','2018-10-08 17:27:25',0),(144,'LUWEN','0149152081','Phone',14,1,'Saville_Kajang,Tuesday,7pm-9pm',2,'60183805019','7,鸭梨,2.9,青皮芒,1.23,菠萝1/2,1.22,西瓜1/4,1.','2018-10-08 21:52:49',0),(146,'heqi','1161772765','whatsApp',8,1,'Ibu_Zain,Thursday,7pm-9pm',2,'0173837324','13,李子,4.','2018-10-10 19:37:20',0),(147,'周文雅','0133075132','Phone',42.5,1,'Villa_Tropika,Thursday,7pm-9pm',2,'0173837324','9,青皮芒,3.13,李子,4.25,菠萝蜜,3.5,橘子一袋,1.23,菠萝1/2,1.','2018-10-10 19:43:49',0),(148,'zhao?chen?yi','0172362750','whatsApp',40,1,'Ibu_Zain,Thursday,19b301,7pm-9pm',2,'0173837324','3,红苹果,4.5,橘子一袋,1.13,李子,10.','2018-10-10 22:37:21',0),(149,'张锦妍','0176536738','Phone',3.5,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'0173837324','25,菠萝蜜,1.','2018-10-10 23:59:04',0),(150,'杨亮','01139363112','whatsApp',30.5,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'0173837324','1,青苹果,4.7,世纪梨,2.11,香蕉一串(长的),1.25,菠萝蜜,1.12,柠檬,2.22,西瓜1/4,1.23,菠萝1/2,1.','2018-10-15 13:15:53',0),(151,'李广新','0176536518','Phone',26,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'0173837324','5,橘子一袋,1.9,青皮芒,1.24,小香蕉一串儿,1.25,菠萝蜜,2.','2018-10-15 13:38:45',0),(152,'Baishuo','0172362520','Phone',7,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'0173837324','18,杨桃一盒,1.21,哈密瓜块儿,1.','2018-10-15 14:14:29',0),(153,'穆汉穆德阿里巴巴','60172388926','whatsApp',12,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'0173837324','7,世纪梨,2.11,香蕉一串(长的),1.6,橙子（大）,1.','2018-10-15 14:44:33',0),(154,'周文雅','0133075132','Phone',17,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'0173837324','25,菠萝蜜,2.23,菠萝1/2,2.13,李子,2.','2018-10-15 17:02:55',0),(155,'Lisanchuan','0183960416','whatsApp',15.5,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'0173837324','25,菠萝蜜,1.26,龙宫果,1.11,香蕉一串(长的),1.','2018-10-15 17:08:00',0),(156,'張文祺','0172377589','whatsApp',11,1,'ZABA,Thursday,7pm-9pm',2,'0173837324','3,红苹果,2.17,奇异果,1.7,世纪梨,1.2,橙子（小）,1.','2018-10-17 10:33:54',0),(157,'梁漪辰','60173007001','whatsApp',10.5,1,'Ibu_Zain,Thursday,7pm-9pm',2,'0173837324','1,青苹果,1.8,优质鸭梨,1.17,奇异果,1.23,菠萝1/2,1.','2018-10-17 16:31:36',0),(158,'wangaobing','01161282099','whatsApp',9,1,'Villa_Tropika,Thursday,7pm-9pm',2,'0173837324','23,Pineapple_1/2,1.7,Oriental_Pear,3.','2018-10-17 21:26:47',0),(159,'徐瑞迪','60172388926','whatsApp',13,1,'ZABA,Thursday,7pm-9pm',2,'0173837324','7,世纪梨,2.11,香蕉一串(长的),1.9,青皮芒,1.','2018-10-17 22:41:14',0),(160,'王嘉雪','0108253058','whatsApp',21.5,1,'Saville_Kajang,Thursday,7pm-9pm',2,'0173837324','27,龙眼,1.22,西瓜1/4,1.4,菠萝蜜,1.23,菠萝1/2,1.','2018-10-17 22:52:10',0),(161,'王应惕','0164308536','Phone',17,1,'Saville_Kajang,Thursday,7pm-9pm',2,'0173837324','3,红苹果,3.9,青皮芒,2.22,西瓜1/4,1.','2018-10-17 23:10:11',0),(162,'黄燕琳','0176505371','Phone',27,1,'Villa_Tropika,Thursday,7pm-9pm',2,'0173837324','23,菠萝1/2,2.9,青皮芒,3.5,橘子一袋,1.','2018-10-18 13:09:31',0),(164,'李科沩','01112859923','whatsApp',25,3,'Ibu_Zain,Breakfast,9:30am-10:30a',2,'0173837324','29,包子(羊肉),4.28,八宝粥,2.31,花卷,1.','2018-10-18 17:04:50',0),(165,'李科沩','01112859923','whatsApp',18,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'0173837324','22,西瓜1/4,1.13,李子,2.4,菠萝蜜,1.3,红苹果,2.12,柠檬,1.','2018-10-18 17:20:12',0),(170,'徐瑞迪','60172388926','whatsApp',17,3,'ZABA,Breakfast,9:30AM-10:30AM',2,'0173837324','29,包子(羊肉),4.28,八宝粥,1.','2018-10-19 00:39:03',0),(168,'余昕蕾','0149166730','whatsApp',12,3,'Villa_Tropika,Breakfast,9:30AM-1',2,'0173837324','29,包子(羊肉),3.31,花卷,1.','2018-10-18 23:47:07',0),(169,'CaoRunze','0182573909','whatsApp',14,3,'Taman_Nadayu,Breakfast,9:30AM-10',2,'0173837324','28,八宝粥,1.29,包子(羊肉),3.','2018-10-18 23:50:21',0),(171,'CaoRunze','0182573909','whatsApp',22,3,'预订到店,Breakfast,9:30am-10:30am',2,'曹润泽','28,Eight_Treasures_Congee,2.29,Bao,4.','2018-10-19 22:54:04',0),(172,'徐瑞迪','60172388926','Phone',12,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'0173837324','6,橙子（大）,1.7,世纪梨,2.19,水翁一包,1.','2018-10-22 09:08:07',0),(173,'杨亮','01139363112','whatsApp',47,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'0173837324','3,红苹果,3.2,橙子（小）,5.6,橙子（大）,2.4,菠萝蜜,2.11,香蕉一串(长的),1.7,世纪梨,2.23,菠萝1/2,2.22,西瓜1/4,1.','2018-10-22 13:32:06',0),(174,'陶佳','01133152839','whatsApp',27,1,'Villa附近的墓地小区,Tuesday,7pm',2,'0173837324','6,橙子（大）,5.9,青皮芒,3.17,奇异果,2.','2018-10-22 13:32:52',0),(175,'liangxinrui','01112809956','whatsApp',20,3,'Ibu_Zain,Breakfast,18D,9:30am-10',2,'0126017986','28,Eight_Treasures_Congee,1.29,Bao,1.31,Steamed_twisted_roll,1.','2018-10-22 13:46:43',0),(176,'ZhaoJing','01112407015','whatsApp',12,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'0173837324','6,橙子（大）,2.11,香蕉一串(长的),1.2,橙子（小）,2.','2018-10-22 18:17:22',0),(177,'Zimu','60172388926','Phone',26,3,'FTSM,Breakfast,9:30AM-10:30AM',2,'0126017986','29,Bao,6.28,Eight_Treasures_Congee,1.49,Lamb_cake,1.','2018-10-22 21:19:51',0),(178,'黄燕琳','0176505371','whatsApp',12,3,'Ibu_Zain,Breakfast,18D,9:30am-10',2,'0126017986','29,Bao,2.48,Garlic_chives_wrap,1.49,Lamb_cake,1.','2018-10-22 21:29:11',0),(179,'heqi','1161772765','whatsApp',17,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'0173837324','2,橙子（小）,2.4,菠萝蜜,2.13,李子,1.21,哈密瓜块儿,1.1,青苹果,2.','2018-10-22 21:53:46',0),(182,'ChanYenYee','0165863537','whatsApp',17,1,'ZABA,Thursday,7pm-9pm',2,'0173837324','26,龙宫果,1.4,菠萝蜜,1.12,柠檬,5.','2018-10-24 10:24:07',0),(183,'wangaobing','01161282099','whatsApp',15.5,1,'Villa_Tropika,Thursday,7pm-9pm',2,'0173837324','4,菠萝蜜,1.23,菠萝1/2,1.21,哈密瓜块儿,1.6,橙子（大）,3.','2018-10-24 19:25:24',0),(184,'Sang','0183519294','whatsApp',11,3,'预订到店,Breakfast,8:30-10:00',2,'预订到店 Sang','28,八宝粥,1.29,包子(羊肉),2.','2018-10-25 09:53:13',0),(185,'Sang','0183519294','whatsApp',9,3,'预订到店,Breakfast,8:30-10:00',2,'预定到店Sang','29,包子(羊肉),1.48,韭菜盒子,2.','2018-10-31 09:22:24',0),(194,'Li Kexin','01112406285','',26,1,'Ibu_Zain,Tuesday,7pm-9pm',2,'01723889266','11,香蕉一串(长的),1.18,杨桃一盒,1.21,哈密瓜块儿,1.22,西瓜1/4,1.23,菠萝1/2,2.2,橙子（小）,2.','2018-11-27 20:10:37',0),(187,'Pang','0127547388','whatsApp',8,3,'KKM,Breakfast,9:30AM-10:30AM',2,'01723889266','48,韭菜盒子,1.28,八宝粥,1.','2018-11-16 22:22:46',0),(195,'wangaobing','01161282099','WhatsApp',2,1,'Villa_Tropika,Tuesday,7pm-9pm',2,'01723889266','2,橙子（小）,2.','2018-11-27 20:28:11',0),(204,'马亮','0164103767','Phone',20,5,'其他大学点这里！,订单确认后我们会联系你,确认订单',2,'0','56,千人晚会入场券x1,2.','2018-12-09 13:56:23',0),(249,'舒茧','01151691877','Phone',11,1,'UKM,IbuZain,Jeff',2,'0166180630','11,香蕉一串(长的),1.22,西瓜1/4,1.','2019-03-29 09:24:30',2),(201,'MARUIQI','01736313147','Wechat',23,3,'Ibu_Zain,Breakfast,9:30am-10:30a',2,'0166180630','29,包子(羊肉),3.48,韭菜盒子,2.50,鲜牛奶,1.49,羊肉饼,1.','2018-12-06 07:40:56',0),(202,'郭少婷','01126238557','WhatsApp',10,5,'UKM国民大学,Ibu_Zain,Hall',2,'0','56,千人晚会入场券x1,1.','2018-12-09 12:34:09',0),(250,'陈思言','0172380992','Phone',11,1,'UKM,IbuZain,Jeff',2,'0166180630','16,草莓一盒,1.','2019-03-29 09:34:02',2),(207,'Lu','0182876710','WhatsApp',20,5,'其他大学点这里！,订单确认后我们会联系你,确认订单',2,'0','56,千人晚会入场券x1,2.','2018-12-09 15:01:24',0),(253,'王一博','0173781653','Phone',4,1,'UKM,IbuZain,Jeff',3,'0166180630','2,橙子（小）,1.','2019-03-29 10:06:59',2),(210,'万欣怡','0172328401','Wechat',10,5,'UKM国民大学,Villa_Tropika,Hall',2,'0','56,千人晚会入场券x1,1.','2018-12-09 15:27:06',0),(240,'WuJiayi','01158607531','WhatsApp',10,5,'其他大学点这里！,订单确认后我们会联系你,确认订单',2,'0','56,千人晚会入场券x1,1.','2018-12-15 10:56:17',0),(241,'HongmanChen','01158631785','WhatsApp',10,5,'其他大学点这里！,订单确认后我们会联系你,确认订单',2,'0','56,千人晚会入场券x1,3.','2018-12-15 11:02:27',0),(215,'Long Liu','01112406898','Phone',11,3,'Saville_Kajang 9:00-10:00am',2,'0166180630','50,Freash_milk,1.31,Steamed_twisted_roll,2.','2018-12-09 22:02:30',0),(216,'Yangbingxin','01163949004','Phone',10,5,'其他大学点这里！,订单确认后我们会联系你,确认订单',2,'0','56,千人晚会入场券x1,2.','2018-12-10 00:08:57',0),(217,'Baraa','0183533095','Phone',9,3,'Villa_Tropika 9:00-10:00am',2,'0166180630','49,Lamb_cake,3.','2018-12-10 00:11:40',0),(218,'Mabaoliang','0183805019','WhatsApp',18,3,'Saville_Kajang 9:00-10:00am',2,'0166180630','29,Bar,4.48,Garlic_chives_wrap,2.','2018-12-10 00:16:48',0),(219,'ZiMu','0172378295','Phone',41,3,'Villa_Tropika 9:00-10:00am',2,'0166180630','29,Bao,8.28,Eight_Treasures_Congee,1.49,Lamb_cake,4.','2018-12-10 02:35:17',0),(256,'GengJiahui','0182418685','Phone',26,1,'UKM,VillaTropika,Andy',2,'0166180630','22,西瓜1/4,1.23,菠萝1/2,1.21,哈密瓜块儿,1.16,草莓一盒,1.3,红苹果,2.','2019-03-29 11:56:45',3),(223,'李德煜','0176190588','WhatsApp',10,5,'其他大学点这里！,订单确认后我们会联系你,确认订单',2,'0','56,千人晚会入场券x1,1.','2018-12-11 09:13:02',0),(234,'张恺璇','1121301188','Phone',15,1,'Ibu_Zain,周五晚上*Fri,7-8pm',2,'0166180630','4,菠萝蜜,2.22,西瓜1/4,1.23,菠萝1/2,1.','2018-12-14 07:41:41',0),(225,'王一玮','01128068680','Wechat',17,1,'Villa_Tropika,周四晚上*Thur,7-8pm',2,'0166180630','6,Citrus Sinensis(Big),5.7,Apple_Pear,2.9,Green_Mango,1.','2018-12-12 15:55:38',0),(226,'周文雅','0133075132','Phone',17,1,'Villa_Tropika,周四下午Thur,4-6pm',2,'0166180630','2,Citrus Sinensis(Small),6.4,Jackfruit,2.13,Plum,2.','2018-12-12 16:41:41',0),(227,'孙中源','01121177095','Phone',12,1,'Villa_Tropika,周四下午Thur,4-6pm',2,'0166180630','9,Green_Mango,2.21,Cantaloupe(cut),1.12,Lemon,2.','2018-12-12 22:16:56',0),(228,'wangaobing','01161282099','WhatsApp',11.5,1,'Villa_Tropika,周四下午Thur,4-6pm',2,'0166180630','4,Jackfruit,1.3,Red_apple,4.','2018-12-13 00:22:25',0),(229,'Andy','60172388926','WhatsApp',15,1,'Villa_Tropika,周四下午Thur,4-6pm',2,'0166180630','13,Plum,1.4,Jackfruit,2.6,Citrus Sinensis(Big),1.7,Apple_Pear,2.','2018-12-13 01:33:02',0),(237,'Andy','60172388926','Phone',9.5,1,'Villa_Tropika,周五下午Fri,4-6pm',2,'0166180630','4,菠萝蜜,1.7,世纪梨,3.','2018-12-14 09:42:21',0),(231,'孙中源','01121177095','Phone',38.5,1,'Villa_Tropika,周五晚上*Fri,7-8pm',2,'0166180630','7,世纪梨,3.16,草莓一盒,1.3,红苹果,1.5,橘子一袋,1.6,橙子（大）,2.4,菠萝蜜,1.','2018-12-13 21:39:41',0),(239,'WuJiayi','01158607531','WhatsApp',30,5,'其他大学点这里！,订单确认后我们会联系你,确认订单',2,'0','56,千人晚会入场券x1,3.','2018-12-14 16:07:10',0),(252,'王雨晴','01164536240','Phone',36,1,'UKM,IbuZain,Jeff',2,'0166180630','11,香蕉一串(长的),1.16,草莓一盒,1.23,菠萝1/2,1.3,红苹果,2.5,橘子一袋,1.','2019-03-29 10:01:26',2),(233,'黄港旋','18820647504','Wechat',100,5,'其他大学点这里！,订单确认后我们会联系你,确认订单',2,'0','56,千人晚会入场券x1,10.','2018-12-13 23:14:25',0),(254,'林峯得不到的女人','0183655924','Phone',94.5,1,'UKM,IbuZain,Jeff',2,'0166180630','21,哈密瓜块儿,1.4,菠萝蜜,2.3,红苹果,2.9,青皮芒,4.12,柠檬,1.22,西瓜1/4,2.27,龙眼,1.23,菠萝1/2,2.5,橘子一袋,1.8,鸭梨,5','2019-03-29 10:45:08',2),(255,'舒茧','01151691877','Phone',10,1,'UKM,IbuZain,Jeff',2,'0166180630','22,西瓜1/4,2.','2019-03-29 11:09:38',2),(257,'Sili','0172694676','Phone',19.5,1,'UKM,IbuZain,Jeff',2,'0166180630','23,一盒菠萝块儿,1.16,草莓一盒,1.','2019-04-01 11:03:20',2),(258,'WangYuqing','01164536240','Phone',16,1,'UKM,IbuZain,Jeff',2,'0166180630','1,青苹果,2.23,一盒菠萝块儿,2.7,世纪梨,2.','2019-04-01 11:56:46',2),(259,'焦雯雯','01116751055','Phone',30.5,1,'UKM,IbuZain,Jeff',2,'0166180630','23,一盒菠萝块儿,1.16,草莓一盒,1.7,世纪梨,2.11,香蕉一串(长的),1.','2019-04-01 12:02:27',2),(260,'王一博','0173781653','Wechat',37,1,'UKM,IbuZain,Jeff',2,'0166180630','8,优质鸭梨,1.28,进口超甜葡萄,1.9,青皮芒,2.','2019-04-01 12:17:26',2),(261,'曲正洋','0173389410','Phone',11,1,'UKM,IbuZain,Jeff',2,'0166180630','22,一盒西瓜块儿,1.23,一盒菠萝块儿,1.','2019-04-01 12:30:51',2),(262,'李文博','01151691877','Wechat',9,1,'UKM,IbuZain,Jeff',2,'0166180630','23,一盒菠萝块儿,2.','2019-04-01 12:36:44',2),(263,'任澳迪','0127110489','Phone',7,1,'UKM,IbuZain,Jeff',2,'0166180630','3,红苹果,2.','2019-04-01 12:40:02',2),(264,'雷莉','0178712162','Phone',29,1,'UKM,IbuZain,Jeff',2,'0166180630','7,世纪梨,4.9,青皮芒,2.19,莲雾(水翁)一包,1.21,哈密瓜块儿,1.','2019-04-01 13:14:51',2),(265,'雷莉','0178712162','Phone',6,1,'UKM,IbuZain,Jeff',2,'0166180630','21,哈密瓜块儿,1.','2019-04-01 13:35:15',2),(266,'沈卓','0182153460','Phone',48,1,'UKM,IbuZain,Jeff',2,'0166180630','4,菠萝蜜,2.9,青皮芒,2.17,奇异果,1.22,一盒西瓜块儿,2.27,龙眼,1.11,香蕉一串(长的),1.2,橙子（小）,4.','2019-04-01 17:41:16',2),(267,'XUYIFAN','601121064270','Phone',16,1,'UKM,IbuZain,Jeff',2,'0166180630','4,菠萝蜜,2.24,小香蕉一串儿,2.','2019-04-01 21:52:57',2),(269,'李可心','01121026439','Wechat',25.5,1,'UKM,IbuZain,Jeff',2,'0166180630','4,菠萝蜜,1.19,莲雾(水翁)一包,1.18,杨桃一盒,1.23,一盒菠萝块儿,1.26,龙宫果,1.','2019-04-02 11:01:39',2),(270,'曹明珠','0183539160','Phone',12,1,'UKM,IbuZain,Jeff',2,'0166180630','3,红苹果,6.','2019-04-02 11:13:23',2),(271,'鸡????老板','01137661085','Phone',12,1,'UKM,IbuZain,Jeff',2,'0166180630','11,香蕉一串(长的),1.22,一盒西瓜块儿,1.','2019-04-02 12:05:36',2),(272,'黄乐辰','01137959711','Phone',5,1,'UKM,IbuZain,Jeff',2,'0166180630','22,一盒西瓜块儿,1.','2019-04-02 12:07:24',2),(273,'韩潇潇','0183252430','Phone',13.5,1,'UKM,IbuZain,Jeff',3,'0166180630','16,草莓一盒,1.','2019-04-02 12:14:28',2),(274,'FUYUKUN','01137613362','Phone',7,1,'UKM,IbuZain,Jeff',2,'0166180630','11,香蕉一串(长的),1.','2019-04-02 12:18:56',2),(275,'唐浚博','01164518949','Phone',27,1,'UKM,IbuZain,Jeff',2,'0166180630','16,草莓一盒,2.','2019-04-04 10:18:15',2),(276,'JiangBin','01137629312','WhatsApp',26.5,1,'UKM,IbuZain,Jeff',2,'0166180630','11,香蕉一串(长的),1.26,龙宫果,1.16,草莓一盒,1.','2019-04-04 14:03:16',2),(277,'焦雯雯','0176674314','Phone',32,1,'UKM,IbuZain,Jeff',2,'0166180630','27,龙眼,1.15,超甜进口提子,1.','2019-04-05 15:17:20',2),(278,'Gengjiahui','0182418685','Phone',16,1,'UKM,VillaTropika,Andy',2,'0166180630','3,红苹果,2.7,世纪梨,2.22,一盒西瓜块儿,1.23,一盒菠萝块儿,1.','2019-04-14 18:59:52',3),(279,'hanxiaoxiao','0183252430','Phone',19,1,'UKM,IbuZain,Jeff',2,'0166180630','5,橘子一袋,1.11,香蕉一串(长的),1.','2019-04-15 10:15:54',2),(280,'龙鱼','01112406898','Phone',15,1,'UKM,IbuZain,Jeff',2,'0166180630','22,一盒西瓜块儿,3.','2019-04-15 10:50:53',2),(281,'史昕潼','01128689473','Phone',13.5,1,'VillaTropika,VillaTropika,Baraa',3,'0166180630','4,菠萝蜜,2.21,哈密瓜块儿,1.','2019-04-17 11:24:56',3),(282,'史昕潼','01128689473','Phone',20,1,'VillaTropika,VillaTropika,Andy',2,'0166180630','4,菠萝蜜,1.27,龙眼,1.21,哈密瓜块儿,1.','2019-04-24 15:57:47',3);
/*!40000 ALTER TABLE `History2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Moment`
--

DROP TABLE IF EXISTS `Moment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Moment` (
  `MomentID` int(11) NOT NULL AUTO_INCREMENT,
  `MType` char(50) NOT NULL DEFAULT 'en',
  `SenderID` int(11) DEFAULT NULL,
  `Sender` varchar(50) DEFAULT NULL,
  `Content` varchar(5000) DEFAULT NULL,
  `Pictures` int(11) DEFAULT '0',
  `Like` int(11) DEFAULT '0',
  `TopicIDs` varchar(50) DEFAULT '0',
  `MDate` datetime DEFAULT NULL,
  `LastEdit` datetime DEFAULT NULL,
  PRIMARY KEY (`MomentID`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Moment`
--

LOCK TABLES `Moment` WRITE;
/*!40000 ALTER TABLE `Moment` DISABLE KEYS */;
INSERT INTO `Moment` VALUES (3,'zh',24,'冰冰侠客','&amp;lt;section&amp;gt;哈喽，积土&amp;lt;/section&amp;gt;&amp;lt;sectionclass=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',2,0,'0','2020-03-10 12:59:57',NULL),(5,'zh',1,'Andy','&amp;lt;section&amp;gt;Hi,JTalk&amp;lt;/section&amp;gt;&amp;lt;sectionclass=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',2,0,'0','2020-03-10 14:00:25',NULL),(48,'zh',37,'缤雪的雨季','&amp;lt;section&amp;gt;啥时候登LOL?&amp;lt;/section&amp;gt;',0,0,'0','2020-03-16 19:49:58',NULL),(49,'zh',2,'JTalk官方','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;h2 style=&amp;quot;color:rgb(208,208,208);text-decoration:line-through;&amp;quot;&amp;gt;新型冠状病毒在国内已经被控制的差不多了。。。。&amp;lt;/h2&amp;gt;&amp;lt;section&amp;gt;然而现在国外却开始迎接这场防疫站的下半场&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;各位同胞们，咱都心里苦T.T&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color:rgb(253,170,37);font-weight:800;font-      style:italic;&amp;quot;&amp;gt;咱作为一个集体，让我们一起挺过去吧&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color:rgb(51,51,51);&amp;quot;&amp;gt;这几天一定要好好照顾好自己欧&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color:rgb(51,51,51);font-weight:800;&amp;quot;&amp;gt;少出门少聚集，消毒水口罩随身带&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;',4,9,'0','2020-03-24 12:00:00','2020-03-24 12:10:14'),(10,'zh',2,'JTalk官方','&amp;lt;section&amp;gt;（吉隆坡10日讯）我国今日新增12宗新冠肺炎确诊病例，这使到累积确诊病例达129宗。&amp;lt;/section&amp;gt;&amp;lt;sectionclass=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;首相办公室今晚发出文告指出，全国危机准备及应对中心（CPRC）今日宣布新增12宗病例。&amp;lt;/section&amp;gt;&amp;lt;h4style=&amp;quot;color:rgb(253,170,37);font-style:italic;&amp;quot;&amp;gt;为了各位的健康，请大家出门最好佩戴口罩&amp;lt;/h4&amp;gt;',2,0,'0','2020-03-11 12:52:57',NULL),(47,'zh',1,'Andy','&amp;lt;sectionclass=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;全球齐心协力，共抵病毒，加油&amp;lt;/section&amp;gt;',1,0,'0','2020-03-15 19:10:01',NULL),(45,'zh',1,'Andy','&amp;lt;section&amp;gt;感受全新积土！&amp;lt;/section&amp;gt;&amp;lt;sectionclass=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-15 14:41:21',NULL),(68,'zh',1,'Andy','&amp;lt;h2 style=&amp;quot;color: rgb(208, 208, 208);&amp;quot;&amp;gt;(疫情记录1) &amp;lt;/h2&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;简简单单才是真嗷 ～&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;闲着在家修炼厨艺，dayday up&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-22 19:17:49','2020-03-25 12:47:45'),(66,'zh',2,'JTalk官方','&amp;lt;h2 style=&amp;quot;color: rgb(253, 170, 37); text-align: center;&amp;quot;&amp;gt;JTalk 王者荣耀争霸赛报名帖&amp;lt;/h2&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;blockquote class=&amp;quot;child-is-picture&amp;quot; style=&amp;quot;color: rgb(176, 101, 226);&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;安卓请在下载JTalk App后在下方评论报名&amp;lt;/span&amp;gt;&amp;lt;/blockquote&amp;gt;&amp;lt;section&amp;gt;&amp;lt;blockquote class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;I&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;OS用户可以联系朋友或者管理员在下发代报&amp;lt;/span&amp;gt;&amp;lt;/blockquote&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(176, 101, 226); font-weight: 800; font-style: italic;&amp;quot;&amp;gt;报名格式&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;只需要队长报名即可：(赛区) 微信号&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(208, 208, 208);&amp;quot;&amp;gt;如 :（微信）微信号&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(68, 198, 123); font-weight: 800;&amp;quot;&amp;gt;在收到官方评论回复后表示报名成功&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;h4 style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;本次赛事分为两个赛区：QQ,  微信&amp;lt;/span&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/h4&amp;gt;&amp;lt;section&amp;gt;&amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;每一个赛区都只限16队报名，报满关闭报名通道。&amp;lt;/span&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;报名截止日期在 3月 23日（星期一）晚上21点截止&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(176, 101, 226);&amp;quot;&amp;gt;开赛时间将会在报名截止后在JTalk里通知&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(253, 170, 37); font-style: italic; font-weight: 800;&amp;quot;&amp;gt;各位召唤师们，冲呀！&amp;lt;/section&amp;gt;',1,0,'0','2020-03-21 11:52:58',NULL),(80,'zh',2,'JTalk官方','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;h2 style=&amp;quot;color: rgb(253, 170, 37);&amp;quot;&amp;gt;半决赛下饭时刻！&amp;lt;/h2&amp;gt;&amp;lt;section&amp;gt;这场是精神小伙成双队 对阵 燃烧你的梦队&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;这场精神小伙露娜的一波敌方蓝区反野直接斩杀对方中c，大乱对面节奏！&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;六分钟，下路爆发一波小规模团战，精神小伙张飞一声吼，冲锋陷阵杀入敌方塔下完成双杀。随后对面周瑜赶到，张飞小伙只能在火海中喊着麻麻我好怕... &amp;lt;/section&amp;gt;',3,27,'0','2020-03-25 15:16:12','2020-04-06 16:52:22'),(70,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;An opportunity for me to improve my cooking skill... &amp;lt;/section&amp;gt;',3,1,'0','2020-03-22 22:47:56',NULL),(71,'en',6,'Baraa','&amp;lt;section&amp;gt;New app, new feelings. Well done bud  !I!ud83d!I!ude01&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-22 22:57:41',NULL),(72,'en',6,'Baraa','&amp;lt;section&amp;gt;Rocket league !I!ud83d!I!ude0e!I!ud83d!I!ude0e&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-22 23:48:50',NULL),(75,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Everyone just stay safe,  hope it will be controlled soon!I!ud83d!I!ude4f&amp;lt;/section&amp;gt;',1,0,'0','2020-03-23 20:17:20',NULL),(76,'en',6,'Baraa','&amp;lt;section&amp;gt;212 new cases! &amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;It is serious, no kidding!&amp;lt;/span&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-23 20:50:21','2020-03-29 10:06:45'),(77,'zh',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;防护指南!I!ud83d!I!ude2e&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;留学在外，学业重要，身体健康更重要哟!I!ud83d!I!ude01&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;无论留守还是回国，同学们都要吃好，睡好，防护好！&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',2,0,'0','2020-03-23 22:48:51',NULL),(78,'en',6,'Baraa','&amp;lt;section&amp;gt;A long night ahead. #fyp&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-24 04:23:26',NULL),(79,'en',6,'Baraa','&amp;lt;section&amp;gt;Good days...&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-24 23:14:34',NULL),(81,'en',6,'Baraa','&amp;lt;section&amp;gt;April #2020 !I!ud83d!I!udc40 What kind of surprises do you have for us? !I!ud83d!I!ude42&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-25 15:48:20',NULL),(83,'zh',2,'JTalk官方','&amp;lt;h2 style=&amp;quot;color: rgb(255, 88, 61);&amp;quot;&amp;gt;JTALK杯王者荣耀决赛关注方法&amp;lt;/h2&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;今晚，让我们一起见证冠军的诞生&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(253, 170, 37);&amp;quot;&amp;gt;下面是观战手册&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;1. 扫描群内二维码进入王者荣耀自动打开赛事系统&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;2. 若上面方法不凑效&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;进入王者荣耀点击微赛事。&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51);&amp;quot;&amp;gt;进入自建比赛&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;点击上面这个搜索按钮复制群内发的&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot; style=&amp;quot;color: rgb(176, 101, 226);&amp;quot;&amp;gt;赛事码&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot; style=&amp;quot;color: rgb(253, 170, 37);&amp;quot;&amp;gt;为他们加油吧！&amp;lt;/section&amp;gt;',3,3,'0','2020-03-26 19:47:01','2020-04-06 16:50:17'),(115,'en',6,'Baraa','&amp;lt;section style=&amp;quot;color: rgb(51, 51, 51); font-weight: 800;&amp;quot;&amp;gt;#uncharted4 | A MASTERPIECE | !I!ud83d!I!ude03!I!ud83d!I!udc4c!I!ud83c!I!udffc&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-04-10 00:36:04',NULL),(84,'en',6,'Baraa','&amp;lt;section&amp;gt;#tbt #mygang !I!ud83d!I!udd25&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-27 06:33:29',NULL),(86,'en',6,'Baraa','&amp;lt;section&amp;gt;#night !I!ud83c!I!udf03&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-27 06:38:59',NULL),(87,'en',6,'Baraa','&amp;lt;section&amp;gt;Good morning !I!ud83c!I!udf1e&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-28 10:59:30','2020-03-29 09:59:52'),(88,'en',6,'Baraa','&amp;lt;section&amp;gt;Tranquility !I!ud83d!I!ude0c&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-29 06:20:21',NULL),(91,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;The beautiful moment. &amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;It&amp;#39;s gonna have three more month to work,  study from home. &amp;lt;/section&amp;gt;&amp;lt;h4 style=&amp;quot;color: rgb(20, 178, 224);&amp;quot;&amp;gt;Time management is so important for now. &amp;lt;/h4&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(255, 88, 61);&amp;quot;&amp;gt;This post is to remind me and you, you deserve a better life. &amp;lt;/section&amp;gt;',1,0,'0','2020-03-29 16:58:51',NULL),(120,'en',6,'Baraa','&amp;lt;section&amp;gt;The NATHAN DRAKE Collection !I!ud83d!I!udd25&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-04-16 23:30:01',NULL),(92,'en',6,'Baraa','&amp;lt;section&amp;gt;FYP !I!ud83e!I!udd74 #dizzy&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-03-31 08:26:24',NULL),(93,'en',6,'Baraa','&amp;lt;section&amp;gt;!I!ud83d!I!udd25&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-04-01 13:28:25',NULL),(95,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Let do some exercises !I!ud83d!I!udcaa&amp;lt;/section&amp;gt;',1,0,'0','2020-04-02 18:30:33',NULL),(96,'en',6,'Baraa','&amp;lt;section&amp;gt;!I!ud83d!I!ude34&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-04-03 23:11:50',NULL),(97,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;h4 style=&amp;quot;color: rgb(208, 208, 208);&amp;quot;&amp;gt;April 4th, today is the day for all the Chinese people to &amp;lt;span style=&amp;quot;caret-color: orange;&amp;quot;&amp;gt;mourn Covid-19 victims. &amp;lt;/span&amp;gt;&amp;lt;/h4&amp;gt;&amp;lt;section&amp;gt;It&amp;#39;s s a long story since the end of last year. &amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;In WuHan, people were lived in peace and happiness. &amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Suddenly,  the virus screwed everything...... &amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;All the facilities were shutdown,  a lot of people suffering from it..... &amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Please, everyone who is reading this post,  use one minute in ur life to mourn for Covid_19 virus victims through the world!I!ud83d!I!ude4f&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Also,  there has some angles, they decided to go to the &amp;#39;harm areas&amp;#39; when things are in the time of crisis. &amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;They are heroes. the bravest people for the world to save lives,  miss you. &amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Stay safe my friends,  we are together to against this virus,  the people all over the world will definitely defeat it!I!ud83d!I!udcaa&amp;lt;/section&amp;gt;',3,0,'0','2020-04-04 09:42:01','2020-04-04 09:42:48'),(101,'en',6,'Baraa','&amp;lt;section&amp;gt;What a game! !I!ud83d!I!udd25 @Andy&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-04-06 01:39:54',NULL),(102,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;A way out!I!ud83d!I!ude0d&amp;lt;/section&amp;gt;',1,0,'0','2020-04-06 10:17:49',NULL),(114,'en',6,'Baraa','&amp;lt;section&amp;gt;Rainy days are the best !I!ud83c!I!udf27&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,1,'0','2020-04-08 18:15:53',NULL),(117,'en',6,'Baraa','&amp;lt;section&amp;gt;!I!ud83d!I!udc80&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,0,'0','2020-04-10 03:07:01',NULL),(119,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;One more fantastic night!I!ud83d!I!udc7b!I!ud83e!I!udd29&amp;lt;/section&amp;gt;',1,0,'0','2020-04-13 11:58:34',NULL),(118,'zh',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;UKM中国留学生会；&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;祖国不远万里寄来健康包，接下来就由我们将这份爱传递给同学们吧&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section style=&amp;quot;color: rgb(253, 170, 37);&amp;quot;&amp;gt;中国加油!I!ud83c!I!udde8!I!ud83c!I!uddf3世界加油！&amp;lt;/section&amp;gt;',2,1,'0','2020-04-12 15:38:45','2020-05-19 14:30:47'),(131,'en',1,'Andy','&amp;lt;section&amp;gt;The fresh look is ready to release!I!ud83d!I!ude01&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;This is no. 1&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Mr. no. 2 is here. &amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Guess who... Yes, it is No. 3!I!ud83d!I!ude03&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Four! &amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Friday brings the lucky, five&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Double click Six, Six, Six!&amp;lt;/section&amp;gt;',6,3,'0','2020-04-19 20:35:00','2020-04-22 20:14:29'),(133,'en',6,'Baraa','&amp;lt;section&amp;gt;On Fire !I!ud83d!I!udd25&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,2,'0','2020-04-22 06:08:36',NULL),(134,'en',6,'Baraa','&amp;lt;section&amp;gt;Ramadan Kareem!I!ud83c!I!udf19!I!ud83d!I!ude42&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,1,'0','2020-04-24 06:04:38',NULL),(135,'en',6,'Baraa','&amp;lt;section&amp;gt;UKMs way of saying #welcomeback !I!ud83d!I!ude11&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,1,'0','2020-04-29 09:03:35',NULL),(136,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Time to get back to the lecture learning!I!ud83d!I!ude42&amp;lt;/section&amp;gt;',1,2,'0','2020-04-29 22:01:09',NULL),(137,'en',6,'Baraa','&amp;lt;section&amp;gt;While fasting, programming is not the best thing to do !I!ud83d!I!ude43&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,1,'0','2020-05-10 19:00:34',NULL),(138,'en',6,'Baraa','&amp;lt;section&amp;gt;Eid Mubarak !I!ud83e!I!udd73&amp;lt;/section&amp;gt;&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;&amp;lt;br&amp;gt;&amp;lt;/section&amp;gt;',1,1,'0','2020-05-24 21:52:48',NULL),(139,'en',1,'Andy','&amp;lt;section class=&amp;quot;child-is-picture&amp;quot;&amp;gt;&amp;lt;img&amp;gt;&amp;lt;/section&amp;gt;&amp;lt;section&amp;gt;Python!I!ud83e!I!uddd0!I!ud83d!I!ude02&amp;lt;/section&amp;gt;',1,1,'0','2020-06-19 11:25:25',NULL);
/*!40000 ALTER TABLE `Moment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Moment_Comment`
--

DROP TABLE IF EXISTS `Moment_Comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Moment_Comment` (
  `CommentID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `User` varchar(30) CHARACTER SET gbk DEFAULT NULL,
  `MomentID` int(11) DEFAULT NULL,
  `CommentContent` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `PostDate` datetime DEFAULT NULL,
  `IsRead` int(11) DEFAULT '0',
  PRIMARY KEY (`CommentID`)
) ENGINE=InnoDB AUTO_INCREMENT=232 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Moment_Comment`
--

LOCK TABLES `Moment_Comment` WRITE;
/*!40000 ALTER TABLE `Moment_Comment` DISABLE KEYS */;
INSERT INTO `Moment_Comment` VALUES (42,3,'Jackey',102,'哈哈！','2020-03-09 22:51:07',0),(43,1,'Andy',7,'你在玩火','2020-03-10 17:00:29',0),(49,37,'Andy',7,'哦','2020-03-10 17:05:55',0),(50,37,'小盆友',3,'1','2020-03-10 17:07:12',0),(104,24,'冰冰侠客',47,'你好','2020-03-19 19:55:14',0),(105,3,'天空之镜',66,'火钳刘明','2020-03-21 11:37:06',0),(107,37,'缤雪的雨季',66,'（报名）QQ张文祺','2020-03-21 13:02:05',0),(108,1,'Andy',66,'报名(QQ) DYHSDYP','2020-03-21 14:50:27',0),(109,1,'Andy',66,'报名(QQ)  陈瀚阳','2020-03-21 19:06:56',0),(110,1,'Andy',66,'报名(QQ) sad799533877','2020-03-21 19:37:10',0),(111,1,'Andy',66,'报名(QQ) 程禁泽','2020-03-21 19:38:29',0),(112,24,'冰冰侠客',49,'嗯嗯','2020-03-21 19:39:54',0),(113,39,'Ahy!',66,'报名（QQ）1594556687','2020-03-22 00:15:48',0),(114,1,'Andy',71,'Thanks bud!!! and the emojis are not working la hahaha','2020-03-22 23:03:10',0),(115,6,'Baraa',70,'Make sure you don&amp;#39;t forget to add salt !','2020-03-22 23:37:07',0),(138,2,'JTalk官方',45,'英国国歌!I!ud83c!I!uddec!I!ud83c!I!udde7','2020-03-23 11:51:07',0),(139,1,'Andy',45,'!I!ud83d!I!ude01!I!ud83d!I!ude0e','2020-03-23 12:20:18',0),(140,1,'Andy',72,'!I!ud83d!I!ude0d！','2020-03-23 12:22:07',0),(144,2,'JTalk官方',45,'发发发','2020-03-23 12:28:27',0),(145,1,'Andy',71,'!I!ud83d!I!ude42!I!ud83d!I!ude09!I!ud83d!I!ude1a!I!ud83d!I!ude09!I!ud83d!I!ude43!I!ud83d!I!ude09☺️','2020-03-23 19:45:36',0),(146,6,'Baraa',75,'Hope so !I!ud83e!I!udd32!I!ud83c!I!udffc','2020-03-23 20:47:31',0),(148,2,'JTalk官方',45,'说得好','2020-03-23 22:38:02',0),(149,1,'Andy',79,'Good days,  Nice memories... !I!ud83d!I!ude0c','2020-03-25 09:20:43',0),(150,1,'Andy',81,'The life without salt!I!ud83d!I!ude0b','2020-03-26 16:07:18',0),(151,3,'快乐风男',83,'前排米饭盛好了','2020-03-26 19:56:49',0),(152,1,'Andy',83,'冲！','2020-03-26 20:01:25',0),(153,1,'Andy',86,'Time to sleep','2020-03-27 23:55:37',0),(154,2,'JTalk官方',87,'Good morning bud, A nice day just started!!I!ud83d!I!ude01','2020-03-28 11:37:51',0),(155,1,'Andy',88,'where is this? !I!ud83d!I!ude2f','2020-03-29 08:37:27',0),(158,2,'JTalk官方',70,'哈哈哈','2020-03-29 11:37:39',0),(159,6,'Baraa',91,'Well said bud !I!ud83d!I!udc4f!I!ud83c!I!udffb!I!ud83d!I!ude09','2020-03-30 04:58:52',0),(163,1,'Andy',92,'omg!!! is it D2? !I!ud83e!I!uddd0!I!ud83d!I!ude31!I!ud83d!I!ude31,  Looks quite complex,  all about logic things... !I!ud83e!I!udd2f','2020-03-31 09:41:49',0),(166,1,'Andy',93,'U started the design!','2020-04-01 15:38:46',0),(168,6,'Baraa',95,'We definitely need to !I!ud83d!I!udc4c!I!ud83c!I!udffc','2020-04-03 08:14:58',0),(169,1,'Andy',96,'sweet dream bud!I!ud83d!I!ude34','2020-04-03 23:17:11',0),(170,3,'XPW',97,'Well said man!I!ud83d!I!udc4d','2020-04-04 11:56:16',0),(171,24,'Bing!',97,'Hope everything will get better soon','2020-04-04 12:06:44',0),(173,6,'Baraa',97,'!I!ud83d!I!ude47!I!ud83c!I!udffb‍♂️!I!ud83d!I!udc4f!I!ud83c!I!udffb!I!ud83d!I!udd1d','2020-04-04 14:12:31',0),(174,1,'Andy',101,'yeah,  what a nice game！!I!ud83d!I!ude0e','2020-04-06 15:00:37',0),(176,1,'Andy',114,'For today, it was pouring!I!ud83d!I!ude02','2020-04-08 22:01:34',0),(177,3,'XPY',45,'测测你','2020-04-09 15:08:06',0),(178,1,'Andy',115,'incredible grafic performance!I!ud83d!I!ude03','2020-04-10 11:52:58',0),(179,1,'Andy',117,'I definitely won&amp;#39;t play this kind of game at night!I!ud83d!I!udc7d','2020-04-10 11:54:04',0),(180,2,'JTalk官方',77,'test','2020-04-10 11:55:22',0),(181,2,'JTalk官方',77,'小飞飞','2020-04-10 12:17:23',0),(182,2,'JTalk官方',77,'Fjfffhjsjs','2020-04-10 13:53:09',0),(183,2,'JTalk官方',77,'Gano','2020-04-10 13:54:27',0),(184,2,'JTalk官方',77,'Zzzbzhzhh','2020-04-10 14:32:02',0),(185,2,'JTalk官方',77,'我觉得可以','2020-04-10 14:42:32',0),(186,1,'Andy',77,'GG刚刚好','2020-04-10 14:44:48',0),(187,3,'XPY',102,'测试一下你','2020-04-10 16:50:44',0),(188,3,'XPY',102,'大家都好发货','2020-04-10 16:52:02',0),(189,3,'tester',77,'测你一下','2020-04-12 12:02:52',0),(190,1,'Andy',117,'I&amp;#39;m playing now!I!ud83d!I!ude0f','2020-04-12 20:20:00',0),(191,6,'Baraa',119,'!I!ud83d!I!ude01!I!ud83d!I!udd25!I!ud83d!I!udc4c!I!ud83c!I!udffc','2020-04-13 19:50:59',0),(192,2,'JTalk官方',119,'gooo','2020-04-15 13:03:48',0),(193,1,'Andy',120,'Oh man!I!ud83d!I!ude0b','2020-04-17 11:03:29',0),(194,6,'Baraa',131,'Wow !I!ud83e!I!udd29','2020-04-20 00:35:26',0),(195,3,'XPY',131,'Incredible','2020-04-21 21:19:50',0),(196,1,'Andy',133,'Nice filter, Like the movie ghost rider','2020-04-22 16:08:35',0),(202,3,'XPY',131,'test u','2020-04-23 16:13:27',0),(203,1,'Andy',134,'Kul&amp;#39;am wa enta bi-khair!','2020-04-26 15:14:06',0),(204,1,'Andy',135,'Love u UKM!I!ud83d!I!udde3','2020-04-29 21:54:32',0),(205,6,'Baraa',136,'Those lectures are too useless and too boring !I!ud83d!I!ude43','2020-04-30 12:47:28',0),(206,2,'JTalk官方',137,'Enjoy the peace in the daytime !I!ud83d!I!ude01','2020-05-11 21:57:59',0),(207,37,'缤雪的雨季',118,'加油','2020-05-22 12:49:56',0),(222,1,'Andy',48,'测试成功啦！','2020-05-22 19:18:01',0),(230,37,'缤雪的雨季',118,'7','2020-05-23 14:23:31',0),(231,6,'Baraa',139,'True !I!ud83d!I!ude02!I!ud83d!I!ude02 (If you use a text editor)','2020-06-20 10:37:44',0);
/*!40000 ALTER TABLE `Moment_Comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Moment_Reply`
--

DROP TABLE IF EXISTS `Moment_Reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Moment_Reply` (
  `ReplyID` int(11) NOT NULL AUTO_INCREMENT,
  `RootID` int(11) NOT NULL DEFAULT '0',
  `CID` int(11) DEFAULT NULL,
  `ContentR` varchar(500) DEFAULT NULL,
  `ToUser` int(11) DEFAULT NULL,
  `ToName` varchar(50) DEFAULT NULL,
  `FromUser` int(11) DEFAULT NULL,
  `FromName` varchar(50) DEFAULT NULL,
  `ReplyDate` datetime DEFAULT NULL,
  `IsRead` int(11) DEFAULT '0',
  PRIMARY KEY (`ReplyID`)
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Moment_Reply`
--

LOCK TABLES `Moment_Reply` WRITE;
/*!40000 ALTER TABLE `Moment_Reply` DISABLE KEYS */;
INSERT INTO `Moment_Reply` VALUES (30,3,50,'把你名字改一哈',NULL,NULL,1,'Andy','2020-03-10 20:06:59',0),(157,92,163,'De... debugging...?',NULL,NULL,1,'Andy','2020-03-31 10:18:53',0),(159,93,166,'Yup, just working on the main layouts to make a proper development environment. When I&amp;#39;m done, I&amp;#39;ll proceed with the development of the system itself. The UI will be the last thing I do.',NULL,NULL,6,'Baraa','2020-04-01 16:08:19',0),(151,88,155,'It is my prayer rug, taken right before the sunrise !I!ud83d!I!ude42 increase your screen brightness.',NULL,NULL,6,'Baraa','2020-03-29 10:01:37',0),(149,88,155,'quite dark... is it a door!I!ud83e!I!udd14',NULL,NULL,1,'Andy','2020-03-29 09:31:24',0),(148,88,155,'My room !I!ud83d!I!ude42',NULL,NULL,6,'Baraa','2020-03-29 09:08:06',0),(147,87,154,'Mooorning !I!ud83d!I!ude09 Indeed, a nice day has just started !I!ud83d!I!udc4c!I!ud83c!I!udffc',NULL,NULL,6,'Baraa','2020-03-28 12:00:56',0),(146,81,150,'!I!ud83d!I!ude02!I!ud83d!I!ude02!I!ud83d!I!ude02!I!ud83d!I!ude02',NULL,NULL,6,'Baraa','2020-03-27 06:26:28',0),(145,71,145,'Here they work !I!ud83d!I!ude01',NULL,NULL,6,'Baraa','2020-03-25 15:27:28',0),(144,71,114,'!I!ud83e!I!udd29',NULL,NULL,6,'Baraa','2020-03-25 15:27:06',0),(143,79,149,'Indeed they are !I!ud83d!I!ude03',NULL,NULL,6,'Baraa','2020-03-25 15:26:07',0),(142,45,147,'np',NULL,NULL,1,'Andy','2020-03-23 22:39:50',0),(141,45,147,'啊哈？',NULL,NULL,1,'Andy','2020-03-23 22:38:15',0),(139,70,115,'Forget about the previous taste !I!ud83e!I!udd23!I!ud83e!I!udd23',NULL,NULL,1,'Andy','2020-03-23 18:39:25',0),(169,97,171,'same wish with u!I!ud83d!I!udd6f',NULL,NULL,1,'Andy','2020-04-04 12:15:37',0),(154,88,155,'!I!ud83d!I!udc4d!I!ud83d!I!ude0f',NULL,NULL,1,'Andy','2020-03-29 17:01:23',0),(137,45,138,'成了',NULL,NULL,1,'Andy','2020-03-23 12:28:53',0),(135,45,138,'牛逼!I!ud83d!I!udc2e',NULL,NULL,2,'JTalk官方','2020-03-23 11:51:13',0),(134,66,113,'收到！赛事开始会讲您拉进群哒',NULL,NULL,2,'JTalk官方','2020-03-22 09:50:20',0),(133,66,111,'报名成功',NULL,NULL,2,'JTalk官方','2020-03-21 21:22:00',0),(132,66,110,'报名成功',NULL,NULL,2,'JTalk官方','2020-03-21 21:21:54',0),(131,66,109,'报名成功+1 ~',NULL,NULL,2,'JTalk官方','2020-03-21 19:09:42',0),(128,66,107,'好的呢，稍后管理员将会拉您进赛事群',NULL,NULL,2,'JTalk官方','2020-03-21 13:04:54',0),(129,66,105,'留',NULL,NULL,2,'快乐风男','2020-03-21 13:13:26',0),(130,66,108,'ok！稍后管理员将会拉您进入赛事群',NULL,NULL,2,'JTalk官方','2020-03-21 14:52:49',0),(122,66,105,'刘明',NULL,NULL,1,'冰冰侠客','2020-03-21 12:22:45',0),(116,3,102,'哈喽',NULL,NULL,24,'冰冰侠客','2020-03-17 21:34:51',0),(158,92,163,'Indeed. It is D2. This model specifically is so damn complex cuz it illustrates the flow of all the data in the system including inputs and outputs of every entity and process !I!ud83e!I!udd2f',NULL,NULL,6,'Baraa','2020-03-31 10:24:43',0),(160,93,166,'good,  u ar doing it in the really right way bud!I!ud83d!I!ude01.  the date that u get this job done is closer and closer!I!ud83d!I!udcaa',NULL,NULL,1,'Andy','2020-04-01 17:30:16',0),(161,93,166,'!I!ud83d!I!ude01!I!ud83d!I!udc4c!I!ud83c!I!udffc',NULL,NULL,6,'Baraa','2020-04-01 18:18:57',0),(162,83,151,'一碗一碗又一碗',NULL,NULL,1,'Andy','2020-04-01 20:22:37',0),(163,95,168,'!I!ud83d!I!ude0eI&amp;#39;m doing right now',NULL,NULL,1,'Andy','2020-04-03 18:25:28',0),(164,95,168,'Cool !I!ud83d!I!udcaa!I!ud83c!I!udffcI did it this morning. No wonder I was too tired when I was done !I!ud83d!I!ude02 I have not moved out of home or done such exercises for so long !I!ud83e!I!udd26!I!ud83c!I!udffb?♂?',NULL,NULL,6,'Baraa','2020-04-03 18:35:18',0),(165,95,168,'!I!ud83e!I!udd14!I!ud83d!I!udc68♂！！？ now I&amp;#39;m quite interesting in what kind of &amp;#39;such&amp;#39; exercise u did?!I!ud83d!I!ude01♂',NULL,NULL,1,'Andy','2020-04-03 18:46:12',0),(166,95,168,'Here&amp;#39;s a link of the video I followed !I!ud83d!I!ude01https://youtu.be/sjmsApWcyCU',NULL,NULL,6,'Baraa','2020-04-03 18:50:56',0),(167,95,168,'Got it,  let me try ha!I!ud83d!I!ude0e!I!ud83d!I!ude03',NULL,NULL,1,'Andy','2020-04-03 18:53:19',0),(168,95,168,'Good luck with it !I!ud83d!I!ude01',NULL,NULL,6,'Baraa','2020-04-03 18:54:42',0),(170,114,176,'Yeah !I!ud83d!I!ude01',NULL,NULL,6,'Baraa','2020-04-09 14:10:43',0),(171,77,180,'盛世军婚打电话',NULL,NULL,2,'JTalk官方','2020-04-10 11:57:12',0),(172,77,180,'好的',NULL,NULL,1,'Andy','2020-04-10 11:59:59',0),(173,77,180,'好的呢',NULL,NULL,2,'JTalk官方','2020-04-10 12:00:05',0),(174,77,180,'你确定？',NULL,NULL,2,'JTalk官方','2020-04-10 12:08:36',0),(175,77,180,'吃完',NULL,NULL,2,'JTalk官方','2020-04-10 12:16:19',0),(176,77,180,'哈哈',NULL,NULL,2,'JTalk官方','2020-04-10 12:17:34',0),(180,117,179,'Why not! !I!ud83d!I!ude02 It is not a horror game, it is an adventure game !I!ud83d!I!udca3!I!ud83d!I!udd25',NULL,NULL,6,'Baraa','2020-04-11 03:15:07',0),(178,77,180,'男生基督教',NULL,NULL,2,'JTalk官方','2020-04-10 13:48:08',0),(179,77,180,'Ndndjdjd',NULL,NULL,2,'JTalk官方','2020-04-10 14:32:06',0),(181,77,180,'来，弟弟',NULL,NULL,2,'JTalk官方','2020-04-12 12:03:03',0),(182,45,138,'我也测你',NULL,NULL,1,'Andy','2020-04-12 12:03:49',0),(183,117,179,'!I!ud83d!I!ude0f!I!ud83d!I!ude0fThat&amp;#39;s ok',NULL,NULL,1,'Andy','2020-04-12 15:13:01',0),(184,120,193,'?!I!ud83c!I!udffc!I!ud83d!I!ude01',NULL,NULL,6,'Baraa','2020-04-18 03:25:40',0),(190,134,203,'OMG !I!ud83d!I!ude0d love you bud ??',NULL,NULL,6,'Baraa','2020-04-26 20:23:40',0),(186,133,196,'and looks so hot!I!ud83d!I!ude02!I!ud83d!I!ude02!I!ud83e!I!udd29',NULL,NULL,1,'Andy','2020-04-22 16:09:31',0),(187,133,196,'!I!ud83d!I!ude02!I!ud83d!I!ude01!I!ud83d!I!udc4c!I!ud83c!I!udffc',NULL,NULL,6,'Baraa','2020-04-23 03:45:33',0),(191,134,203,'?!I!ud83d!I!ude18',NULL,NULL,6,'Baraa','2020-04-26 20:25:36',0),(192,134,203,'!I!ud83d!I!ude0a',NULL,NULL,1,'Andy','2020-04-29 21:54:57',0),(193,135,204,'!I!ud83e!I!udd25!I!ud83e!I!udd25!I!ud83e!I!udd25!I!ud83e!I!udd25!I!ud83e!I!udd25',NULL,NULL,1,'Andy','2020-04-29 22:01:32',0),(194,135,204,'It is lovely !I!ud83e!I!udd10!I!ud83d!I!ude02',NULL,NULL,6,'Baraa','2020-04-30 12:47:58',0),(195,137,206,'No time to waste !I!ud83d!I!ude05 I am making a good progress in Python generally and Data Analysis specifically',NULL,NULL,6,'Baraa','2020-05-12 18:06:04',0),(199,83,225,'呵',NULL,NULL,2,'JTalk官方','2020-05-22 19:34:24',0),(200,83,225,'嘿嘿嘿',NULL,NULL,2,'JTalk官方','2020-05-22 19:38:43',0),(201,83,152,'!I!ud83d!I!ude02',NULL,NULL,2,'JTalk官方','2020-05-22 19:41:08',0);
/*!40000 ALTER TABLE `Moment_Reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Moment_Topic`
--

DROP TABLE IF EXISTS `Moment_Topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Moment_Topic` (
  `TopicID` int(11) NOT NULL,
  `TopicZH` varchar(50) DEFAULT NULL,
  `TopicEN` varchar(50) DEFAULT NULL,
  `RankOrder` int(11) DEFAULT NULL,
  PRIMARY KEY (`TopicID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Moment_Topic`
--

LOCK TABLES `Moment_Topic` WRITE;
/*!40000 ALTER TABLE `Moment_Topic` DISABLE KEYS */;
INSERT INTO `Moment_Topic` VALUES (1,'马来西亚','Malaysia',1),(0,'综合','General',1);
/*!40000 ALTER TABLE `Moment_Topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Official`
--

DROP TABLE IF EXISTS `Official`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Official` (
  `OID` int(11) NOT NULL,
  `Account` char(50) DEFAULT NULL,
  `KEY` char(100) DEFAULT NULL,
  `Token` char(50) DEFAULT NULL,
  `Client` int(11) DEFAULT '0',
  PRIMARY KEY (`OID`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Official`
--

LOCK TABLES `Official` WRITE;
/*!40000 ALTER TABLE `Official` DISABLE KEYS */;
INSERT INTO `Official` VALUES (0,'jitu2019','zy7gws65hxe3swsl68hmpzmumyebks9w','123456',1);
/*!40000 ALTER TABLE `Official` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Port`
--

DROP TABLE IF EXISTS `Port`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Port` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Account` varchar(50) DEFAULT NULL,
  `Phone` varchar(30) DEFAULT NULL,
  `KEY` varchar(50) DEFAULT NULL,
  `Token` varchar(50) DEFAULT NULL,
  `Action` varchar(20) DEFAULT NULL,
  `PID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Port`
--

LOCK TABLES `Port` WRITE;
/*!40000 ALTER TABLE `Port` DISABLE KEYS */;
INSERT INTO `Port` VALUES (5,'Baraa','0183533095','hnlpcucanil89qnfjvt5202qdxaxlscc','baabal8534','700080',3),(2,'Shaheem','01116509173','dma8exj9j17ohbtznsl1em8vrofpu00z','Zaba2019','123456',2),(6,'WHQ','01116317293','cph2wa29smycobj8ykw9ubeytr3zzc1y','Kajang2019','123456',4),(3,'Jeff','01151691877','rnnsa2ai4br0q5trtgqz1m336nrf49sn','Ibu2019','123456',1),(1,'Admin','0172388926','qsjx1ceskqmmgwnpgcen081i6o1nmv4d','jitu2019','5517241',0),(7,'Arka','0104273708','nuc96sbr2prfneoe29iol3kg5r3b1yyd','KKM2019','123456',5),(8,'Muhtasim','0182569420','6yqzow7nn5gxfzhkfakp85ppud2jbfid','krk2019','123456',6),(9,'Admin2','0172388926','5ul9sampja42wxwq5byjd5uh9g15fa1r','jitu2020','123456',0);
/*!40000 ALTER TABLE `Port` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ports`
--

DROP TABLE IF EXISTS `Ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ports` (
  `PID` int(11) NOT NULL AUTO_INCREMENT,
  `PName` varchar(50) DEFAULT NULL,
  `PLoc` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`PID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ports`
--

LOCK TABLES `Ports` WRITE;
/*!40000 ALTER TABLE `Ports` DISABLE KEYS */;
INSERT INTO `Ports` VALUES (1,'测试地标','0,2');
/*!40000 ALTER TABLE `Ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Shopkeeper`
--

DROP TABLE IF EXISTS `Shopkeeper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Shopkeeper` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Account` varchar(50) DEFAULT NULL,
  `Token` varchar(20) NOT NULL,
  `Action` varchar(10) DEFAULT NULL,
  `KEY` varchar(100) NOT NULL,
  `ShopID` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=gbk COMMENT='店掌柜';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shopkeeper`
--

LOCK TABLES `Shopkeeper` WRITE;
/*!40000 ALTER TABLE `Shopkeeper` DISABLE KEYS */;
INSERT INTO `Shopkeeper` VALUES (1,'Andy','wtfwtfwtf','5517241','h74ygakpej67fnjr0w2jzlfowfj6rcz5',1),(2,'HotMealBa','hotmealba','3888702','ajaxnz5bfgbrkbfpl48znb2gxmopn6td',3),(3,'Andy','wtfwtfwtff','123456','ajaxnz5bfgbrkbfpl48znb2gxmopn6td',2);
/*!40000 ALTER TABLE `Shopkeeper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserLike`
--

DROP TABLE IF EXISTS `UserLike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserLike` (
  `LID` int(11) NOT NULL AUTO_INCREMENT,
  `RootID` int(11) NOT NULL DEFAULT '0',
  `UID` int(11) NOT NULL,
  `LDate` datetime NOT NULL,
  PRIMARY KEY (`LID`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=gbk;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserLike`
--

LOCK TABLES `UserLike` WRITE;
/*!40000 ALTER TABLE `UserLike` DISABLE KEYS */;
INSERT INTO `UserLike` VALUES (67,131,2,'2020-04-21 12:14:49'),(65,131,3,'2020-04-20 12:14:29'),(66,131,1,'2020-04-21 09:48:53'),(68,114,3,'2020-04-21 21:19:01'),(69,133,1,'2020-04-22 16:03:15'),(70,70,1,'2020-04-23 09:08:49'),(71,133,2,'2020-04-23 16:01:54'),(72,134,1,'2020-04-26 15:12:38'),(73,135,1,'2020-04-29 21:54:37'),(74,136,6,'2020-04-30 12:47:31'),(75,137,2,'2020-05-11 21:58:01'),(76,83,1,'2020-05-16 00:12:25'),(77,118,1,'2020-05-18 14:39:11'),(78,136,1,'2020-05-22 20:45:52'),(79,80,1,'2020-05-23 14:22:33'),(80,49,1,'2020-05-23 14:22:41'),(81,138,1,'2020-06-17 22:51:42'),(82,139,6,'2020-06-20 10:35:22');
/*!40000 ALTER TABLE `UserLike` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`gdm340875110`@`%`*/ /*!50003 TRIGGER `UserLike_after_insert` BEFORE INSERT ON `UserLike` FOR EACH ROW update `Moment` set `Like`=`Like`+1 where `Moment`.`MomentID` = TRIM(New.RootID) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`gdm340875110`@`%`*/ /*!50003 TRIGGER `UserLike_after_delete` BEFORE DELETE ON `UserLike` FOR EACH ROW update `Moment` set `Like` = `Like`-1 where `Moment`.`MomentID` = Old.RootID */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stores` (
  `SID` int(11) NOT NULL AUTO_INCREMENT,
  `LOC` char(50) NOT NULL DEFAULT '0',
  `Status` int(11) NOT NULL DEFAULT '0',
  `Express` double NOT NULL DEFAULT '0',
  `ZH_Name` varchar(50) NOT NULL DEFAULT 'BABYStore',
  `EN_Name` varchar(50) NOT NULL DEFAULT '0',
  `ZH_Detail` varchar(400) NOT NULL DEFAULT '0',
  `EN_Detail` varchar(400) NOT NULL DEFAULT '0',
  `Supports` varchar(500) DEFAULT NULL,
  `Phone` varchar(50) NOT NULL DEFAULT '0',
  `Start` double NOT NULL DEFAULT '0',
  `Packing` double NOT NULL DEFAULT '0',
  `Type` varchar(10) NOT NULL DEFAULT 'Take away',
  `OpenTime` varchar(125) DEFAULT NULL,
  PRIMARY KEY (`SID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=gbk COMMENT='商店总表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stores`
--

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
INSERT INTO `stores` VALUES (1,'1',1,3,'Q字号鲜果坊','Mr.Q Fruit Shop','欢迎光临Q字号鲜果坊，为您提供新鲜便宜的水果+配送服务 !~','Welcome_to_Mr.Q_Fruit_shop_!_Order_now_and_get_freshest_and_cheapest_fruits ~','UKM@ZABA#Shaheem@KolejUngkuOmar#Someone@FTSM#Someone@FEP#Jeff@IbuZain#Jeff!SavileKajang@SavileKajang#Someone!VillaTropika@VillaTropika#Andy!Kolej_Keris_Mas@KolejKerisMas#Arka!Kolej_Rahim_Kajai@KolejRahimKajai#Muhtasim','60172388926',5,0.5,'Take away','2,18:30'),(2,'2',0,4,'积土超市','Supermarket','哈喽！欢迎光临积土超级商城，在本店下单后，次日下午18点就能送到您的宿舍哟','Welcome_to_Mr.Q_Supermarket_!_Order_now_and_get_cheapest_goods_at_around_6PM','UKM@ZABA#Shaheem@KolejUngkuOmar#Someone@FTSM#Someone@FEP#Jeff@IbuZain#Jeff!SavileKajang@SavileKajang#Someone!VillaTropika@VillaTropika#Andy!Kolej_Keris_Mas@KolejKerisMas#Arka!Kolej_Rahim_Kajai@KolejRahimKajai#Muhtasim','60172388926',8,0,'Take away','19'),(3,'1,2,3,4,6',1,2,'清·真','Halal restrant','清·真是您与朋友聚餐，同学派对的不二之选','Description...','预订到店@Breakfast#8:30-10:00!Ibu_Zain@Breakfast#9:30am-10:30am!FEP@Breakfast#9:30AM-10:30AM!FTSM@Breakfast#9:30AM-10:30AM!Villa_Tropika@Breakfast#9:30AM-10:30AM!ZABA@Breakfast#9:30AM-10:30AM!Saville_Kajang@Tuesday#7pm-9pm@Breakfast#9:30AM-10:30AM','60177335639',2,0,'Take away','1,11:00.1,19:30.2,11:00.2,19:30.3,11:00.3,19:30.4,11:00.4,19:30.5,11:00.5,19:30.6,11:00.6,19:30.7,11:00.7,19:30');
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'gdm340875110_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-18 11:31:55
